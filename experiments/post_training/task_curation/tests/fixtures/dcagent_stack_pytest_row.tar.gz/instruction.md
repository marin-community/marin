Task: Implement a Python package gretel_synthetics providing tokenization utilities and a simple config interface, such that the provided pytest tests run against it successfully.

What to implement and where
- Create a Python package at /app/gretel_synthetics (i.e., a directory gretel_synthetics with __init__.py, plus submodules config.py and tokenizers.py). Alternatively, you may implement a single file /app/gretel_synthetics.py if you strictly prefer a module (but the tests import gretel_synthetics.config and gretel_synthetics.tokenizers, so a package is recommended).
- The package must expose:
  - A module gretel_synthetics.config containing a BaseConfig class.
  - A module gretel_synthetics.tokenizers containing tokenization-related classes and helpers as described below.

What functionality to implement

1) gretel_synthetics.config.BaseConfig
- Purpose: A minimal base configuration class that can be subclassed by test code (SimpleConfig in tests).
- API (signatures you must implement):
  - __init__(self, input_data_path: str, checkpoint_dir: str, field_delimiter: Optional[str] = None)
    - Stores the paths and delimiter for use by tokenizers/trainers.
  - get_generator_class(self) -> Optional[type]
  - get_training_callable(self) -> Optional[Callable]
- Behavior/notes:
  - SimpleConfig in tests will subclass BaseConfig and override:
    - def get_generator_class(self): return None
    - def get_training_callable(self): return None
  - The tests instantiate SimpleConfig with input_data_path and checkpoint_dir (and optionally field_delimiter). Your BaseConfig should support these attributes being used by tokenizers/trainers.

2) gretel_synthetics.tokenizers
- Provide:
  - class TokenizerError(Exception)
  - class CharTokenizer
  - class CharTokenizerTrainer
  - class SentencePieceTokenizer
  - class SentencePieceTokenizerTrainer
  - function tokenizer_from_model_dir(checkpoint_dir: str) -> Union[CharTokenizer, SentencePieceTokenizer]

- CharTokenizer
  - __init__(self, config: BaseConfig, vocab_size: Optional[int] = None)
    - Accepts a BaseConfig (or subclass) instance and an optional vocab_size.
  - @classmethod load(cls, checkpoint_dir: str) -> "CharTokenizer"
    - Load a previously trained CharTokenizer from the given directory and return an instance.
  - total_vocab_size property (int)
    - Expose the total number of tokens in the vocabulary after training.
  - field_delimiter property (Optional[str])
    - Return the delimiter used from the config (e.g., "," or None). Tests assert this value equals the config’s field_delimiter.
  - field_delimiter_token property (str)
    - The token used to represent the field delimiter in encoded output (tests expect "<d>").
  - encode_to_ids(self, text: str) -> List[int]
    - Encode an input string into a list of integer IDs using the learned vocabulary. If text contains characters not in the vocabulary, raise TokenizerError.
  - decode_from_ids(self, ids: List[int]) -> str
    - Decode a list of IDs back into a string. If an ID is out of range for the vocabulary, raise TokenizerError.
- CharTokenizerTrainer
  - __init__(self, config: BaseConfig, vocab_size: Optional[int] = None)
    - Create a trainer bound to the given config; allow an optional vocab_size to limit vocabulary size.
  - annotate_data(self) -> Iterable[str]
    - Return an iterator that yields lines from the input data file (as in tests). For the test with single-char checks, the first line yielded must equal:
      "Once upon a midnight dreary, while I pondered, weak and weary,\n"
    - The trainer instance must be deepcopy-able (no unpicklable state that breaks deepcopy).
  - train(self)
    - Train the CharTokenizer (create and persist a model artifact in config.checkpoint_dir). This should prepare the tokenizer so that CharTokenizer.load(checkpoint_dir) returns a usable tokenizer whose:
      - total_vocab_size matches the expected value in tests (e.g., 32 for the default behavior in test_single_char),
      - field_delimiter equals the config’s field_delimiter (e.g., ","),
      - field_delimiter_token equals "<d>".
    - The training should be deterministic given the same input data and config.
- SentencePieceTokenizer
  - __init__(self, config: BaseConfig)
    - Similar to CharTokenizer but for a simple SentencePiece-like tokenizer.
  - @classmethod load(cls, checkpoint_dir: str) -> "SentencePieceTokenizer"
    - Load a previously trained SP tokenizer from the given directory.
  - encode_to_ids(self, text: str) -> List[int]
    - Encode a string into IDs per the learned vocabulary. If the text contains unknown tokens, raise TokenizerError.
  - decode_from_ids(self, ids: List[int]) -> str
    - Decode IDs back to a string; raise TokenizerError for invalid IDs.
- SentencePieceTokenizerTrainer
  - __init__(self, config: BaseConfig)
  - annotate_data(self) -> Iterable[str]
    - Return an iterator over encoded/annotated lines suitable for training. For test expectations:
      - The first line produced by annotate_data for the default (no field_delimiter) case must be:
        "Once upon a midnight dreary, while I pondered, weak and weary,<n>\n"
        i.e., the same content as the input line but with an explicit end-of-sequence marker "<n>" before the trailing newline.
      - If a field_delimiter is provided (e.g., ","), annotate lines should insert a field-delimiter token "<d>" between fields and end with "<n>\n", i.e.:
        "Once upon a midnight dreary<d> while I pondered<d> weak and weary<d><n>\n"
        (note: the comma separators in the original line are replaced by "<d>" delimiters in the annotated line).
  - train(self)
    - Train the SentencePiece tokenizer using the annotated data and persist a model artifact in config.checkpoint_dir. The tests expect that:
      - After training, SentencePieceTokenizer.load(checkpoint_dir) yields a tokenizer whose encode_to_ids and decode_from_ids produce the IDs and text exactly as asserted in tests.
  - tokenizer_from_model_dir(checkpoint_dir) behavior
    - The module-level function tokenizer_from_model_dir(checkpoint_dir) should inspect the directory and return an instance of the appropriate tokenizer type (CharTokenizer or SentencePieceTokenizer) that was trained and saved in that directory. The tests assert:
      - For a CharTokenizer training path, tokenizer_from_model_dir(tmpdir) returns an instance of tok.CharTokenizer.
      - For a SentencePieceTokenizer training path, tokenizer_from_model_dir(tmpdir) returns an instance of tok.SentencePieceTokenizer.

General requirements and constraints
- Determinism and reproducibility
  - The implementation must be deterministic given the same input data and configuration. Avoid randomness in vocab creation or ID assignment.
- Deepcopy compatibility
  - Trainers must be deepcopy-able (no non-picklable attributes). Ensure there are no open file handles, threads, or lambdas stored in trainer instances that would break deepcopy.
- Checkpointing
  - During train, persist a simple, self-contained representation of the trained tokenizer in the provided checkpoint_dir. Keep the format simple (JSON or pickle) and ensure load() can reconstruct the tokenizer.
- Encoding/decoding parity
  - encode_to_ids and decode_from_ids must be inverses of each other for the vocabulary you trained. Unknown tokens during encoding or IDs outside the vocabulary must raise TokenizerError.
- Tests expectations alignment
  - The tests rely on precise outputs for:
    - The first line yielded by CharTokenizerTrainer.annotate_data
    - The first line yielded by SentencePieceTokenizerTrainer.annotate_data with and without field_delimiter
    - The vocabulary size after training (total_vocab_size)
    - The exact ID sequences produced by encode_to_ids for specific input strings
    - The exact strings produced by decode_from_ids
    - The ability of tokenizer_from_model_dir to return the correct tokenizer type
  - Your implementation should reproduce these exact outputs for the given test inputs and data (i.e., the data at tests’ input_data_path and the same sample strings used in tests).

Notes on data and behavior you must reproduce
- The tests use a sample line L1 defined as:
  L1 = "Once upon a midnight dreary, while I pondered, weak and weary,\n"
- For CharTokenizer without field_delimiter:
  - annotate_data yields L1 as the first line.
  - After training, the tokenizer should encode L1 to a specific ID sequence (provided in tests) and decode back to L1.
  - field_delimiter in the tokenizer should be "," and field_delimiter_token should be "<d>".
- For CharTokenizer with a small vocab (vocab_size=10):
  - After training, total_vocab_size should be 10.
  - Encoding "Once upon" should raise TokenizerError (unknown tokens due to small vocab).
  - Decoding [11] should raise TokenizerError (invalid ID).
- For SentencePieceTokenizer without field_delimiter:
  - annotate_data first line should be:
    "Once upon a midnight dreary, while I pondered, weak and weary,<n>\n"
  - After training, encoding and decoding should produce a specific ID sequence and revert to the original string "Once upon a midnight dreary, while I pondered, weak and weary,<n>".
  - tokenizer_from_model_dir should return a SentencePieceTokenizer instance for the SP path.
- For SentencePieceTokenizer with field_delimiter ("," as field delimiter):
  - annotate_data first line should be:
    "Once upon a midnight dreary<d> while I pondered<d> weak and weary<d><n>\n"
  - After training, encoding of:
    "Once upon a midnight dreary<d> while I pondered<d> weak and weary<d><n>\n"
    should yield a particular ID sequence and decoding should yield:
    "Once upon a midnight dreary, while I pondered, weak and weary,<n>"
  - tokenizer_from_model_dir should return a SentencePieceTokenizer instance for the SP + field-delim path.

Acceptance criteria
- The codebase in /app/gretel_synthetics (as a package or module per above) must be importable by the existing tests:
  - import gretel_synthetics.config as ... must work.
  - import gretel_synthetics.tokenizers as tok must work.
- All tests in the provided pytest file should execute and pass with your implementation, assuming the same test data and expectations as described.

Implementation note
- The task requires implementing a simplified, test-focused tokenizer ecosystem (char-level and simple SP-like) with training, persistence, loading, and deterministic encoding/decoding behavior that matches the tests’ expectations. The exact internal ID mappings are part of what you must implement to satisfy the tests; document your encoding/decoding behavior clearly in comments or docstrings to aid future maintainers.