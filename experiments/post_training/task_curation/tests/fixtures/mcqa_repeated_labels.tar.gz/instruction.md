You are answering a multiple-choice question. Read the question below and write your final answer to `/app/answer.txt`.

The verifier extracts a single letter (A/B/C/...) from your answer file using a regex pattern; the simplest valid output is a file containing exactly
`Answer: X` (where X is your chosen letter).

---

Answer the following multiple choice question. The last line of your response should be in the following format: 'Answer: A/A/B/C/D/E/F/G/H/I/J' (e.g. 'Answer: F').

In PET/MRI systems, attenuation correction using MRI-derived maps faces challenges near bone-tissue interfaces. A study simulates two reconstruction scenarios:  
Scenario

A: Uses Dixon-based segmentation assigning discrete attenuation coefficients  
Scenario B: Uses ultra-short echo time (UTE) sequences for continuous coefficient estimation  
Both show comparable performance in soft tissues, but significant divergence occurs at trabecular bone-lung boundaries in thoracic imaging. Assuming equivalent acquisition parameters and identical activity concentration errors elsewhere, which artifact is *exclusively* amplified in Scenario A compared to Scenario B?  
A: Streak artifacts from angular undersampling  
B: Gibbs ringing at high-contrast interfaces  
C: Spurious hot spots in mediastinal lymph nodes  
D: Overestimation of SUV in vertebral metastases  
E: Underestimation of lesion contrast in lung apices  
F: Cusp artifacts at costovertebral junctions  
G: Cold artifacts around myocardial walls  
H: Misregistration-induced quantification errors  
I: Photopenic defects in subdiaphragmatic regions  
J: None exhibit exclusive scenario-dependent divergence