#!/bin/bash
set -u
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
python3 /tests/verifier.py >> /logs/verifier/test-stdout.txt 2>&1
