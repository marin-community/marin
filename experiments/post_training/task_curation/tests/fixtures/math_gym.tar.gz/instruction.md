You are a careful mathematical reasoner. Read the problem below and show your work, then write your final answer at the path `/app/answer.txt`.

Format requirement: the answer file should contain `\boxed{<answer>}` on its
last meaningful line. The verifier extracts the last `\boxed{...}` it finds.

---

Your task is to find the solution to this math problem. Make sure your answer is inside \boxed{}.
Let
\[
I = \int_{0}^{1} \frac{\ln^{2} x + \ln^{2} (1-x) - \ln x \ln (1-x)}{1 - x + x^{2}} \, dx.
\]

All logarithms are natural and the integral is taken in the improper sense. Determine the exact closed-form value of \(I\) as a combination of classical constants.

## Submitting your answer (IMPORTANT)
You are a terminal agent. Your chat reply is NOT graded — the grader only reads the file `/app/answer.txt` inside the sandbox. You MUST write your solution, ending with the final answer in \boxed{...} to `/app/answer.txt` by RUNNING A SHELL COMMAND, e.g. a heredoc:

    cat > /app/answer.txt <<'EOF'
    <your solution, ending with the final answer in \boxed{...} here>
    EOF

Then confirm it with `cat /app/answer.txt`. An empty or missing `/app/answer.txt` scores 0 regardless of what you wrote in your reply.

Reliability note: write a provisional `/app/answer.txt` as soon as you have a
candidate answer, then refine it if needed. This preserves a scoreable answer if
later computation consumes the remaining agent time.
