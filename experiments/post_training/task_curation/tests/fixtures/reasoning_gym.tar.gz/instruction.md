You are solving a procedurally-generated reasoning task from Reasoning Gym. Read the problem below and write your final answer to `/app/answer.txt`. The verifier will try the upstream Reasoning Gym scorer first, then fall back to normalized exact-match.

---

Simplify the fraction $3211/6695$ to its lowest terms. Give only the simplified fraction as your final answer.