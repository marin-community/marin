## Environment Setup (complete these steps first)

```bash
cd /testbed
git clone https://github.com/0xPolygonHermez/zkevm-node.git . && git checkout 6e30e6f81a54eaf7fda9e676824d2096b07eb18a
export DEBIAN_FRONTEND=noninteractive
apt-get update -y -qq
apt-get install -y -qq golang docker-compose
export GOPATH=$HOME/go
export GOMODCACHE=$GOPATH/pkg/mod
export GOCACHE=$HOME/.cache/go-build
mkdir -p $GOPATH $GOCACHE
go mod download
```

---

Fix executor input for unsigned transactions
After talking with @0xPolygonHermez/protocol we've decided that the executor will require correct nonce and chainID when using unsigned transactions. Since the jRPC method behind this functionality doesn't receive this data, we need to artificially inject this, probably in this method `func EncodeUnsignedTransaction(tx types.Transaction) ([]byte, error)`:

- [ ] ChainID it's already being added, but it's a hardcoded constant, instead of something that depends on network config
- [x] The nonce should be fetched from DB. Handled by the jRPC, implemented in this PR #1034
