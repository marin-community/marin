#!/bin/bash
set -euo pipefail
APP_DIR="${APP_DIR:-/app}"
mkdir -p "$APP_DIR"
printf '%s' 'cHJpbnQoJ1lORU9TJ1t7KmlucHV0KCl9IT17KicxOTc0ICd9OjoyXSk=' | base64 -d > "$APP_DIR/solution.py"
