# Task Description: Check for Sequence Arrangement

## Problem Statement

You are given four digits: \( N_1, N_2, N_3, \) and \( N_4 \). Your task is to determine if these digits can be rearranged to form the sequence of digits "1974".

## Input Format

- Four integers \( N_1, N_2, N_3, N_4 \) (0 ≤ \( N_i \) ≤ 9) representing the digits.

## Output Format

- Print "YES" if the digits can be rearranged to form the sequence "1974".
- Print "NO" if they cannot.

## Examples

**Example 1:**

Input:
```
1 9 7 4
```
Output:
```
YES
```

**Example 2:**

Input:
```
2 3 4 5
```
Output:
```
NO
```

**Example 3:**

Input:
```
4 9 1 7
```
Output:
```
YES
```

## Solution

Your solution should be implemented in the `/app/` directory.

Important: place your implementation at `/app/solution.py` so the verifier can run it.
