#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
passed=0
total=0

for input_file in /tests/inputs/input_*.txt; do
    [[ -f "$input_file" ]] || continue
    total=$((total + 1))
    number=$(basename "$input_file" | sed 's/input_//;s/\.txt//')
    expected="/tests/outputs/output_${number}.txt"
    [[ -s "$input_file" && -s "$expected" ]] || exit 1
    set +e
    timeout 30 python3 /app/solution.py < "$input_file" > /tmp/codenet-actual.txt         2> /logs/verifier/stderr.txt
    status=$?
    set -e
    [[ $status -eq 0 ]] || exit 1
    python3 - /tmp/codenet-actual.txt "$expected" <<'PY' || exit 1
import sys
from pathlib import Path

actual = " ".join(Path(sys.argv[1]).read_text().split())
expected = " ".join(Path(sys.argv[2]).read_text().split())
raise SystemExit(0 if actual == expected else 1)
PY
    passed=$((passed + 1))
done

if [[ $total -ge 2 && $passed -eq $total ]]; then
    echo 1 > /logs/verifier/reward.txt
    exit 0
fi
exit 1
