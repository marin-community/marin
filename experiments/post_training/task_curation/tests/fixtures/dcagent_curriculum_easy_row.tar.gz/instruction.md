# Easier task: implement a small compatibility module for ddtrace

Objective
- Create a minimal Python package at /app/ddtrace with an __init__.py and a module compat.py.
- The tests will import from ddtrace.compat:
  - to_unicode
  - PY2
  - reraise
  - get_connection_response

What to implement (simplified but functional)
1) ddtrace.compat.PY2
- A boolean constant named PY2.
- Value should be True when running under Python 2 and False under Python 3.
- Tests may override this value, so ensure the code uses the PY2 constant at call time.

2) ddtrace.compat.to_unicode(obj)
- Signature: def to_unicode(obj)
- Behavior (per version):
  - Python 2:
    - If obj is a unicode object, return it unchanged.
    - If obj is a str (bytes in Py2), decode using UTF-8 to produce a unicode object.
    - If obj is a bytes/bytearray, decode using UTF-8 to produce a unicode object.
    - Otherwise, convert using unicode(obj).
  - Python 3:
    - If obj is bytes or bytearray, decode using UTF-8 to produce a str.
    - If obj is str, return it unchanged.
    - For any other type, return str(obj).
- The function should return the appropriate string type for the current Python version and work for common inputs (non-strings and encoding cases).

3) ddtrace.compat.get_connection_response(conn)
- Signature: def get_connection_response(conn)
- Behavior:
  - If PY2 is True, call conn.getresponse(buffering=...) with a buffering keyword argument (any truthy value is fine) so tests can detect buffering in kwargs.
  - If PY2 is False, call conn.getresponse(...) without any buffering keyword argument.
- Works with any object that implements a getresponse(self, *args, **kwargs) callable.

4) ddtrace.compat.reraise(tp, value, tb=None)
- Signature: def reraise(tp, value, tb=None)
- Purpose: A Python 2/3 compatible helper to re-raise an exception with the original traceback.
- Expected behavior for tests:
  - Return an exception instance that, when raised, preserves the original message (tests typically check the message, e.g., 'Ouch!').
  - If tb is provided, attach it to the returned exception via with_traceback(tb) when possible.
  - The returned object must be raiseable (i.e., an exception instance).

5) Packaging and exposure
- Ensure /app/ddtrace/__init__.py exists and is importable.
- __init__ should expose the compat module or re-export the requested names, e.g.:
  - from .compat import to_unicode, PY2, reraise, get_connection_response
- No external dependencies. Pure Python only.

How to implement (guiding hints)
- Detect Python version with sys.version_info to set PY2 at import time.
- Implement to_unicode with version-specific branches, using unicode on Py2 and str/bytes on Py3.
- Implement get_connection_response to call conn.getresponse with buffering on Py2 and without on Py3.
- Implement reraise to return an exception instance constructed from the provided type/value, optionally attaching the traceback.
- Keep the code self-contained and robust for common input types.

Skeleton you can start from (for clarity)
- compat.py (skeleton)
  - import sys
  - PY2 = sys.version_info[0] == 2
  - def to_unicode(obj): pass
  - def get_connection_response(conn): pass
  - def reraise(tp, value, tb=None): pass
- __init__.py
  - from .compat import to_unicode, PY2, reraise, get_connection_response

What this task yields
- A small, self-contained ddtrace.compat module with the four functions described, following an easier, straightforward approach.
- A packaging layout under /app/ ready for tests to import:
  - import ddtrace.compat
  - from ddtrace.compat import to_unicode, PY2, reraise, get_connection_response

Notes
- Do not add external dependencies.
- The implementation should be pure Python and work in standard Python environments.