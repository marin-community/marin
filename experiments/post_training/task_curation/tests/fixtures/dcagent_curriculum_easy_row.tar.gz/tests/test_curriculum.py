import pytest
import ddtrace.compat as compat
from ddtrace.compat import to_unicode, PY2, reraise, get_connection_response

def test_to_unicode_basic_py3():
    # Basic happy-path tests for Python 3
    assert to_unicode('hello') == 'hello'
    assert to_unicode(b'hello') == 'hello'
    assert to_unicode(123) == '123'

def test_to_unicode_py2_override(monkeypatch):
    # Simulate Py2 behavior by overriding PY2 at call time
    monkeypatch.setattr(compat, 'PY2', True)
    # Basic conversions in Py2 path should still produce a unicode-like result
    assert to_unicode('hello') == 'hello'
    assert to_unicode(b'abc') == 'abc'
    assert to_unicode(1) == '1'

def test_get_connection_response_py2_and_py3(monkeypatch):
    class DummyConn:
        def __init__(self):
            self.kwargs = None
        def getresponse(self, *args, **kwargs):
            self.kwargs = kwargs
            return "response"

    # Py3 path: no buffering kwarg
    c = DummyConn()
    monkeypatch.setattr(compat, 'PY2', False)
    resp = compat.get_connection_response(c)
    assert resp == "response"
    assert c.kwargs == {}

    # Py2 path: buffering kwarg should be passed
    c2 = DummyConn()
    monkeypatch.setattr(compat, 'PY2', True)
    resp2 = compat.get_connection_response(c2)
    assert resp2 == "response"
    assert c2.kwargs == {'buffering': True}

def test_reraise_preserves_message():
    exc = compat.reraise(ValueError, "Ouch!")
    with pytest.raises(ValueError) as ei:
        raise exc
    assert "Ouch!" in str(ei.value)