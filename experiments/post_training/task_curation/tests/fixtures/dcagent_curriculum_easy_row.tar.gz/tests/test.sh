#!/bin/bash
set -e

mkdir -p /logs/verifier

cleanup() {
    if [ $? -eq 0 ]; then
        echo "1" > /logs/verifier/reward.txt
    else
        echo "0" > /logs/verifier/reward.txt
    fi
}
trap cleanup EXIT

cd /app
export PYTHONPATH="/app:${PYTHONPATH:-}"

# Setup
export PYTHONPATH=/app:${PYTHONPATH:-}

echo "Running tests..."
pytest /tests/test_curriculum.py -v --tb=short 2>&1 | tee /logs/verifier/test_output.txt

exit ${PIPESTATUS[0]}
