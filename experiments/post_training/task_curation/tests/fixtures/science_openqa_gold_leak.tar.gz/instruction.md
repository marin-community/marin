You are answering an open-ended science question. Work through it and write your full answer to the file `/app/response.txt` inside the sandbox. Put your FINAL answer at the end of the response, enclosed in `\boxed{...}` exactly as the question instructs — a grader will extract the boxed answer and compare it for scientific equivalence against a reference answer.

To write the response from a shell, use a heredoc, e.g.:
    cat > /app/response.txt <<'EOF'
    <your full answer, ending with \boxed{<final answer>}>
    EOF
Verify with `cat /app/response.txt` before completing. An empty or missing file scores 0.

---

Answer the question.  
End your response with: Final Answer: ||X||, where X is the final answer and only the answer.

Show that the Majorana equation  
\(i \,\bar{\sigma}\!\cdot\!\partial\,\chi \;-\; i m \sigma^{2}\chi^{*}=0\)  
for a two‑component spinor \(\chi\) implies the Klein‑Gordon equation  
\((\partial^{2}+m^{2})\chi =0\).