Task: Implement a small Typer-based CLI package at /app/funk_lines/

What to build
- Create a Python package named funk_lines (directory /app/funk_lines) containing:
  - __init__.py
  - __main__.py
- The tests import the submodule funk_lines.__main__ and access an app object (typer.Typer instance) via __main__.app.

Required functionality
- Expose a Typer app named app in funk_lines.__main__.
- Implement a base callback that allows invocation without any subcommands.
- Support a global flag --version (and any common short form, e.g., -v if you choose, but tests call --version exactly).
  - When invoked with --version, print the version string and exit with code 0.
  - Use a defined version constant from funk_lines.__init__ (e.g., __version__ = "0.1.0") so the CLI can report the version.
- When invoked with no arguments (no subcommands, no flags), the CLI should exit with code 0 (consistent with the tests’ expectations for a zero exit status).
- Help and version behaviors must work with Typer’s built-in help text; ensure --help exits with code 0 as tested.

Implementation details to include
- In funk_lines/__init__.py:
  - Define a public version string, e.g. __version__ = "0.1.0".
- In funk_lines/__main__.py:
  - Import typer and the __version__ from the package.
  - Create a Typer app instance named app.
  - Implement a callback with invoke_without_command=True that accepts a boolean option version (typer.Option(False, "--version", help="Show the version.")). If version is True, print the version (e.g., using typer.echo(f"funk_lines {__version__}") or similar) and exit.
  - Do not define additional commands (tests only require --version, --help, and no-command invocation to succeed).
- Ensure the code is Python 3.10+ compatible and self-contained (no external dependencies beyond Typer).

Acceptance criteria
- The tests can run via pytest and pass:
  - test_version_succeeds: running the CLI with --version exits with code 0.
  - test_help_succeeds: running the CLI with --help exits with code 0.
  - test_without_commands_succeeds: running the CLI with no arguments exits with code 0.
- The implementation is located at /app/funk_lines/ (i.e., the package directory), with __init__.py and __main__.py as described.