#!/bin/bash
set -e

# Ensure logs directory exists
mkdir -p /logs/verifier

# Cleanup handler - always write reward file on exit
cleanup() {
    if [ $? -eq 0 ]; then
        echo "1" > /logs/verifier/reward.txt
    else
        echo "0" > /logs/verifier/reward.txt
    fi
}
trap cleanup EXIT

# Create virtual environment if needed (fixes PEP 668 on Python 3.12+)
if [ ! -d /app/.venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv /app/.venv
fi

# Activate virtual environment
source /app/.venv/bin/activate

# Install pytest
echo "Installing pytest..."
pip install --quiet pytest

# Install known dependencies
echo "Installing dependencies: typer..."
pip install --quiet typer 2>/dev/null || true

# Ensure /app is on PYTHONPATH so the agent's module can be imported
export PYTHONPATH=/app:$PYTHONPATH

# Change to app directory
cd /app

# Run pytest and capture output
echo "Running pytest..."
pytest /tests/test_solution.py -v --tb=short 2>&1 | tee /logs/verifier/pytest_output.txt

# Check pytest exit code
PYTEST_EXIT=${PIPESTATUS[0]}

if [ $PYTEST_EXIT -eq 0 ]; then
    echo "All tests passed!"
    exit 0
else
    echo "Some tests failed."
    exit 1
fi
