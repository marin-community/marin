Let \( X \) be a set with \( n \) elements, where \( n \ge 1 \). Denote \( \mathscr{P}(X) \) as the set of all subsets of \( X \). Find the greatest number \( m \) such that for any function \( f: \mathscr{P}(X) \to \{1, 2, 3, \ldots, m\} \), there exist subsets \( A \ne B \subset X \) such that \( f(A) = f(B) = f(A \cup B) \).

Provide your answer in the file answer.txt

## Submitting the answer

Write the final answer to `/app/answer.txt`. Put the final expression in
`\boxed{...}` when practical. Reasoning may precede the final answer, but the
last meaningful line must state the answer unambiguously.

