#!/bin/bash
set -euo pipefail
cat > /app/answer.txt <<'TASKTROVE_ANSWER_95066811b8b5a8c9'
\boxed{\( n \)}
TASKTROVE_ANSWER_95066811b8b5a8c9
