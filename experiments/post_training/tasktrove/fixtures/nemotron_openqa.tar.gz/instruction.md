You are answering an open-ended question. Write your concise final answer to `/app/response.txt`. An LLM judge will compare your response to the reference answer(s) and score for semantic equivalence (paraphrases and alternative phrasings are acceptable as long as the substantive answer matches).

---

Solve the following problem step by step. Put your answer inside \boxed{}.

Under the narrow interpretation of Article 51 of the UN Charter, when a state suffers a major armed attack by a non-state armed group operating from the territory of another state, under what condition may the victim state lawfully use military force within the host state's territory without violating the principle of sovereignty?
Remember to put your answer inside \boxed{}.