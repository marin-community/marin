"""Disable hidden reasoning for the pinned Together judge."""
import litellm

_original_acompletion = litellm.acompletion

async def _together_acompletion(*args, **kwargs):
    if kwargs.get("model") == "together_ai/Qwen/Qwen3.5-9B":
        extra_body = dict(kwargs.get("extra_body") or {})
        extra_body["reasoning"] = {"enabled": False}
        kwargs["extra_body"] = extra_body
        kwargs["temperature"] = 0.0
    return await _original_acompletion(*args, **kwargs)

litellm.acompletion = _together_acompletion
