#!/bin/bash
set -euo pipefail

mkdir -p /logs/verifier
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt

if [[ ! -s /app/response.txt && ! -s /app/answer.txt ]]; then
  printf '{"reward": 0.0}\n' > /logs/verifier/reward.json
  exit 0
fi

if [[ -s /app/answer.txt ]]; then
  cp -f /app/answer.txt /app/response.txt
fi

set +e
python3 /tests/exact_gate >> /logs/verifier/test-stdout.txt 2>&1
gate_status=$?
set -e
if [[ ${gate_status} -eq 0 ]]; then
  printf '{"reward": 1.0}\n' > /logs/verifier/reward.json
  exit 0
fi
if [[ ${gate_status} -ne 43 ]]; then
  exit "${gate_status}"
fi

export LITELLM_DROP_PARAMS=1
export PYTHONPATH=/tests
judge_status=1
for attempt in 1 2 3; do
  set +e
  rewardkit /tests --max-concurrent-llm 1 \
    >> /logs/verifier/test-stdout.txt 2>&1
  judge_status=$?
  set -e
  if [[ ${judge_status} -eq 0 ]]; then
    exit 0
  fi
  rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
  if [[ ${attempt} -lt 3 ]]; then
    sleep $((attempt * 5))
  fi
done
exit "${judge_status}"
