#!/bin/bash
set -u
REWARD=/logs/verifier/reward.txt
mkdir -p /logs/verifier
echo 0 > "$REWARD"

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

cd /testbed

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1 || \
   ! git -c safe.directory=/testbed cat-file -e 3b1e6ec37ffeacc5bed0e55e287f86166b4db21c^{commit} || \
   ! git -c safe.directory=/testbed cat-file -e 614b1348ef893b4fa90e76f56df44ee64f5d0222^{commit}; then
    exit 0
fi
if ! bash /tests/install_trusted_test_paths.sh \
    /testbed 3b1e6ec37ffeacc5bed0e55e287f86166b4db21c /tests/trusted_test_paths.txt "" \
    614b1348ef893b4fa90e76f56df44ee64f5d0222; then
    exit 0
fi
# Extract test file paths from config.json
TEST_FILES=$(python3 -c "
import json
try:
    cfg = json.load(open('/tests/config.json'))
    f2p = cfg.get('FAIL_TO_PASS', [])
    p2p = cfg.get('PASS_TO_PASS', [])
    if isinstance(f2p, str): f2p = json.loads(f2p)
    if isinstance(p2p, str): p2p = json.loads(p2p)
    files = sorted(set(t.split('::')[0] for t in f2p + p2p))
    print(' '.join(files))
except: pass
" 2>/dev/null)


# Run the specified tests
if [ -n "$TEST_FILES" ]; then
    pytest --no-header -rA --tb=line --color=no -p no:cacheprovider \
        -W ignore::DeprecationWarning --override-ini=addopts= $TEST_FILES \
        --continue-on-collection-errors > /logs/test_output.log 2>&1
else
    pytest --no-header -rA --tb=line --color=no -p no:cacheprovider \
        -W ignore::DeprecationWarning --continue-on-collection-errors \
        > /logs/test_output.log 2>&1
fi

# Grade: test_state.py parses the pytest output and checks FAIL_TO_PASS/PASS_TO_PASS
python3 -m pytest /tests/test_state.py --tb=short 2>/dev/null
if [ $? -eq 0 ]; then
    echo 1 > "$REWARD"
fi

exit 0
