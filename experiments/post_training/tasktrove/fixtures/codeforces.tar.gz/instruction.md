# Problem: brcktsrm

## Difficulty
Rating: 6

## Tags
None specified

## Constraints
- Time Limit: None seconds
- Memory Limit: 256 MB

## Problem Statement

Problem description.
Vipul is a hardworking super-hero who maintains the bracket ratio of all the strings in the world. Recently he indulged himself in saving the string population so much that he lost his ability for checking brackets (luckily, not permanently ).Being his super-hero friend help him in his time of hardship. 

Input

The first line of the input contains an integer T denoting the number of test cases. The description of T test cases follows.
The first line of each test case contains a single string S denoting the string to be checked.


Output

For each test case, output a single line printing "YES" or "NO" (without " " and in uppercase only) , denoting if the brackets in the given string is balanced or not .


Constraints

1 ≤ T ≤ 10
1 ≤ length of S ≤ 60


Example
Input:
3
((()))
(())()
()(()

Output:
YES
YES
NO

 

Explanation
Example is self-explanatory.

## Your Task

Implement a solution that:
1. Reads input from stdin
2. Produces output to stdout
3. Passes all test cases within the time and memory limits

Place your solution in `/app/solution.py` (or solution.cpp/Solution.java for C++/Java).

## Tips for Competitive Programming
- Consider edge cases (empty input, maximum values, etc.)
- Optimize for the given time/memory constraints
- Test with the provided examples before submitting

## Examples

### Example 1
**Input:**
```
3
((()))
(())()
()(()
```

**Output:**
```
YES
YES
NO
```

### Example 2
**Input:**
```
3
((()))
(())()
()())
```

**Output:**
```
YES
YES
NO

```

### Example 3
**Input:**
```
3
((()()
(())()
()(()
```

**Output:**
```
NO
YES
NO

```
