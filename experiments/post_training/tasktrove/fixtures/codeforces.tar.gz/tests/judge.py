import sys, re, io, contextlib, importlib.util

def _norm(s: str) -> str:
    return re.sub(r'\s+', ' ', (s or '').strip())

def _exact(got: str, expected: str) -> bool:
    return _norm(got) == _norm(expected)

def main():
    input_path, expected_path, got_path = sys.argv[1], sys.argv[2], sys.argv[3]
    checker_path = sys.argv[4] if len(sys.argv) > 4 else None
    got = open(got_path, 'r', errors='replace').read()
    expected = open(expected_path, 'r', errors='replace').read()
    if checker_path:
        try:
            spec = importlib.util.spec_from_file_location("cf_checker", checker_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                mod.main(input_path, expected_path, got_path)
            lines = [l for l in buf.getvalue().strip().splitlines() if l.strip()]
            if lines and lines[-1].strip() == "1":
                print("1"); return
            if lines and lines[-1].strip() == "0":
                print("0"); return
        except Exception:
            pass  # broken checker -> fall through to exact match
    print("1" if _exact(got, expected) else "0")

main()
