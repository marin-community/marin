#!/bin/bash
# Verifier: compile/run the agent solution, feed test inputs, compare stdout.
set -u
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt          # DEFAULT-FAIL
echo "0.0" > /logs/verifier/pass_ratio.txt

cd /app

# --- locate + (if needed) compile the agent solution ---
SOL=""
RUNPY=""
if [ -f /app/solution.py ]; then
    RUNPY="python3 /app/solution.py"
elif [ -f /app/solution.cpp ]; then
    if g++ -O2 -std=c++17 -o /app/sol_bin /app/solution.cpp 2>/dev/null; then SOL="/app/sol_bin"; fi
elif [ -f /app/Solution.java ]; then
    if javac -d /app /app/Solution.java 2>/dev/null; then SOL="java -cp /app Solution"; fi
fi
[ -z "$SOL" ] && [ -z "$RUNPY" ] && { echo "No solution found at /app/solution.py|solution.cpp|Solution.java"; python3 -m pytest /tests/test_state.py -q -p no:cacheprovider >/dev/null 2>&1 || true; exit 1; }
RUN="${RUNPY:-$SOL}"

# --- run every provided test case ---
PASSED=0; FAILED=0; TOTAL=0
shopt -s nullglob
for input_file in /tests/inputs/input_*.txt; do
    TOTAL=$((TOTAL + 1))
    test_num=$(basename "$input_file" | sed 's/input_//;s/.txt//')
    expected_file="/tests/outputs/output_${test_num}.txt"
    [ -f "$expected_file" ] || { echo "test $test_num: missing expected"; FAILED=$((FAILED + 1)); continue; }
    actual=$(timeout 30 $RUN < "$input_file" 2>/dev/null); rc=$?
    if [ $rc -ne 0 ]; then echo "test $test_num: runtime error/timeout ($rc)"; FAILED=$((FAILED + 1)); continue; fi
    printf '%s' "$actual" > /tmp/__got.txt
    if [ -f /tests/checker.py ]; then
        verdict=$(python3 /tests/judge.py "$input_file" "$expected_file" /tmp/__got.txt /tests/checker.py 2>/dev/null | tail -1)
    else
        verdict=$(python3 /tests/judge.py "$input_file" "$expected_file" /tmp/__got.txt 2>/dev/null | tail -1)
    fi
    if [ "$verdict" = "1" ]; then echo "test $test_num: PASS"; PASSED=$((PASSED + 1)); else echo "test $test_num: FAIL"; FAILED=$((FAILED + 1)); fi
done

# --- fallback: no test cases shipped -> at least require it compiles & runs ---
if [ "$TOTAL" -eq 0 ]; then
    if timeout 30 $RUN < /dev/null >/tmp/__out.txt 2>/dev/null; then PASSED=1; TOTAL=1; fi
fi

ratio="0"
[ "$TOTAL" -gt 0 ] && ratio=$(python3 -c "print(round($PASSED/$TOTAL, 4))")
echo "$ratio" > /logs/verifier/pass_ratio.txt
echo "Results: $PASSED/$TOTAL passed (ratio=$ratio)"

if [ "$FAILED" -eq 0 ] && [ "$TOTAL" -gt 0 ]; then echo 1 > /logs/verifier/reward.txt; fi

python3 -m pytest /tests/test_state.py -q -p no:cacheprovider >/dev/null 2>&1 || true
