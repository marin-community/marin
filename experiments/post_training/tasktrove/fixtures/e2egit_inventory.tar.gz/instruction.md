## Task Description

Implement a simple inventory management system with the following functionalities:

1. **Item Class**: Create an `Item` class in the `/app/` directory that represents an item in the inventory. Each item should have the following attributes:
   - `name` (string): the name of the item.
   - `quantity` (integer): the quantity of the item in stock.
   - `price` (float): the price of the item.

   The `Item` class should have the following methods:
   - `__init__(self, name: str, quantity: int, price: float)`: Initialize an item with the specified name, quantity, and price.
   - `increase_quantity(self, amount: int)`: Increases the quantity of the item by the specified amount. The amount must be a positive integer.
   - `decrease_quantity(self, amount: int)`: Decreases the quantity of the item by the specified amount. The amount must be a positive integer and cannot reduce the quantity below zero.

2. **Inventory Class**: Create an `Inventory` class in the `/app/` directory that manages a collection of `Item` objects. The `Inventory` class should have the following methods:
   - `__init__(self)`: Initializes an empty inventory.
   - `add_item(self, item: Item)`: Adds a new item to the inventory. If the item already exists (matched by name), it should increase the existing item's quantity instead of adding a duplicate item.
   - `remove_item(self, item_name: str, quantity: int)`: Removes the specified quantity of an item from the inventory. If the quantity to be removed is greater than the available quantity, it should not remove any items.
   - `get_inventory(self) -> List[Dict[str, Union[str, int, float]]]`: Returns a list of dictionaries representing the current inventory, with each dictionary containing the item's `name`, `quantity`, and `price`.

3. **Testing**: Ensure the implementation passes the provided test cases by meeting the following requirements:
   - The `Item` class correctly initializes items and handles quantity modifications.
   - The `Inventory` class correctly adds items, removes items, and retrieves the inventory list.
   - Proper error handling is in place for invalid quantities in both `increase_quantity` and `remove_item`.

Place the `Item` and `Inventory` classes in a file named `inventory.py` within the `/app/` directory.