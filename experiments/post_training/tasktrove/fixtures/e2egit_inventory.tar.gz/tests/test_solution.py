import sys
import pytest

sys.path.insert(0, "/app")
from inventory import Item, Inventory

def test_item_initialization():
    item = Item(name="Apple", quantity=10, price=0.50)
    assert item.name == "Apple"
    assert item.quantity == 10
    assert item.price == 0.50

def test_item_quantity_increase():
    item = Item(name="Banana", quantity=5, price=0.30)
    item.increase_quantity(10)
    assert item.quantity == 15

def test_item_quantity_decrease():
    item = Item(name="Orange", quantity=20, price=0.60)
    item.decrease_quantity(5)
    assert item.quantity == 15
    item.decrease_quantity(15)
    assert item.quantity == 0  # Should not go below zero
    item.decrease_quantity(5)  # Attempt to decrease below zero
    assert item.quantity == 0  # Should remain at zero

def test_inventory_add_item():
    inventory = Inventory()
    item1 = Item(name="Grapes", quantity=10, price=2.00)
    inventory.add_item(item1)
    assert len(inventory.get_inventory()) == 1
    assert inventory.get_inventory()[0]['name'] == "Grapes"
    assert inventory.get_inventory()[0]['quantity'] == 10
    
    # Adding the same item should increase the quantity
    inventory.add_item(item1)
    assert inventory.get_inventory()[0]['quantity'] == 20

def test_inventory_remove_item():
    inventory = Inventory()
    item = Item(name="Peach", quantity=10, price=1.00)
    inventory.add_item(item)
    
    inventory.remove_item("Peach", 5)
    assert inventory.get_inventory()[0]['quantity'] == 5
    
    # Remove more than available should not change the quantity
    inventory.remove_item("Peach", 10)
    assert inventory.get_inventory()[0]['quantity'] == 5

def test_inventory_get_inventory():
    inventory = Inventory()
    item1 = Item(name="Watermelon", quantity=3, price=3.00)
    item2 = Item(name="Mango", quantity=5, price=1.50)
    
    inventory.add_item(item1)
    inventory.add_item(item2)
    
    inv_list = inventory.get_inventory()
    assert len(inv_list) == 2
    assert inv_list[0]['name'] == "Watermelon"
    assert inv_list[1]['name'] == "Mango"
    assert inv_list[0]['quantity'] == 3
    assert inv_list[1]['quantity'] == 5