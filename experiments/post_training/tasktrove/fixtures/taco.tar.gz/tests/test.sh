#!/bin/bash
set -e

mkdir -p /logs/verifier

PASSED=0
FAILED=0
TOTAL=0

cd /app

for input_file in /tests/inputs/input_*.txt; do
    if [ ! -f "$input_file" ]; then
        continue
    fi

    TOTAL=$((TOTAL + 1))
    test_num=$(basename "$input_file" | sed 's/input_//;s/.txt//')
    expected_file="/tests/outputs/output_$test_num.txt"

    if [ ! -f "$expected_file" ]; then
        echo "Missing expected output for test $test_num"
        FAILED=$((FAILED + 1))
        continue
    fi

    echo "Running test $test_num..."
    actual_output=$(python3 /app/solution.py < "$input_file" 2>&1) || true
    expected_output=$(cat "$expected_file")

    # Normalize whitespace for comparison
    actual_normalized=$(echo "$actual_output" | tr -s '[:space:]' ' ' | sed 's/^ //;s/ $//')
    expected_normalized=$(echo "$expected_output" | tr -s '[:space:]' ' ' | sed 's/^ //;s/ $//')

    if [ "$actual_normalized" = "$expected_normalized" ]; then
        echo "Test $test_num: PASSED"
        PASSED=$((PASSED + 1))
    else
        echo "Test $test_num: FAILED"
        echo "Expected: $expected_output"
        echo "Actual: $actual_output"
        FAILED=$((FAILED + 1))
    fi
done

echo ""
echo "Results: $PASSED/$TOTAL passed"

if [ $FAILED -eq 0 ] && [ $TOTAL -gt 0 ]; then
    echo "1" > /logs/verifier/reward.txt
    exit 0
else
    echo "0" > /logs/verifier/reward.txt
    exit 1
fi
