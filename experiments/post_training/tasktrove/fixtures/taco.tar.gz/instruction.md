# Problem Description

Tania has several candy boxes arranged in a row, and she wants to eat candies from them while adhering to specific rules. Your task is to determine the minimum amount of time (in seconds) Tania needs to eat at least a given number of candies. 

## Problem Statement

There are \(n\) candy boxes in front of Tania. They are arranged in a row and numbered from \(1\) to \(n\). Each box \(i\) contains \(r_i\) candies of color \(c_i\) (where \(c_i\) can be 'R' for red, 'G' for green, or 'B' for blue). Initially, Tania is positioned next to box number \(s\). 

Tania can:
1. Move to adjacent boxes (either left or right) which takes one second per move.
2. Eat all candies from her current box instantly.

However, Tania must follow these eating rules:
- She cannot eat candies of the same color from consecutive boxes.
- The number of candies consumed from each subsequent box must strictly increase compared to the last box she ate from.

For the first box she consumes candies from, there are no restrictions on color or quantity.

Tania aims to consume at least \(k\) candies. Your goal is to find the minimum number of seconds needed for her to do so. If it's not possible for her to eat at least \(k\) candies while adhering to the rules, return `-1`.

## Input Format

- The first line contains three integers \(n\), \(s\), and \(k\) (\(1 \le n \le 50\), \(1 \le s \le n\), \(1 \le k \le 2000\)) — the number of boxes, Tania's initial position, and the minimum number of candies she wants to eat, respectively.
- The second line contains \(n\) integers \(r_i\) (\(1 \le r_i \le 50\)) — the number of candies in each box.
- The third line contains a sequence of \(n\) letters ('R', 'G', 'B') representing the colors of the candies in the respective boxes (e.g., 'R' for red, 'G' for green, and 'B' for blue). There are no spaces in this line.

## Output Format

- Print the minimum number of seconds needed to eat at least \(k\) candies. If it is impossible, print `-1`.

## Examples

### Input 1
```
5 3 10
1 2 3 4 5
RGBRR
```

### Output 1
```
4
```

### Input 2
```
2 1 15
5 6
RG
```

### Output 2
```
-1
```

## Note

In the first example, the sequence of actions taken by Tania is as follows:
1. Move from box \(3\) to box \(2\) (1 second).
2. Eat candies from box \(2\).
3. Move from box \(2\) to box \(3\) (1 second).
4. Eat candies from box \(3\).
5. Move from box \(3\) to box \(4\) (1 second).
6. Move from box \(4\) to box \(5\) (1 second).
7. Eat candies from box \(5\).

Total movement time is \(4\) seconds since eating candies is instantaneous. 

## Solution Directory

The solution should be implemented in the `/app/` directory.

Important: place your implementation at `/app/solution.py` so the verifier can run it.
