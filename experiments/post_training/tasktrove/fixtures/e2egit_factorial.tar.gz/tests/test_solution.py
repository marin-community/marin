import sys
import pytest

sys.path.insert(0, "/app")
from factorial import calculate_factorial

def test_factorial_zero():
    assert calculate_factorial(0) == 1

def test_factorial_positive_integers():
    assert calculate_factorial(1) == 1
    assert calculate_factorial(2) == 2
    assert calculate_factorial(3) == 6
    assert calculate_factorial(4) == 24
    assert calculate_factorial(5) == 120

def test_factorial_negative_integer():
    with pytest.raises(ValueError):
        calculate_factorial(-1)

def test_factorial_large_integer():
    assert calculate_factorial(20) == 2432902008176640000