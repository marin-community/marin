Implement a function named `calculate_factorial` in the file `/app/factorial.py`. This function should take a single non-negative integer as input and return the factorial of that integer. 

Requirements:
1. The function should raise a `ValueError` if the input is a negative integer.
2. The factorial of 0 should return 1 (0! = 1).
3. The function should be able to handle inputs up to 20 (inclusive), as factorials for larger integers can exceed standard data types.
4. The implementation must use a recursive approach to compute the factorial.
5. Ensure to include appropriate docstrings and type hints for the function.

Make sure to include unit tests in a separate file at `/tests/test_factorial.py` to verify the correctness of the implementation. The tests should cover the input validation, base case (0), and some typical cases (1 through 5).