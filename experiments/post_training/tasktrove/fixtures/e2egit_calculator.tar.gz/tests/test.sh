#!/bin/bash
pytest /tests/test_solution.py
