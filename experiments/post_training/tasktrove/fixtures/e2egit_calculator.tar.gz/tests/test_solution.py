import sys
sys.path.insert(0, "/app")
import pytest
from calculator import Calculator  # Assuming the Calculator class is in calculator.py

def test_addition():
    calc = Calculator()
    result = calc.add(1.5, 2.5)
    assert result == 4.0

def test_subtraction():
    calc = Calculator()
    result = calc.subtract(5.0, 3.0)
    assert result == 2.0

def test_division_by_zero():
    calc = Calculator()
    with pytest.raises(ValueError, match="Cannot divide by zero."):
        calc.divide(10.0, 0)