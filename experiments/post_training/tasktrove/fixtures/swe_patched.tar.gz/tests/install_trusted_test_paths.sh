#!/bin/bash
set -Eeuo pipefail

export GIT_CONFIG_GLOBAL=/dev/null
export GIT_CONFIG_NOSYSTEM=1
export GIT_NO_REPLACE_OBJECTS=1

repository=${1:?repository path is required}
trusted_commit=${2:?trusted commit is required}
manifest=${3:?path manifest is required}
patch_path=${4:-}
fallback_commit=${5:-}

cd "$repository"

trusted_git() {
    command git -c safe.directory="$repository"         -c core.hooksPath=/dev/null         -c core.fsmonitor=false         "$@"
}

trusted_git cat-file -e "${trusted_commit}^{commit}"

restore_path() {
    path=$1
    case "$path" in
        ""|/*|.|..|../*|*/..|*/../*)
            echo "Unsafe trusted-test path: $path" >&2
            exit 1
            ;;
    esac
    trusted_git clean -ffdx -- "$path"
    rm -rf -- "$path"
    if trusted_git cat-file -e "${trusted_commit}:${path}" 2>/dev/null; then
        trusted_git archive --format=tar "$trusted_commit" -- "$path" |             tar -xf - -C "$repository"
    elif [ -n "$fallback_commit" ] &&          trusted_git cat-file -e "${fallback_commit}:${path}" 2>/dev/null; then
        trusted_git archive --format=tar "$fallback_commit" -- "$path" |             tar -xf - -C "$repository"
    fi
}

is_test_control_path() {
    path=$1
    basename=${path##*/}
    case "/$path/" in
        */test/*|*/tests/*|*/testing/*|*/test-data/*|*/testdata/*|*/spec/*|*/specs/*|*/__tests__/*)
            return 0
            ;;
    esac
    case "$basename" in
        conftest.py|pytest.ini|tox.ini|.coveragerc|jest.config.*|vitest.config.*|test_*|*_test.*|*.test.*|*.spec.*)
            return 0
            ;;
    esac
    return 1
}

# Reset changed and untracked test-control files before restoring the explicit
# task targets. Product-code changes remain untouched.
while IFS= read -r -d '' path; do
    if is_test_control_path "$path"; then
        restore_path "$path"
    fi
done < <(
    {
        trusted_git diff --name-only -z "$trusted_commit"
        trusted_git ls-files --others --exclude-standard -z
        trusted_git ls-files             --others --ignored --exclude-standard -z
    } | sort -zu
)

# Index flags can hide working-tree edits from ordinary diff discovery.
while IFS= read -r -d '' record; do
    flag=${record%% *}
    path=${record#? }
    case "$flag" in
        [a-z]|S)
            if is_test_control_path "$path"; then
                restore_path "$path"
            fi
            ;;
    esac
done < <(trusted_git ls-files -v -z)

while IFS= read -r path || [ -n "$path" ]; do
    restore_path "$path"
done < "$manifest"

if [ -n "$patch_path" ] && [ -s "$patch_path" ]; then
    trusted_git apply --check "$patch_path"
    trusted_git apply --verbose "$patch_path"
fi
