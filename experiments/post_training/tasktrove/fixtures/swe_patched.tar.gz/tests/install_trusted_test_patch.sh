#!/bin/bash
set -Eeuo pipefail

repository=${1:?repository path is required}
patch_path=${2:?patch path is required}
trusted_commit=${3:?trusted commit is required}

exec bash /tests/install_trusted_test_paths.sh     "$repository" "$trusted_commit" /tests/trusted_patch_paths.txt "$patch_path"
