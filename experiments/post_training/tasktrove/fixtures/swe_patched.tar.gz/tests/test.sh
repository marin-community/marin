#!/bin/bash
# SWE-rebench-V2 task verifier — runs the V2 install_config.test_cmd,
# then grades using the self-contained parsers in test_state.py.

set -o pipefail

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
if ! git -C /testbed rev-parse --is-inside-work-tree >/dev/null 2>&1 ||    ! git -C /testbed -c safe.directory=/testbed cat-file -e 799957a5564e8ca1ea20d7cf643abbc21db4e40f^{commit}; then
    exit 0
fi
if ! bash /tests/install_trusted_test_paths.sh     /testbed 799957a5564e8ca1ea20d7cf643abbc21db4e40f /tests/trusted_test_paths.txt; then
    exit 0
fi

# Some base images have minimal apt available; the V2 install commands
# may have already pulled in curl/jq. Re-install opportunistically.
apt-get update >/dev/null 2>&1 || true
apt-get install -y --no-install-recommends curl jq python3 python3-pip >/dev/null 2>&1 || true

# Fallback test runners for languages where the V2 install commands
# commonly forget the runner (Python tasks routinely `pip install -e .`
# without pytest; JS tasks routinely call `pnpm` / `yarn` without
# installing them globally; etc.). All of these are no-ops if the
# tool is already on PATH.
if command -v pip >/dev/null 2>&1; then
    pip install -q pytest pytest-xprocess >/dev/null 2>&1 || true
elif command -v pip3 >/dev/null 2>&1; then
    pip3 install -q pytest pytest-xprocess >/dev/null 2>&1 || true
fi
if command -v npm >/dev/null 2>&1; then
    command -v pnpm >/dev/null 2>&1 || npm install -g pnpm --silent >/dev/null 2>&1 || true
    command -v yarn >/dev/null 2>&1 || npm install -g yarn --silent >/dev/null 2>&1 || true
    command -v jest >/dev/null 2>&1 || npm install -g jest --silent >/dev/null 2>&1 || true
fi

# uv brings its own Python; we use it as the grader runtime (no
# dependency on the language-family base image actually having Python).
if ! command -v uv >/dev/null 2>&1; then
    curl -LsSf https://astral.sh/uv/0.7.13/install.sh | sh >/dev/null 2>&1 || true
    export PATH="$HOME/.local/bin:$PATH"
fi

# Restore hidden-test paths from the immutable base before applying the trusted
# patch. Product-code edits made by the agent remain untouched.
if ! bash /tests/install_trusted_test_patch.sh /testbed /tests/test_patch.diff 799957a5564e8ca1ea20d7cf643abbc21db4e40f; then
    exit 1
fi

# Run the task's test command (per-row from install_config.test_cmd).
# We capture the exit status — it's used by test_state.py as a fallback
# signal when the parser can't identify per-test names.
pytest --no-header -rA --tb=line --color=no -p no:cacheprovider -W ignore::DeprecationWarning tests/unit/test_linter.py > /logs/test_output.log 2>&1
echo $? > /logs/test_exit_code.txt

echo "=== TEST OUTPUT (last 100 lines) ==="
tail -100 /logs/test_output.log
echo "=== END TEST OUTPUT ==="

# Grading harness — uv-managed venv so we never collide with the testbed env.
# The grader is fully self-contained (no swebench dependency).
cd /tests
uv init --python 3.12 --no-progress >/dev/null 2>&1 || true
uv add --no-progress pytest==8.4.1 pytest-json-ctrf==0.3.5 >/dev/null 2>&1
uv run --no-progress pytest --ctrf /logs/verifier/ctrf.json test_state.py -rA

if [ $? -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
