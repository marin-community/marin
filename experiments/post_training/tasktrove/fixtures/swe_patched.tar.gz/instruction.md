## Environment Setup (complete these steps first)

```bash
cd /testbed
git clone https://github.com/3YOURMIND/django-migration-linter.git . && git checkout 799957a5564e8ca1ea20d7cf643abbc21db4e40f
export DEBIAN_FRONTEND=noninteractive && apt-get update -y -qq && apt-get install -y -qq default-libmysqlclient-dev build-essential pkg-config libpq-dev
pip install -q -e .
pip install -q mysqlclient psycopg2 appdirs toml django_add_default_value coverage
```

---

Bug: --include-migrations-from argument being ignored
In version 2.2.2, using the `--include-migration-from` argument and specifying a migration .py file will not work and `lintmigrations` will run on all migration files.

On [line 299](https://github.com/3YOURMIND/django-migration-linter/blob/799957a5564e8ca1ea20d7cf643abbc21db4e40f/django_migration_linter/migration_linter.py#L299) of `migration_linter.py` the method `is_migration_file` is being called with every line of the `migrations_file_path` file instead of the filename `migrations_file_path`
