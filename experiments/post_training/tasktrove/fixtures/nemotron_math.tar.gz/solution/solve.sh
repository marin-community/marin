#!/bin/bash
set -euo pipefail
cat > /app/answer.txt <<'TASKTROVE_ANSWER_4a44dc15364204a8'
\boxed{10}
TASKTROVE_ANSWER_4a44dc15364204a8
