Find the natural number \( n \neq 0 \) such that 210 divides \( 6 + 6^2 + \cdots + 6^n \).

Please place your final answer in a file named `/app/solution.txt`.

## Submitting the answer

Write the final answer to `/app/answer.txt`. Put the final expression in
`\boxed{...}` when practical. Reasoning may precede the final answer, but the
last meaningful line must state the answer unambiguously.

