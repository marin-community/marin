#!/bin/bash
set -euo pipefail
mkdir -p /logs/verifier
rm -f /logs/verifier/reward.txt
python3 /tests/verifier.py >> /logs/verifier/test-stdout.txt 2>&1
test -s /logs/verifier/reward.txt
grep -Eq '^(0|1)$' /logs/verifier/reward.txt
