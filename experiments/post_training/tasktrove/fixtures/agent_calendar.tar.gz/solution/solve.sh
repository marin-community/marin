#!/bin/bash
set -eu
cp /solution/answer.json /app/answer.txt
