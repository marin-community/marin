#!/bin/bash
set -euo pipefail

# Install test dependencies (offline-safe: already in image, pip is a no-op)
pip3 install --quiet pytest==8.4.1 pytest-json-ctrf==0.3.5 2>/dev/null || true

mkdir -p /logs/verifier

# Run pytest without aborting the script on a test failure, capture its exit
# code, then restore strict mode. Under `set -e` a non-zero pytest exit killed
# the script before reward.txt was written, so failing solutions produced a
# RewardFileNotFoundError instead of reward=0. Always record a reward now.
set +e
pytest --ctrf /logs/verifier/ctrf.json /tests/test_state.py -rA
PYTEST_EXIT=$?
set -e

if [ $PYTEST_EXIT -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
