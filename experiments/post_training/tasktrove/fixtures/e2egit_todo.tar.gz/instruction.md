### Task Description: Implement a Simple Todo List Functionality

Your task is to implement the functionality of a simple Todo List application. The application should allow users to add, remove, and list tasks. The main functionality to be implemented is as follows:

1. **Add Task**: Create a function `addTask(task: string)` that takes a string as input and adds it to the list of tasks. The task should be stored in a way that it is accessible for future operations.

2. **Remove Task**: Implement a function `removeTask(task: string)` which takes a string as input and removes the specified task from the list. If the task does not exist, the function should gracefully handle the situation (e.g., by not making any changes or notifying the user).

3. **List Tasks**: Write a function `listTasks(): string[]` that returns an array of all current tasks in the list. The tasks should be returned in the order they were added.

### Specific Requirements:
- Ensure that when a task is added, it does not allow duplicate tasks (i.e., the same task should only be added once).
- If the user attempts to remove a task that doesn't exist, the function should not throw an error but instead return a message indicating that the task was not found.
- The implementation should be placed in the `/app/` directory of the project.
- The code should adhere to standard JavaScript/TypeScript best practices, including proper function signatures, clean code structure, and comments where necessary for clarity.

Make sure your implementation passes the provided test cases, which are designed to verify the correct functioning of the add, remove, and list operations.