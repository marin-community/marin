import sys
sys.path.insert(0, "/app")

import pytest
from todo_list import addTask, removeTask, listTasks

def test_add_task():
    addTask("Buy groceries")
    addTask("Walk the dog")
    tasks = listTasks()
    assert tasks == ["Buy groceries", "Walk the dog"]

def test_add_duplicate_task():
    addTask("Read a book")
    addTask("Read a book")  # Attempt to add a duplicate
    tasks = listTasks()
    assert tasks == ["Read a book"]

def test_remove_task():
    addTask("Finish homework")
    assert removeTask("Finish homework") == "Task 'Finish homework' removed."
    tasks = listTasks()
    assert tasks == []

def test_remove_nonexistent_task():
    addTask("Go for a run")
    result = removeTask("Non-existent task")
    assert result == "Task 'Non-existent task' not found."
    tasks = listTasks()
    assert tasks == ["Go for a run"]