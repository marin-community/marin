#!/usr/bin/env python3
import json
import pathlib
import re
import sys

FAMILY = 'structured'


def require(condition, message):
    if not condition:
        raise ValueError(message)


data = json.loads(pathlib.Path(sys.argv[1]).read_text())
require(isinstance(data, dict), "verifier data must be an object")
if FAMILY == "swe_tool_call":
    value = data.get("expected")
    require(isinstance(value, list) and value, "expected calls missing")
    require(all(isinstance(call, dict) and isinstance(call.get("name"), str) for call in value), "invalid expected call")
elif FAMILY == "grid_transform":
    value = data.get("test_cases")
    require(isinstance(value, list) and value, "test cases missing")
    require(all(isinstance(case, dict) and isinstance(case.get("input"), list) and isinstance(case.get("output"), list) for case in value), "invalid test case")
elif FAMILY == "grid_match":
    value = data.get("expected_output")
    require(isinstance(value, list) and value and all(isinstance(row, list) for row in value), "invalid expected grid")
elif FAMILY == "stdio_diff":
    inputs, outputs = data.get("inputs"), data.get("outputs")
    require(isinstance(inputs, list) and inputs and isinstance(outputs, list) and len(inputs) == len(outputs), "invalid stdin/stdout tests")
    require(all(isinstance(value, str) for value in inputs + outputs), "stdin/stdout tests must be strings")
elif FAMILY == "calendar":
    events = data.get("expected_events")
    require(isinstance(events, dict) and events, "calendar events missing")
    require(all(isinstance(event, dict) and isinstance(event.get("duration"), int) and isinstance(event.get("event_id"), int) and isinstance(event.get("min_time"), str) and isinstance(event.get("max_time"), str) and (event.get("constraint") is None or isinstance(event.get("constraint"), str)) for event in events.values()), "invalid calendar event")
elif FAMILY == "regex_count":
    regexes = data.get("verify_regex")
    require(isinstance(regexes, list) and regexes and all(isinstance(value, str) for value in regexes), "regex list missing")
    require(isinstance(data.get("verify_min_matches"), int) and data["verify_min_matches"] >= 0, "invalid match threshold")
    for pattern in regexes:
        re.compile(pattern)
elif FAMILY == "structured":
    require(isinstance(data.get("schema"), dict), "schema missing")
    require(data.get("schema_type") in {"json", "yaml", "toml", "xml", "csv"}, "invalid schema type")
elif FAMILY == "mcqa":
    require(isinstance(data.get("expected_answer"), str) and data["expected_answer"], "expected answer missing")
    require(isinstance(data.get("output_regex", ""), str), "output regex invalid")
    re.compile(data.get("output_regex") or r"Answer\s*:\s*(?!Answer)\s*([A-Za-z0-9])\s*")
elif FAMILY == "math_boxed":
    boxed = isinstance(data.get("expected_answer"), str)
    numeric = isinstance(data.get("expected_value"), (int, float))
    require(boxed or numeric, "math expectation invalid")
    if numeric:
        require(isinstance(data.get("tolerance_abs", 1e-6), (int, float)), "absolute tolerance invalid")
        require(isinstance(data.get("tolerance_rel", 1e-6), (int, float)), "relative tolerance invalid")
        require(data.get("tolerance_abs", 1e-6) >= 0, "absolute tolerance negative")
        require(data.get("tolerance_rel", 1e-6) >= 0, "relative tolerance negative")
elif FAMILY == "reasoning_gym":
    require(isinstance(data.get("answer"), str), "answer invalid")
    metadata = data.get("metadata")
    require(isinstance(metadata, dict) and isinstance(metadata.get("source_dataset"), str) and metadata["source_dataset"], "Reasoning Gym source missing")
else:
    raise ValueError(f"unknown verifier family: {FAMILY}")
