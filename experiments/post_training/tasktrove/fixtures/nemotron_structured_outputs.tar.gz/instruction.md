You will produce a structured response. Write your final answer to `/app/answer.txt`.
Emit a JSON document that validates against the JSON Schema in the task. The verifier parses your answer (optionally unwrapping a ```json fence) and validates it with `jsonschema` Draft 2020-12.

---

Given the following text:

When pairing wine with grilled salmon, a medium-bodied white wine such as Chardonnay or a Pinot Noir is ideal. These wines offer balanced acidity that complements the natural richness of the fish, while their flavor profiles—ranging from crisp citrus and green apple notes in Chardonnay to subtle red berry undertones in Pinot Noir—enhance the dish without overpowering it. The acidity also helps refresh the palate between bites, ensuring a harmonious dining experience.

Acidity in wine plays a critical role in food pairing, particularly with fatty foods. It acts as a palate cleanser, cutting through the mouth-coating richness of fats and preventing a heavy or greasy sensation. This crisp, refreshing quality not only restores balance but also increases the perception of freshness and clarity in each bite, making the meal feel lighter and more enjoyable.

For a cheese platter featuring blue cheeses—such as Roquefort, Gorgonzola, or Stilton—a sweet dessert wine is highly recommended. Wines like Sauternes from Bordeaux or a late-harvest Riesling from Germany are excellent choices. Their high residual sugar content effectively counteracts the intense saltiness and pungent aroma characteristic of blue cheeses, creating a harmonious interplay of sweet and savory. The wine’s complexity and slight honeyed richness also mirror the creamy, bold textures of the cheese, elevating the overall tasting experience.

Tannins in red wines, especially those found in full-bodied varieties like Cabernet Sauvignon, Merlot, or Nebbiolo, interact dynamically with red meat. These polyphenolic compounds bind to proteins in the meat, softening the wine’s astringency and rounding out its structure. This interaction not only enhances the perception of the wine's smoothness but also amplifies the meat’s natural tenderness and depth of flavor, creating a synergistic effect that makes both the wine and the food more satisfying.

When pairing wine with spicy food—such as Indian curries, Thai dishes, or Mexican salsas—it is essential to avoid wines high in alcohol or tannins, as these components can amplify the heat and lead to an unpleasant burn. Instead, wines with a touch of residual sugar, such as off-dry Gewürztraminer or a slightly chilled Rosé, are ideal. The gentle sweetness in these wines tempers the spiciness, while their aromatic profiles (floral, lychee, rose petal in Gewürztraminer; ripe strawberry, cherry in Rosé) provide a refreshing contrast. Their moderate acidity and lower alcohol content also contribute to a cooling sensation on the palate, balancing the heat without overwhelming the dish.

Parse the document and populate the following data model.
I'd like you to format your response as a JSON object matching the provided schema: {'title': 'WineAndFoodPairingRecommendation', 'type': 'object', 'additionalProperties': False, 'required': ['dishName', 'wineType', 'flavorProfile', 'acidityLevel', 'tanninLevel', 'servingTemperature', 'isRecommended'], 'properties': {'dishName': {'type': 'string', 'description': 'The name of the dish being paired with wine.'}, 'wineType': {'type': 'string', 'enum': ['Red', 'White', 'Rosé', 'Sparkling', 'Dessert'], 'description': 'The type of wine recommended for pairing.'}, 'flavorProfile': {'type': 'object', 'additionalProperties': False, 'required': ['primary', 'secondary'], 'properties': {'primary': {'type': 'string', 'description': 'The dominant flavor note in the wine.'}, 'secondary': {'type': 'string', 'description': 'A secondary flavor note in the wine.'}}}, 'acidityLevel': {'type': 'string', 'enum': ['Low', 'Medium', 'High'], 'description': 'The level of acidity in the wine.'}, 'tanninLevel': {'type': 'string', 'enum': ['Low', 'Medium', 'High'], 'description': 'The level of tannins in the wine.'}, 'servingTemperature': {'type': 'number', 'minimum': 0, 'maximum': 30, 'description': 'Serving temperature in degrees Celsius.'}, 'isRecommended': {'type': 'boolean', 'description': 'Whether the pairing is recommended based on flavor compatibility.'}}}

## Submitting your answer (IMPORTANT)
You are a terminal agent. Your chat reply is NOT graded — the grader only reads the file `/app/answer.txt` inside the sandbox. You MUST write your JSON document to `/app/answer.txt` by RUNNING A SHELL COMMAND, e.g. a heredoc:

    cat > /app/answer.txt <<'EOF'
    <your JSON document here>
    EOF

Then confirm it with `cat /app/answer.txt`. An empty or missing `/app/answer.txt` scores 0 regardless of what you wrote in your reply.
