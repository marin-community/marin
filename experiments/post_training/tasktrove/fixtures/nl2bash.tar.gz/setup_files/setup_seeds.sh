#!/usr/bin/env bash
set -euo pipefail
# Auto-generated: copies small seeds and creates large zero-filled files

# Copy small seed files from setup_files
if [ -d /setup_files/seeds ]; then
    cp -a /setup_files/seeds/. /workspace/
fi

