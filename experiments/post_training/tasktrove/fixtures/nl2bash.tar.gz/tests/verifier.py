#!/usr/bin/env python3
from __future__ import annotations

import collections
import json
import pathlib
import re
import sys

REWARD = pathlib.Path("/logs/verifier/reward.txt")
OUTPUT = pathlib.Path("/output/command_capture.txt")
DATA = pathlib.Path("/tests/verifier_data.json")
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ERROR = re.compile(
    r"(?i)\b(?:error|failed|failure|no such file|not found|permission denied|traceback)\b"
)
UNIT = re.compile(r"(?i)\s+(?:bytes?|kb|kib|mb|mib|gb|gib)\s*$")


def _write_reward(score: int) -> None:
    REWARD.parent.mkdir(parents=True, exist_ok=True)
    REWARD.write_text("1" if score else "0")


def _record(line: str) -> str:
    value = ANSI.sub("", line).strip()
    value = re.sub(r"(?<!\S)/workspace/", "", value)
    value = re.sub(r"(?<!\S)\./", "", value)
    value = UNIT.sub("", value)
    return re.sub(r"\s+", " ", value).strip()


def _records(text: str) -> list[str]:
    return [record for line in text.splitlines() if (record := _record(line))]


def _matches(actual: str, expected: str) -> bool:
    expected_records = collections.Counter(_records(expected))
    actual_records = collections.Counter(_records(actual))
    if not expected_records:
        return not actual_records
    missing = expected_records - actual_records
    if missing:
        print(f"missing expected records: {dict(missing)}", file=sys.stderr)
        return False
    extras = actual_records - expected_records
    for record in extras:
        if ERROR.search(record):
            print(f"unexpected error record: {record}", file=sys.stderr)
            return False
    return True


def main() -> int:
    data = json.loads(DATA.read_text())
    expected = data["expected_output"]
    if not isinstance(expected, str):
        raise ValueError("expected_output must be a string")
    if not OUTPUT.exists():
        print(f"missing output: {OUTPUT}", file=sys.stderr)
        return 0
    return int(_matches(OUTPUT.read_text(errors="replace"), expected))


if __name__ == "__main__":
    score = main()
    _write_reward(score)
