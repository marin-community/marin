## Environment Setup (run before starting)

```bash
bash /setup_files/setup_seeds.sh
```

---

# Terminal Automation Request

**TERMINAL ENVIRONMENT**: Ubuntu 24.04 with bash, git, curl, wget, Python 3.10, pip, coreutils, and build-essential.

## Goal
Search for regular files (case-insensitive) with names matching 'fileName*.txt' under the current directory tree, excluding traversal into './ignored_directory', and capture both stdout and stderr into command_capture.txt

## Requirements
- Run the command block you create in a single shell session so that stdout and stderr are both captured.
- The combined output must be written to `/output/command_capture.txt`.
- Do not delete any helper files generated during execution; the verifier inspects them.
- The workspace already contains pre-seeded fixtures copied to `/workspace`; run the command from that directory.


After executing the command, confirm that `/output/command_capture.txt` exists (it may be empty when the requested command is silent). Return a short confirmation summarising the exit status and file size.

## Available Tools
- bash / sh / coreutils
- git, curl, wget
- python3.10 and pip
- build-essential (gcc, make)
