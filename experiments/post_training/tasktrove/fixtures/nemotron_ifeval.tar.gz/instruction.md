You are running in a shell-based sandbox. Read the instruction below and write your final, complete answer text to the file `/app/answer.txt`. The verifier reads ONLY `/app/answer.txt` — anything you print to the terminal or describe in chat is ignored. Your answer.txt must be the raw answer prose itself (not a wrapper, not a summary, not commentary), satisfying every formal constraint in the instruction (paragraph count, forbidden words, letter frequency, formatting markers, ...).

Example of how to save your answer (run this in the shell after composing your response):

```sh
cat > /app/answer.txt <<'EOF'
<your full answer text here>
EOF
```

Verify the file exists and contains your answer with `cat /app/answer.txt` before finishing. If `/app/answer.txt` is missing or empty the task fails.

---

While diying after his fight against the antimonitor, Oliver Queen finds his soul sent back to the start of his journey. Right back to Starling City hospital. First Episode of season 1. This is Oliver Queen realising he has a second chance. Oliver & his mom are in the car. Oliver asked his mom to take him to where he can find Laurel Lance. “Hello Laurel” his voice breaking at the end. Oliver knew that Laurel would be angry & demanding answer. Why had he cheated on her with her sister ? Was she dead then, with her body resting at the bottom of the ocean. He could not tell her she was dead. He would not lye again to her. Please ensure your answer follows these guidelines: There should be 4 paragraphs. Paragraphs and only paragraphs are separated with each other by two new lines as if it was '\n\n' in python. Paragraph 3 must start with word crash and The last word of your response should be the word contest