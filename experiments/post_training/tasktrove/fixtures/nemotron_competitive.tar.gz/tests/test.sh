#!/bin/bash
set -euo pipefail

APP_DIR=${APP_DIR:-/app}
TESTS_DIR=${TESTS_DIR:-/tests}
LOGS_DIR=${LOGS_DIR:-/logs/verifier}
REWARD="$LOGS_DIR/reward.txt"
mkdir -p "$LOGS_DIR"
rm -f "$REWARD"

# Dataset package validation is infrastructure. Any failure leaves no reward.
python3 "$TESTS_DIR/validate_verifier_data.py" "$TESTS_DIR/verifier_data.json" \
  >> "$LOGS_DIR/test-stdout.txt" 2>&1
python3 "$TESTS_DIR/verifier.py" >> "$LOGS_DIR/test-stdout.txt" 2>&1

test -s "$REWARD"
grep -Eq '^(0|1)$' "$REWARD"
