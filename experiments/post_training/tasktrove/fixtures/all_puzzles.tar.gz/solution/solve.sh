#!/usr/bin/env bash
mkdir -p /app
printf '%s\n' 'Defect, Salt, chair, donate' > /app/answer.txt
