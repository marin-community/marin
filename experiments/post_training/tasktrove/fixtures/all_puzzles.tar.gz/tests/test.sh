#!/bin/bash
# --- laion v2 puzzles verifier: deterministic normalized-compare to baked gold ---
set -u
mkdir -p /logs/verifier
echo "0" > /logs/verifier/reward.txt          # DEFAULT-FAIL
echo "0.0" > /logs/verifier/pass_ratio.txt

python3 /tests/compare_answer.py 2>&1 | tee /logs/verifier/test_output.txt
python3 -m pytest /tests/test_state.py -q -p no:cacheprovider >/dev/null 2>&1 || true
exit 0
