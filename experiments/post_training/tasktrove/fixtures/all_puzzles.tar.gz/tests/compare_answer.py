"""Deterministic puzzle answer verifier.

Reads the baked gold + answer type from /tests/gold.json, reads the agent's
answer from /app/answer.txt, normalizes both per answer type, and compares.
Writes reward.txt (1 on match else 0) and pass_ratio.txt.
"""
import json, re, sys
from pathlib import Path

GOLD = Path("/tests/gold.json")
ANS = Path("/app/answer.txt")
REWARD = Path("/logs/verifier/reward.txt")
RATIO = Path("/logs/verifier/pass_ratio.txt")

def first_number(s: str):
    m = re.search(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?", s)
    return float(m.group(0)) if m else None

def all_numbers(s: str):
    return [float(x) for x in re.findall(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?", s)]

def num_close(a, b, atol=5e-3, rtol=1e-3):
    if a is None or b is None:
        return False
    return abs(a - b) <= atol or abs(a - b) <= rtol * max(abs(a), abs(b), 1e-9)

def norm_str(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())

try:
    meta = json.loads(GOLD.read_text())
except Exception as e:
    print(f"FAIL: bad gold.json ({e})"); RATIO.write_text("0.0"); REWARD.write_text("0"); sys.exit(0)

gold = meta["gold"]; atype = meta["answer_type"]; ptype = meta.get("ptype", "?")

try:
    agent = ANS.read_text()
except Exception:
    print(f"FAIL: agent did not write {ANS}"); RATIO.write_text("0.0"); REWARD.write_text("0"); sys.exit(0)

match = False
if atype == "choice":
    match = norm_str(agent) == norm_str(gold)
elif atype == "exact":
    match = norm_str(agent) == norm_str(gold)
elif atype == "number":
    a = first_number(agent); g = first_number(gold)
    match = num_close(a, g, atol=5e-3)
elif atype == "coords":
    ag = all_numbers(agent); gg = all_numbers(gold)
    if len(ag) >= 2 and len(gg) >= 2:
        match = num_close(ag[0], gg[0], atol=5e-3) and num_close(ag[1], gg[1], atol=5e-3)
elif atype == "ordered_list":
    ag = [norm_str(x) for x in agent.split(",") if norm_str(x)]
    gg = [norm_str(x) for x in gold.split(",") if norm_str(x)]
    match = ag == gg

RATIO.write_text("1.0" if match else "0.0")
REWARD.write_text("1" if match else "0")
print(f"[{ptype}] answer_type={atype} match={match}")
print(f"  agent={agent.strip()[:120]!r}")
print(f"  gold ={gold[:120]!r}")
