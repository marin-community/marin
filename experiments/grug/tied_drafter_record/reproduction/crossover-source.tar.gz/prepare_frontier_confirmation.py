"""Freeze fresh-window protocols from the audited frontier selection."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TRIALS_PER_JOB = 3


def confirmation_protocols(selection: dict, template: dict, frozen_at: str) -> dict[str, dict]:
    candidate = selection['passing_candidate']
    if candidate is None:
        raise ValueError('No passing candidate was selected; confirmation requires a revised decision')
    cells = [candidate]
    if selection['failing_neighbor'] is not None:
        cells.append(selection['failing_neighbor'])
    trials = selection['confirmation_trial_ids']
    if trials != list(range(4, 16)):
        raise ValueError('Confirmation must use the predeclared twelve fresh windows per seed')
    protocol = dict(template)
    protocol.pop('partition_of', None)
    protocol.update(
        phase='paired rejection frontier, fresh confirmation',
        frozen_at=frozen_at,
        trial_ids=trials,
        active_experts=[8] + sorted({cell['active_experts'] for cell in cells}, reverse=True),
        horizons=sorted({cell['horizon'] for cell in cells}),
        launch_decision='frontier-confirmation-selection-v1.json',
        confirmation_cells=[{'active_experts': cell['active_experts'], 'horizon': cell['horizon']} for cell in cells],
        comparison=(
            'Matched native and selected draft trajectories run on the same allocation. '
            'Nested horizons share a trajectory. Any extra expert/horizon combinations '
            'are diagnostic only and cannot replace the preselected confirmation cells.'
        ),
        screen_rule=(
            'Fresh confirmation pools all36 unique seed/window pairs per preselected cell. '
            'At most three rejections is <=10%; four or more exceeds10%. '
            'Do not replace a failed candidate after viewing confirmation outcomes.'
        ),
    )
    if max(protocol['horizons']) > 1536 or protocol['checkpoint_step'] != 1024:
        raise ValueError('Confirmation would exceed the frozen optimizer-clock limits')
    evaluation_indices = {
        index
        for trial in trials
        for index in [protocol['check_batch_start'] + trial] + list(range(
            protocol['fresh_batch_start'] + trial * protocol['monitor_batches'],
            protocol['fresh_batch_start'] + (trial + 1) * protocol['monitor_batches'],
        ))
    }
    for trial in trials:
        start = protocol['training_batch_start'] + trial * protocol['training_window_stride']
        if any(start <= index < start + max(protocol['horizons']) for index in evaluation_indices):
            raise ValueError('Training and held-out confirmation windows overlap')
    aggregate_name = 'frontier-confirmation-v1.json'
    result = {aggregate_name: protocol}
    for partition, start in enumerate(range(0, len(trials), TRIALS_PER_JOB)):
        result[f'frontier-confirmation-p{partition}-v1.json'] = protocol | {
            'trial_ids': trials[start:start + TRIALS_PER_JOB], 'partition_of': aggregate_name,
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', type=Path, default=ROOT / 'frontier-confirmation-selection-v1.json')
    args = parser.parse_args()
    selection = json.loads(args.selection.read_text())
    rule_path = ROOT / 'frontier-analysis-protocol-v1.json'
    if selection['rule_sha256'] != hashlib.sha256(rule_path.read_bytes()).hexdigest():
        raise ValueError('Selection rule changed')
    for source in selection['sources']:
        if hashlib.sha256((ROOT / source['path']).read_bytes()).hexdigest() != source['sha256']:
            raise ValueError('Screen summary changed after selection')
    template = json.loads((ROOT / 'frontier-long-v1.json').read_text())
    for path, expected in template['implementation_sha256'].items():
        if hashlib.sha256((ROOT / 'marin' / path).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Frozen runtime changed: {path}')
    protocols = confirmation_protocols(selection, template, datetime.now(timezone.utc).isoformat())
    destinations = [directory / name for directory in (ROOT, ROOT / 'marin/experiments/grug') for name in protocols]
    if any(path.exists() for path in destinations):
        raise FileExistsError('A confirmation protocol already exists; do not overwrite a frozen phase')
    for path in destinations:
        with path.open('x') as output:
            output.write(json.dumps(protocols[path.name], indent=2, allow_nan=False) + '\n')
    print(json.dumps({'protocols': list(protocols), 'trials_per_cell': 36, 'jobs': 12, 'maximum_concurrent_h100': 96}))


if __name__ == '__main__':
    main()
