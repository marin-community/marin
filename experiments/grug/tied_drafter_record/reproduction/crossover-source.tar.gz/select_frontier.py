"""Freeze confirmation candidates using the predeclared frontier ranking rule."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics


EXPERT_ORDER = [6, 4, 2, 1]
HORIZON_ORDER = [64, 128, 256, 512, 1024, 1536]


def select_cells(cells):
    passing = [cell for cell in cells if cell['rejected'] / cell['trials'] <= 0.1]
    if not passing:
        return None, None
    selected = min(
        passing,
        key=lambda cell: (
            cell['median_seconds_per_executed_update'], cell['active_experts'], -cell['horizon']
        ),
    )
    failing = [cell for cell in cells if cell['rejected'] / cell['trials'] > 0.1]
    if not failing:
        return selected, None
    neighbor = min(
        failing,
        key=lambda cell: (
            abs(EXPERT_ORDER.index(cell['active_experts']) - EXPERT_ORDER.index(selected['active_experts']))
            + abs(HORIZON_ORDER.index(cell['horizon']) - HORIZON_ORDER.index(selected['horizon'])),
            cell['active_experts'], -cell['horizon'],
        ),
    )
    return selected, neighbor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summaries', type=Path, nargs='+')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cells = {}
    sources = []
    for path in args.summaries:
        summary = json.loads(path.read_text())
        if summary['status'] != 'audited':
            raise ValueError('Only complete audited summaries may select confirmation candidates')
        for source in summary['sources'] + summary['cached_native_sources']:
            if hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() != source['sha256']:
                raise ValueError('Raw source changed after analysis')
        sources.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        for cell in summary['cells']:
            if cell['active_experts'] == 8:
                continue
            key = (cell['active_experts'], cell['horizon'])
            if key in cells:
                raise ValueError(f'Duplicate screened cell: {key}')
            records = [r for r in summary['records'] if (r['active_experts'], r['horizon']) == key]
            pairs = [(r['seed'], r['trial']) for r in records]
            expected = {(seed, trial) for seed in range(3) for trial in range(4)}
            if len(pairs) != 12 or set(pairs) != expected:
                raise ValueError('Selection requires all twelve unique screen trials')
            rejected = sum(not r['accepted'] for r in records)
            speed = statistics.median(r['update_seconds'] / (r['failure_step'] or r['horizon']) for r in records)
            if rejected != cell['rejected'] or speed != cell['median_seconds_per_executed_update']:
                raise ValueError('Summary ranking does not match per-trial evidence')
            cells[key] = cell
    selected, neighbor = select_cells(list(cells.values()))
    rule_path = Path(__file__).with_name('frontier-analysis-protocol-v1.json')
    result = {
        'frozen_at': datetime.now(timezone.utc).isoformat(),
        'rule_sha256': hashlib.sha256(rule_path.read_bytes()).hexdigest(),
        'sources': sources,
        'passing_candidate': selected,
        'failing_neighbor': neighbor,
        'confirmation_trial_ids': list(range(4, 16)),
        'scope': 'Observed screen ranking; fresh confirmation pending. This is not a production-speed ranking.',
    }
    with args.output.open('x') as output:
        output.write(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
