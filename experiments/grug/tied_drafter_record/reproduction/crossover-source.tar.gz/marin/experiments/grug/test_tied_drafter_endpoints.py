# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

from dataclasses import dataclass, replace

import jax
import jax.numpy as jnp
import numpy as np
import optax

from experiments.grug.tied_drafter_endpoints import device_snapshot, identical_arrays, restore_snapshot


@jax.tree_util.register_dataclass
@dataclass(frozen=True)
class OptimizerState:
    weights: jax.Array
    moments: optax.OptState
    step: jax.Array
    routing: jax.Array


def test_prefix_snapshot_survives_donated_updates_and_preserves_continuation():
    optimizer = optax.adam(0.1)
    weights = jnp.array([2.0, -1.0])
    state = OptimizerState(weights, optimizer.init(weights), jnp.array(0), jnp.array([0.2, -0.2]))
    leaves, tree = jax.tree.flatten(state)
    shardings = [x.sharding for x in leaves]

    @jax.jit(donate_argnums=(0,))
    def advance(arrays, target):
        current = jax.tree.unflatten(tree, arrays)
        gradient = jax.grad(lambda w: jnp.sum((w - target) ** 2))(current.weights)
        updates, moments = optimizer.update(gradient, current.moments, current.weights)
        current = replace(
            current,
            weights=optax.apply_updates(current.weights, updates),
            moments=moments,
            step=current.step + 1,
            routing=current.routing + 0.03,
        )
        return jax.tree.leaves(current)

    initial = device_snapshot(leaves)
    prefix = advance(restore_snapshot(initial, shardings), jnp.array([0.0, 1.0]))
    saved_prefix = device_snapshot(prefix)
    endpoint = advance(prefix, jnp.array([1.0, 0.0]))
    endpoint = advance(endpoint, jnp.array([-1.0, 2.0]))
    # Shortening the block must resume exactly from the saved prefix, including
    # Adam moments, step clock and routing state despite later buffer donation.
    resumed = advance(restore_snapshot(saved_prefix, shardings), jnp.array([1.0, 0.0]))
    reference = advance(restore_snapshot(initial, shardings), jnp.array([0.0, 1.0]))
    reference = advance(reference, jnp.array([1.0, 0.0]))
    for actual, expected in zip(resumed, reference, strict=True):
        np.testing.assert_array_equal(actual, expected)
    assert bool(identical_arrays(resumed, reference))
    assert not bool(identical_arrays(resumed, endpoint))
    assert int(jax.tree.unflatten(tree, resumed).step) == 2
    assert int(jax.tree.unflatten(tree, endpoint).step) == 3
    rejected = restore_snapshot(initial, shardings)
    for actual, expected in zip(rejected, initial, strict=True):
        np.testing.assert_array_equal(actual, expected)
