# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

from dataclasses import replace

import equinox as eqx
import jax
import jax.numpy as jnp
import jmp
import numpy as np
import optax
import pytest
from levanter.data.text.examples import GrugLmExample
from levanter.grug.attention import AttentionMask

from experiments.grug.fast_track.model import Transformer
from experiments.grug.fast_track.train import GrugTrainState
from experiments.grug.noise_belay.validation_cases import make_small_model
from experiments.grug.tied_drafter.coordinates import (
    DraftRecipe,
    coordinate_map,
    draft_config,
    lift_displacement,
    restrict_model,
)
from experiments.grug.tied_drafter.runtime import draft_training_state, sequence_losses
from experiments.grug.tied_drafter.transactions import commit_parameters, snapshot_state


@pytest.fixture(scope="module")
def hero():
    return make_small_model()


@pytest.mark.parametrize("recipe", list(DraftRecipe))
def test_stale_displacement_updates_only_selected_current_coordinates(hero, recipe):
    model, mesh = hero
    with jax.set_mesh(mesh):
        template = eqx.filter_eval_shape(Transformer.init, draft_config(model.config, recipe), key=jax.random.PRNGKey(1))
        mapping = coordinate_map(model, template)
        start = restrict_model(model, template, mapping)
        end = jax.tree.map(lambda x: x + 0.125, start)
        current = jax.tree.map(lambda x: x - 0.25, model)
        result = eqx.filter_jit(lift_displacement)(current, start, end, mapping, scale=0.5)
        for original, output, entry in zip(jax.tree.leaves(current), jax.tree.leaves(result), mapping, strict=True):
            expected = np.asarray(original).copy()
            if entry.propose:
                expected[tuple(slice(0, n) for n in entry.draft_shape)] += 0.0625
            np.testing.assert_allclose(output, expected, atol=2e-7, rtol=2e-7)
        # The source model is a stale snapshot; applying the jump must not reset
        # untouched current coordinates to that snapshot's older values.
        for old, now in zip(jax.tree.leaves(model), jax.tree.leaves(current), strict=True):
            np.testing.assert_allclose(now, old - 0.25, atol=0, rtol=0)


def test_full_width_map_preserves_forward_and_gradient(hero):
    model, mesh = hero
    with jax.set_mesh(mesh):
        mapping = coordinate_map(model, model)
        tied = restrict_model(model, model, mapping)
        tokens = jax.random.randint(jax.random.PRNGKey(13), (1, 128), 0, model.config.vocab_size)
        objective = eqx.filter_jit(eqx.filter_value_and_grad(lambda m: jnp.mean(m(tokens)[0].astype(jnp.float32) ** 2)))
        loss, gradient = objective(model)
        tied_loss, tied_gradient = objective(tied)
        np.testing.assert_array_equal(loss, tied_loss)
        for a, b in zip(jax.tree.leaves(gradient), jax.tree.leaves(tied_gradient), strict=True):
            np.testing.assert_array_equal(a, b)


def test_rejection_snapshot_survives_donation_and_commit_keeps_optimizer_state(hero):
    params, mesh = hero
    with jax.set_mesh(mesh):
        optimizer = optax.adam(0.001)
        state = GrugTrainState(
            step=jnp.array(7),
            params=params,
            master_params=None,
            ema_params=jax.tree.map(lambda x: x.copy(), params),
            opt_state=optimizer.init(params),
            pending_qb_betas=jnp.zeros((params.config.num_layers, params.config.num_experts)),
        )
        preserved = snapshot_state(state)
        mutate = jax.jit(lambda s: replace(s, params=jax.tree.map(lambda x: x + 0.25, s.params)), donate_argnums=(0,))
        changed = mutate(snapshot_state(state))
        jax.block_until_ready(changed)
        # Rejection keeps the complete preserved state, including moments and EMA.
        for a, b in zip(jax.tree.leaves(state), jax.tree.leaves(preserved), strict=True):
            np.testing.assert_array_equal(a, b)
        accepted = commit_parameters(preserved, changed.params)
        np.testing.assert_array_equal(accepted.step, state.step)
        for field in ("opt_state", "ema_params", "pending_qb_betas"):
            for a, b in zip(
                jax.tree.leaves(getattr(accepted, field)), jax.tree.leaves(getattr(state, field)), strict=True
            ):
                np.testing.assert_array_equal(a, b)
        for a, b in zip(jax.tree.leaves(accepted.params), jax.tree.leaves(params), strict=True):
            np.testing.assert_allclose(a, b + 0.25, atol=0, rtol=0)


@pytest.mark.parametrize("recipe", list(DraftRecipe))
def test_narrow_draft_learns_a_fixed_batch(hero, recipe):
    model, mesh = hero
    with jax.set_mesh(mesh):
        template = eqx.filter_eval_shape(Transformer.init, draft_config(model.config, recipe), key=jax.random.PRNGKey(1))
        mapping = coordinate_map(model, template)
        draft = restrict_model(model, template, mapping)
        tokens = jax.random.randint(jax.random.PRNGKey(17), (1, 128), 0, model.config.vocab_size)
        weights = jnp.ones(tokens.shape).at[:, -1].set(0)
        objective = eqx.filter_jit(eqx.filter_value_and_grad(lambda m: m.next_token_loss(tokens, weights)))
        before, gradient = objective(draft)
        updated = jax.tree.map(lambda w, g: w - 0.0001 * g, draft, gradient)
        after, _ = objective(updated)
        assert np.isfinite(float(after)) and float(after) < float(before)


def test_draft_optimizer_advances_independently_of_snapshot(hero):
    model, mesh = hero
    with jax.set_mesh(mesh):
        template = eqx.filter_eval_shape(
            Transformer.init, draft_config(model.config, DraftRecipe.WIDTH_QUARTER), key=jax.random.PRNGKey(1)
        )
        draft = restrict_model(model, template, coordinate_map(model, template))
        leaves, structure, update, _ = draft_training_state(draft, learning_rate=0.001, z_loss_weight=0.0001)
        original = [np.asarray(x).copy() for x in jax.tree.leaves(draft)]
        tokens = jax.random.randint(jax.random.PRNGKey(17), (1, 128), 0, model.config.vocab_size)
        batch = GrugLmExample(tokens, jnp.ones(tokens.shape).at[:, -1].set(0), AttentionMask(is_causal=True))
        copied = [jax.device_put(x, x.sharding, may_alias=False) for x in leaves]
        updated, metrics, _ = update(copied, batch)
        state = jax.tree.unflatten(structure, updated)
        assert int(state.step) == 1 and np.isfinite(float(metrics["train/loss"]))
        assert any(not np.array_equal(x, y) for x, y in zip(original, jax.tree.leaves(state.params), strict=True))
        for expected, actual in zip(original, jax.tree.leaves(draft), strict=True):
            np.testing.assert_array_equal(expected, actual)


def test_sequence_verifier_matches_weighted_native_loss(hero):
    model, mesh = hero
    with jax.set_mesh(mesh):
        tokens = jax.random.randint(jax.random.PRNGKey(41), (2, 128), 0, model.config.vocab_size)
        weights = jnp.ones(tokens.shape).at[0, 32:].set(0).at[1, ::2].set(0.25).at[:, -1].set(0)
        batch = GrugLmExample(tokens, weights, AttentionMask(is_causal=True))
        mp = jmp.get_policy("params=float32,compute=float32,output=float32")
        losses, counts = eqx.filter_jit(sequence_losses)(model, batch, mp)
        expected = eqx.filter_jit(lambda m: m.next_token_loss(tokens, weights))(model)
        combined = jnp.sum(losses * counts) / jnp.sum(counts)
        np.testing.assert_allclose(combined, expected, rtol=2e-6, atol=2e-6)
        np.testing.assert_array_equal(counts, jnp.sum(weights, axis=-1))
