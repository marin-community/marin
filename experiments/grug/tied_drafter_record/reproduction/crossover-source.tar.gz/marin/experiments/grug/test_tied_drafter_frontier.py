# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

import io
from dataclasses import dataclass, replace

import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np
import optax
from jax.sharding import AxisType, Mesh, NamedSharding
from jax.sharding import PartitionSpec as P

from experiments.grug.tied_drafter_latency import restored_leaf


@jax.tree_util.register_dataclass
@dataclass(frozen=True)
class CheckpointState:
    weights: jax.Array
    moments: optax.OptState
    step: jax.Array
    routing: jax.Array


def test_checkpoint_round_trip_preserves_optimizer_continuation():
    optimizer = optax.adam(0.02)
    mesh = Mesh(
        np.asarray(jax.devices()[:1]).reshape(1, 1, 1, 1),
        ("replica_dcn", "data", "expert", "model"),
        axis_types=(AxisType.Explicit,) * 4,
    )
    with jax.set_mesh(mesh):
        weights = jnp.array([1.5, -0.4])
        state = CheckpointState(weights, optimizer.init(weights), jnp.array(0), jnp.array([0.2, -0.2]))
        state = jax.tree.map(lambda x: jax.device_put(x, NamedSharding(mesh, P())), state)

        @jax.jit
        def advance(current, target):
            gradient = jax.grad(lambda w: jnp.sum((w - target) ** 2))(current.weights)
            updates, moments = optimizer.update(gradient, current.moments, current.weights)
            return replace(
                current,
                weights=optax.apply_updates(current.weights, updates),
                moments=moments,
                step=current.step + 1,
                routing=current.routing + 0.03,
            )

        for target in [0.0, 1.0, -1.0, 2.0, 0.5, -0.5, 1.5]:
            state = advance(state, target)
        template = jax.tree.map(lambda x: jax.ShapeDtypeStruct(x.shape, x.dtype, sharding=x.sharding), state)
        stream = io.BytesIO()
        eqx.tree_serialise_leaves(stream, state)
        stream.seek(0)
        restored = eqx.tree_deserialise_leaves(
            stream, template, filter_spec=lambda stream, leaf: restored_leaf(stream, leaf, mesh)
        )
        assert stream.read(1) == b""
        for actual, expected in zip(jax.tree.leaves(restored), jax.tree.leaves(state), strict=True):
            np.testing.assert_array_equal(actual, expected)
        resumed = advance(restored, -2.0)
        reference = advance(state, -2.0)
        for actual, expected in zip(jax.tree.leaves(resumed), jax.tree.leaves(reference), strict=True):
            np.testing.assert_array_equal(actual, expected)
