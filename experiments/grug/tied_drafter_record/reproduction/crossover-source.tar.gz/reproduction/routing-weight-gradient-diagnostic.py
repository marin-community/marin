"""Measure the selected routing-weight derivative in an isolated CPU calculation."""

import hashlib
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
EPSILON = 1e-9


def selected_weights(logits):
    values = jnp.sqrt(jnp.maximum(jax.nn.softplus(logits), 1e-30))
    return (values * (2.5 / (values.sum() + EPSILON))).astype(jnp.bfloat16)


def main():
    reference = json.loads((ROOT / 'marin/experiments/grug/noise_belay/candidate11-reference.json').read_text())['config']['model']
    assert reference['routing_renorm_sum'] == 2.5
    assert reference['router_combine'] == 'SQRT_SOFTPLUS_RENORM'
    cases = []
    for active in [1, 2, 8]:
        for offset in [-10.0, -2.0, 0.0, 2.0, 10.0]:
            logits = jnp.full((1,), offset, dtype=jnp.float32) if active == 1 else jnp.linspace(offset - 1, offset + 1, active, dtype=jnp.float32)
            jacobian = jax.jit(jax.jacrev(selected_weights))(logits)
            cases.append({
                'active_routed_experts': active,
                'logit_center': offset,
                'weights': np.asarray(selected_weights(logits), dtype=np.float32).tolist(),
                'weight_jacobian_max_abs': float(jnp.max(jnp.abs(jacobian))),
                'weight_jacobian_frobenius': float(jnp.linalg.norm(jacobian)),
            })
    record = {
        'scope': 'CPU algebra diagnostic of the selected routing-weight formula, not measured full-model gradients or a causal attribution of the training outcome. No GPU recipe changed.',
        'formula': 'g=sqrt(max(softplus(logit),1e-30)); weight=2.5*g/(sum(g)+1e-9), then BF16 cast.',
        'interpretation': 'With one selected expert and negligible epsilon, the combination weight is constant 2.5 and its logit gradient vanishes. Epsilon and floating-point cancellation leave small residuals. Top-k index selection is discrete; balancing biases, features, stored optimizer moments and weight decay may still change routes or router parameters.',
        'jax_version': jax.__version__,
        'diagnostic_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'model_sha256': hashlib.sha256((ROOT / 'marin/experiments/grug/fast_track/model.py').read_bytes()).hexdigest(),
        'configuration': {key: reference[key] for key in ['router_combine', 'routing_renorm_sum', 'num_shared_experts', 'moe_dense_router_grad', 'simbal_loss_weight', 'erc_loss_weight']},
        'cases': cases,
    }
    (ROOT / 'measurements/frontier-routing-weight-gradient-diagnostic.json').write_text(json.dumps(record, indent=2) + '\n')
    for active in [1, 2, 8]:
        print(active, max(c['weight_jacobian_max_abs'] for c in cases if c['active_routed_experts'] == active))


if __name__ == '__main__':
    main()
