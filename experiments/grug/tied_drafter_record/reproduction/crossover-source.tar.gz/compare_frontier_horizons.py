"""Compare measured native1024 and draft1536 endpoints on matched windows."""

import hashlib
import json
from pathlib import Path
import statistics


def main() -> None:
    root = Path(__file__).resolve().parent
    path = root / 'measurements/frontier-long-summary.json'
    summary = json.loads(path.read_text())
    if summary['status'] != 'audited':
        raise ValueError('Cross-horizon comparison requires an audited long-horizon phase')
    lookup = {(r['seed'], r['trial'], r['active_experts'], r['horizon']): r for r in summary['records']}
    rows = []
    for seed in range(3):
        for trial in range(4):
            native = lookup[seed, trial, 8, 1024]
            draft = lookup[seed, trial, 1, 1536]
            rows.append({
                'seed': seed, 'trial': trial, 'native_horizon': 1024, 'draft_horizon': 1536,
                'native_fresh_gain': native['fresh_gain'], 'draft_fresh_gain': draft['fresh_gain'],
                'native_loss_advantage': native['fresh_gain'] - draft['fresh_gain'],
                'native_update_seconds': native['update_seconds'],
                'draft_update_seconds': draft['update_seconds'],
                'draft_single_horizon_seconds': draft['single_horizon_execution_seconds'],
                'draft_update_cost_over_native': draft['update_seconds'] / native['update_seconds'],
                'draft_minimal_cost_over_native': draft['single_horizon_execution_seconds'] / native['update_seconds'],
                'native_lower_loss_and_less_update_time': (
                    native['fresh_gain'] > draft['fresh_gain'] and native['update_seconds'] < draft['update_seconds']
                ),
            })
    result = {
        'scope': (
            'Descriptive cross-horizon comparison on the same twelve seed/windows, starting checkpoint '
            'and fresh evaluation batches, with native and draft on the same allocation. '
            'This does not estimate matched-target convergence or change confirmation selection.'
        ),
        'source': str(path.relative_to(root)),
        'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'pairs': len(rows),
        'native_dominates_pairs': sum(r['native_lower_loss_and_less_update_time'] for r in rows),
        'mean_native_loss_advantage': statistics.mean(r['native_loss_advantage'] for r in rows),
        'median_draft_update_cost_over_native': statistics.median(r['draft_update_cost_over_native'] for r in rows),
        'median_draft_minimal_cost_over_native': statistics.median(r['draft_minimal_cost_over_native'] for r in rows),
        'rows': rows,
    }
    (root / 'measurements/frontier-long-cross-horizon-comparison.json').write_text(
        json.dumps(result, indent=2, allow_nan=False) + '\n'
    )


if __name__ == '__main__':
    main()
