"""Verify completed frontier W&B records against the preserved raw endpoints."""

import argparse
from datetime import datetime
import json
from pathlib import Path
from urllib.parse import urlparse

import wandb


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--pod-record', type=Path, required=True)
    parser.add_argument('--allocation-start', required=True, help='Observed PodScheduled=True timestamp for this attempt')
    args = parser.parse_args()
    raw = json.loads(args.input.read_text())
    parts = urlparse(raw['wandb_url']).path.strip('/').split('/')
    if len(parts) != 4 or parts[2] != 'runs':
        raise ValueError('Unexpected W&B run URL')
    run = wandb.Api().run('/'.join([parts[0], parts[1], parts[3]]))
    if run.state != 'finished' or run.summary.get('completed') is not True:
        raise ValueError(f'W&B run is not complete: {run.state}')
    if raw['status'] != 'complete' or run.summary['endpoints'] != len(raw['endpoints']):
        raise ValueError('W&B and raw completion counts disagree')
    keys = ['_timestamp', 'trial', 'active_experts', 'horizon', 'accepted', 'update_seconds']
    history = list(run.scan_history(keys=keys))
    if len(history) != len(raw['endpoints']):
        raise ValueError('Missing or duplicate W&B endpoint observations')
    pod = json.loads(args.pod_record.read_text())
    created = datetime.fromisoformat(pod['created']).timestamp()
    allocation_start = datetime.fromisoformat(args.allocation_start).timestamp()
    finished = max(datetime.fromisoformat(c['state']['terminated']['finishedAt']).timestamp() for c in pod['containers'])
    if pod['phase'] != 'Succeeded' or any(c['state']['terminated']['exitCode'] for c in pod['containers']):
        raise ValueError('Pod did not complete successfully')
    first_container_start = min(
        datetime.fromisoformat(c['state']['terminated']['startedAt']).timestamp() for c in pod['containers']
    )
    if not created <= allocation_start <= first_container_start <= finished:
        raise ValueError('Allocation timestamp is outside the pod startup interval')
    for row, endpoint in zip(history, raw['endpoints'], strict=True):
        for key in keys[1:]:
            if row[key] != endpoint[key]:
                raise ValueError(f'W&B differs from raw endpoint field: {key}')
        if not allocation_start <= row['_timestamp'] <= finished:
            raise ValueError('Endpoint timestamp outside allocated pod lifetime')
        row['attempt_allocated_gpu_hours'] = 8 * (row['_timestamp'] - allocation_start) / 3600
    args.output.write_text(json.dumps({
        'pod_created': pod['created'], 'url': raw['wandb_url'], 'state': run.state,
        'completed': True, 'created_at': run.created_at, 'history': history,
        'allocation_start': args.allocation_start,
        'queued_seconds': allocation_start - created,
        'allocated_gpu_hours': 8 * (finished - allocation_start) / 3600,
        'pod_lifetime_gpu_hours_upper_bound': 8 * (finished - created) / 3600,
        'accounting_basis': (
            'Eight GPUs from observed pod scheduling to last container completion. '
            'Queue time is excluded; prior preempted attempts are charged separately in the resource ledger. '
            'This is an allocation-duration estimate, not a billing measurement.'
        ),
    }, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    main()
