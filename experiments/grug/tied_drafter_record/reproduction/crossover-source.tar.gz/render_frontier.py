"""Render audited rejection-frontier phases without extrapolating untested cells."""

import argparse
import html
import json
from pathlib import Path


def number(value, digits=4):
    return 'Not finite' if value is None else f'{value:.{digits}f}'


def phase_section(path, root):
    summary = json.loads(path.read_text())
    if summary['status'] != 'audited':
        raise ValueError('Report requires an audited phase')
    rows = []
    for cell in summary['cells']:
        rows.append(
            f'<tr><td>{cell["active_experts"]}</td><td>{cell["horizon"]}</td>'
            f'<td>{cell["rejected"]}/{cell["trials"]} ({100*cell["rejection_rate"]:.1f}%)</td>'
            f'<td>{number(cell["mean_fresh_gain"])}</td>'
            f'<td>{number(cell["mean_fresh_gain_vs_native"])}</td>'
            f'<td>{number(cell["median_update_time_ratio"],3)}</td>'
            f'<td>{number(cell["median_single_horizon_cost_ratio"],3)}</td>'
            f'<td>{cell["nonfinite_fresh"]}</td></tr>'
        )
    sources = []
    for source in summary['sources']:
        raw_path = Path(source['path']).resolve()
        raw = json.loads(raw_path.read_text())
        sources.append(
            f'<li>Seed {source["seed"]}, trials {html.escape(str(raw["protocol"]["trial_ids"]))}: '
            f'<a href="{html.escape(str(raw_path.relative_to(root)))}">raw measurements</a>, '
            f'<a href="{html.escape(source["wandb_url"])}">W&amp;B</a>.</li>'
        )
    relative = path.resolve().relative_to(root)
    titles = {
        'frontier-screen-summary': 'Initial screen: six, four, and two active experts',
        'frontier-k1-summary': 'One active expert, using previously measured native controls',
        'frontier-long-summary': 'Longer blocks with native controls on the same allocation',
        'frontier-confirmation-summary': 'Fresh confirmation of the selected settings',
    }
    return f'''<h3>{html.escape(titles.get(path.stem, path.stem))}</h3>
<table><thead><tr><th>Active routed experts</th><th>Proposed updates</th><th>Rejected proposals</th>
<th>Fresh gain from start</th><th>Fresh gain vs native</th><th>Update cost / native</th>
<th>Single-horizon cost / native</th><th>Nonfinite fresh endpoints</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table>
<figure><img src="{html.escape(str(relative.with_suffix('.svg')))}" alt="Rejection counts and fresh loss differences for each tested expert count and update horizon"></figure>
<details><summary>Phase evidence</summary><p><a href="{html.escape(str(relative))}">Audited summary and per-trial records</a>.</p><ul>{''.join(sources)}</ul></details>'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summaries', type=Path, nargs='+')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--selection', type=Path)
    parser.add_argument('--conclusion', type=Path, required=True, help='Reviewed evidence-specific opening HTML')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    phases = ''.join(phase_section(path, root) for path in args.summaries)
    selection = ''
    if args.selection:
        chosen = json.loads(args.selection.read_text())
        candidate = chosen['passing_candidate']
        neighbor = chosen['failing_neighbor']
        if candidate:
            selection = f'<p>The screen selected {candidate["active_experts"]} active experts at {candidate["horizon"]} updates by the lowest median measured update time per executed update among passing settings.'
            if neighbor:
                selection += f' The nearest observed failing neighbor was {neighbor["active_experts"]} experts at {neighbor["horizon"]} updates.'
            else:
                selection += ' No failing neighbor was observed within the tested settings.'
            selection += ' Selection was fixed before the fresh confirmation windows. This ranks execution speed subject to the relaxed acceptance condition; it does not rank learning efficiency.</p>'
    section = f'''<section id="frontier-results"><h2>Longer blocks and faster drafters: the rejection boundary</h2>
{args.conclusion.read_text()}
<p>These experiments reduce the number of active routed experts per token while retaining the original model’s complete weight coordinates. The full reference has six transformer layers, 512 routed experts per layer, eight active routed experts per token, one always-active shared expert per layer, and about 1.03B parameters. The shared expert is unchanged in every drafter. A drafter takes ordinary gradient-based Muon/Adam-family updates with fewer active routed experts. Each token selects the highest current router scores after adding expert-balancing biases. Selected combination weights use the native square-root-softplus transformation and renormalize to the unchanged total weight 2.5. This keeps the total combination weight fixed while changing the selected expert mixture.</p>
<p>A proposal block is a sequence of optimizer updates, distinct from the transformer layers. Its endpoint is evaluated with eight active routed experts. Evaluation uses current weights, rather than the preserved exponential moving average. It also applies the pending router-bias adjustments computed by the draft updates to balance expert usage, as the next training update would. Rejection in this screen classifies an endpoint; it does not trigger a measured rollback or shorter-prefix rescue. A passing shorter prefix never changes the full proposal’s rejection count.</p>
<p>Each trial restores a complete native checkpoint at optimizer step 1,024, including optimizer moments, the exponential moving average of weights, and routing state. Different trial windows use new training, check, and monitoring batches. The optimizer clock still starts at 1,024; it does not take the large numerical index of the data window. The native schedule remains 2,698 steps, so the longest allowed 1,536-update proposal ends at step 2,560. This screen branches independently from three checkpoints. It does not establish rejection rates during a long sequence of accepted interventions.</p>
<details><summary>One routed expert changes a router-gradient path</summary><p>With one selected expert, its normalized combination weight is 2.5g/(g + 10⁻⁹), where g is the positive transformed router score. When g is much larger than the stabilizer, this weight is nearly constant. An isolated CPU calculation of this formula found a maximum absolute weight derivative of 2.06 × 10⁻⁷ for one expert, compared with 0.247 for two and 0.197 for eight, over the specified test logits. Expert weights and shared layers still receive gradients; routing choices can still change with token representations and balancing biases. This identifies a changed learning mechanism, but it is not a measurement of full-model gradient norms or a causal explanation of the observed loss gap. <a href="measurements/frontier-routing-weight-gradient-diagnostic.json">Cases and scope</a> · <a href="reproduction/routing-weight-gradient-diagnostic.py">CPU reproduction</a>.</p></details>
<p>Acceptance requires a full-model check-loss decrease from the proposal’s starting checkpoint greater than max(10⁻⁶, twice the range of three repeated starting evaluations). It does not require matching native training’s endpoint loss. One check batch contains 128 sequences of length 4,096. Four separate monitoring batches measure fresh loss and do not select endpoints. Every declared prefix is checked even if a shorter prefix fails. Draft numerical divergence rejects all unreached endpoints and is recorded separately; a native divergence aborts the experiment for diagnosis. Runtime exceptions are not counted as ordinary model rejections.</p>
<p>The initial screen uses four windows per initialization seed: twelve trials per setting. One rejection is 8.3%; two are 16.7%. Fresh confirmation uses twelve new windows per seed: 36 trials per selected setting. Three rejections are 8.3%; four are 11.1%. These are observed rates. Shared checkpoints and shared data windows make the trials dependent, so the threshold is not a population reliability guarantee.</p>
{selection}
<h3>How to read quality and cost</h3>
<p>Positive fresh gain means lower token-weighted loss; negative means higher loss. Gain from start measures whether the proposal learned anything useful for the full model. Gain versus native compares it with full-model training on exactly the same training batches. A low rejection rate alone cannot establish a pretraining speedup. Both fresh-gain columns average all finite endpoints in each setting, including rejected proposals. Nonfinite endpoints remain in the rejection denominator and their excluded fresh-loss counts are shown explicitly.</p>
<p>Cost columns are medians of paired per-trial ratios. Update cost includes synchronized draft execution. Single-horizon cost adds its initial state copy, starting check forward, and candidate check forward; the denominator is matched native update execution. Earlier prefix evaluations, calibration, fresh monitoring, data loading, checkpoint restore, compilation, and validation are research overhead recorded separately. All generated updates are charged, including rejected proposals. Early numerical failures have no equal-horizon cost ratio. Reused native references must match checkpoint identity, source, schedule, seed, data windows, and token fingerprints. The one-expert screen reuses native measurements from separate GPU allocations, so its timing ratios can include machine-to-machine variation. Whole-job H100 allocation is recorded in the resource ledger.</p>
{phases}
<p>Protocols: <a href="frontier-screen-v1.json">initial screen and expansion rules</a>, <a href="frontier-analysis-protocol-v1.json">candidate selection and confirmation</a>. Reproduction: <a href="marin/experiments/grug/tied_drafter_frontier.py">driver</a>, <a href="analyze_frontier.py">auditor and figures</a>, <a href="select_frontier.py">selection implementation</a>, <a href="measurements/resource-ledger.json">resource ledger</a>, <a href="reproduction/frontier-final-source.tar.gz">final source archive</a>, <a href="reproduction/frontier-final-source-manifest.json">archive manifest and restore instructions</a>.</p>
</section>'''
    args.output.write_text(section)


if __name__ == '__main__':
    main()
