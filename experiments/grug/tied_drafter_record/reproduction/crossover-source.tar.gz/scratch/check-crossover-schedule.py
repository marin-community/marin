import json,hashlib
from pathlib import Path
import draccus
import jax
import jax.numpy as jnp
import numpy as np
from experiments.grug.fast_track.optimizer import GrugMoeMuonHConfig, _power_decay_schedule
from levanter.optim.config import _convert_frac_or_steps
r=Path('experiments/grug/noise_belay/candidate11-reference.json')
c=json.loads(r.read_text())['config']; o=draccus.decode(GrugMoeMuonHConfig,c['optimizer']);n=c['trainer']['trainer']['num_train_steps']
assert o.muonh_decay_power==0.7 and o.muonh_power_cool is None and o.lr_schedule=='cosine'
muon=_power_decay_schedule(o.learning_rate,o.learning_rate*o.min_lr_ratio,_convert_frac_or_steps(o.warmup,n),n,o.muonh_decay_power)
adam=o.lr_scheduler(n,override_lr=o.adam_lr)
steps=jnp.arange(5121);a=np.asarray(jax.vmap(adam)(steps));m=np.asarray(jax.vmap(muon)(steps))
assert np.isfinite(a).all() and np.isfinite(m).all()
np.testing.assert_allclose(a[n:],o.adam_lr*o.min_lr_ratio,rtol=1e-6,atol=0)
np.testing.assert_allclose(m[n:],o.learning_rate*o.min_lr_ratio,rtol=1e-6,atol=0)
assert np.all(np.diff(a[1024:])<=1e-8) and np.all(np.diff(m[1024:])<=1e-8)
p=Path('../measurements/crossover-schedule-check.json');p.write_text(json.dumps({'status':'passed','schedule_steps':n,'final_optimizer_step':5120,'no_schedule_rebuild_or_rescaling':True,'floor_fraction':o.min_lr_ratio,'optimizer_source_sha256':hashlib.sha256(Path('experiments/grug/fast_track/optimizer.py').read_bytes()).hexdigest(),'samples':[{'optimizer_step':i,'muon_lr':float(m[i]),'adam_lr':float(a[i])} for i in [1024,1536,2048,2560,2697,2698,3072,4096,5120]],'scope':'All5121schedulevalues finite; unchanged native Muon power and Adam cosine schedules stay at configured floors after2698. Same optimizer build remains used for both arms.'},indent=2)+'\n')
print(p.read_text())
