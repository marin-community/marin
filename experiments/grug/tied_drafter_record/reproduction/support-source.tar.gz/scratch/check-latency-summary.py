import importlib.util
import json
from pathlib import Path
root=Path('/Users/benfeuer/Documents/experiments/active/fast-pretraining-tied-drafter')
spec=importlib.util.spec_from_file_location('latency_summary',root/'summarize_latency.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
raw=json.loads((root/'measurements/replica-sizes-v1/replica-sizes.json').read_text())
raw['batch_indices']=raw['verification_batches']
control=raw['replicas'][0]['forward_seconds']
for row in raw['replicas']:
    if row['name']=='full_identity': row['name']='identity'
    row['paired_hero_forward_seconds']=control
    for batch in row['batches']:
        batch['sampled_valid_positions']=len(batch['hero_top5_ids'])
rows=module.aggregate(raw)
assert [r['top1_matches'] for r in rows]==[192,103,60]
assert [r['sampled_positions'] for r in rows]==[192,192,192]
assert rows[0]['cross_entropy_increase']==0
assert abs(rows[1]['replica_cross_entropy']-4.4187804102)<1e-9
assert abs(rows[2]['replica_cross_entropy']-6.9081574827)<1e-9
print(json.dumps({'status':'passed','scope':'Reducer regression using preserved size-sanity measurements adapted in memory; not new latency-sweep results','top1_matches':[r['top1_matches'] for r in rows],'sampled_positions':[r['sampled_positions'] for r in rows]},indent=2))
