"""Collect only completed crossover attempts; keep bounded pod status and archive evidence."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
from datetime import datetime,timezone
import tarfile
import zstandard

R=Path(__file__).resolve().parents[1]
MAIN=Path('/Users/benfeuer/Documents/marin')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--study', default='crossover')
parser.add_argument('--state', default='scratch/crossover-4096-monitoring-state.json')
args=parser.parse_args()
study=args.study
state_path=R/args.state
state=json.loads(state_path.read_text())
raw=subprocess.run(['kubectl','--kubeconfig','/Users/benfeuer/.kube/coreweave-iris','--context','marin-rn02a_RNO2A','-n','iris','get','pods','-o','json'],capture_output=True,text=True,check=True)
pods=json.loads(raw.stdout)['items'];observed=[];collected=[]
collection_path=R/f'measurements/{study}-collection.json'
if collection_path.exists():collected=json.loads(collection_path.read_text())
for key,job in state['jobs'].items():
 matches=[p for p in pods if p['metadata'].get('labels',{}).get('iris.job_id')==job['job_id'].strip('/').replace('/','.')]
 for p in matches:
  labels=p['metadata']['labels'];attempt=int(labels['iris.attempt_id'])
  record={'key':key,'name':p['metadata']['name'],'attempt':attempt,'created':p['metadata']['creationTimestamp'],'phase':p['status']['phase'],'labels':labels,'conditions':p['status'].get('conditions',[]),'containers':[{'name':c['name'],'state':c['state']} for c in p['status'].get('containerStatuses',[])]}
  observed.append(record)
  evidence=R/f'scratch/{study}-{key}-attempt{attempt}-pod.json';evidence.write_text(json.dumps(record,indent=2)+'\n')
  if record['phase']!='Succeeded':continue
  if any(c['state']['terminated']['exitCode'] for c in record['containers']):raise ValueError('Nonzero container exit in Succeeded pod')
  uploader=next(c for c in record['containers'] if c['name']=='output-uploader')
  archive_info=json.loads(uploader['state']['terminated']['message'])
  if archive_info['state']!='TASK_OUTPUT_ARCHIVE_STATE_UPLOADED':raise ValueError('Output capture did not succeed')
  stem=f'measurements/{study}-{key}-v1';archive=R/(stem+'.tar.zst')
  if not archive.exists():
   with (R/f'scratch/{study}-{key}-download.txt').open('w') as log:
    subprocess.run(['uv','run','fsutil','cp',archive_info['uri'],str(archive)],cwd=MAIN,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert archive.stat().st_size==int(archive_info['size_bytes'])
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==archive_info['sha256']
  dest=R/stem;dest.mkdir(exist_ok=True)
  if not (dest/'frontier.json').exists():
   with archive.open('rb') as f,zstandard.ZstdDecompressor().stream_reader(f) as stream,tarfile.open(fileobj=stream,mode='r|') as tar:tar.extractall(dest,filter='data')
  result=json.loads((dest/'frontier.json').read_text());assert result['status']=='complete'
  expected=2*len(result['protocol']['horizons']);assert len(result['endpoints'])==expected
  allocation_start=next(c['lastTransitionTime'] for c in record['conditions'] if c['type']=='PodScheduled' and c['status']=='True')
  wb=R/(stem+'-wandb.json')
  if not wb.exists():
   with (R/f'scratch/{study}-{key}-capture.txt').open('w') as log:
    subprocess.run(['uv','run','--project','marin','--no-sync','python','capture_frontier_history.py',str(dest/'frontier.json'),'--pod-record',str(evidence),'--allocation-start',allocation_start,'--output',str(wb)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
  history=json.loads(wb.read_text());assert history['completed'] and len(history['history'])==expected
  item={'key':key,'attempt':attempt,'archive_sha256':archive_info['sha256'],'bytes':archive.stat().st_size,'endpoint_count':expected,'wandb_url':result['wandb_url'],'allocated_gpu_hours':history['allocated_gpu_hours'],'pod_record':str(evidence.relative_to(R))}
  previous=[x for x in collected if x['key']==key]
  if previous:assert previous==[item]
  else:collected.append(item)
  job.update(status='pod_succeeded_collected',attempt=attempt,pod=record['name'],wandb_url=result['wandb_url'],allocation_start=allocation_start)
  collection_path.write_text(json.dumps(collected,indent=2)+'\n');state_path.write_text(json.dumps(state,indent=2)+'\n')
  print('Collected',key,expected,'endpoints',flush=True)
now=datetime.now(timezone.utc).isoformat()
(R/f'scratch/{study}-latest-pods.json').write_text(json.dumps({'observed_at':now,'pods':observed},indent=2)+'\n')
print('Pod states:',[(x['key'],x['attempt'],x['phase']) for x in observed],flush=True)
print('Collected completed jobs:',len(collected),flush=True)
