import json
import jax
import jax.numpy as jnp
import numpy as np
from jax.sharding import Mesh,AxisType,NamedSharding,PartitionSpec as P
from experiments.grug.tied_drafter_approximations import exchange_function, fp4_roundtrip
from levanter.grug._moe.ep_fixed_pooled_wave_all_to_all import _fp8_pack_rows, _fp8_unpack_rows
host=np.random.default_rng(1).normal(size=(64,4,128)).astype(np.float32)
host=np.asarray(jnp.asarray(host,dtype=jnp.bfloat16))
quant4=np.asarray(fp4_roundtrip(jnp.asarray(host)))
quant8=np.asarray(_fp8_unpack_rows(_fp8_pack_rows(jnp.asarray(host)),hidden_dim=128,dtype=jnp.bfloat16))
mesh=Mesh(np.asarray(jax.devices()).reshape(1,1,8,1),('replica_dcn','data','expert','model'),axis_types=(AxisType.Explicit,)*4)
with jax.set_mesh(mesh):
    x=jax.device_put(host,NamedSharding(mesh,P('expert',None,None)))
    for name,ref in [('bf16',host),('fp8',quant8),('fp4',quant4)]:
        out=exchange_function(P('expert',None,None),name)(x)
        expected=ref.reshape(8,8,4,128).transpose(1,0,2,3).reshape(64,4,128)
        np.testing.assert_array_equal(np.asarray(out),expected)
print(json.dumps({'status':'passed','devices':len(jax.devices()),'behavior':'BF16/FP8/FP4 exchange payloads equal independently transposed per-row decoded inputs across eight CPU devices.'},indent=2))
