import importlib.util,json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('summary',root/'summarize_route_boundary.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
tokens=np.broadcast_to(np.arange(4096)%2,(2,4096))
routes=np.broadcast_to((tokens[...,None]*8+np.arange(8))[None],(1,2,4096,8))
data={'tokens':tokens,'routes':routes}
rows=m.analyze(data,data)
def get(w,method):return next(r for r in rows if r['window_tokens']==w and r['method']==method and r['capacity_experts']==8)
assert get(1,'oracle')['hit_rate']==1
assert get(1,'token_id_forecast')['hit_rate']==1
assert get(1,'recent')['hit_rate']==0
assert get(4,'oracle')['hit_rate']==.5
assert get(4,'oracle')['mean_experts_used']==16
assert get(4,'oracle')['fully_covered_window_fraction']==0
print(json.dumps({'status':'passed','behavior':'Alternating disjoint eight-expert token groups: oracle and token forecast hit all single-token routes; recent misses all; an eight-expert cache covers half of four-token assignments.'},indent=2))
