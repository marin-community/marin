"""Verify current report references and preserve frozen source/archive provenance."""
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import tarfile
from urllib.parse import urlsplit, unquote

R=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
class Doc(HTMLParser):
    def __init__(self,p):
        super().__init__();self.ids=[];self.links=[];self.feed(p.read_text())
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if 'id' in d:self.ids.append(d['id'])
        self.links.extend(d[k] for k in ('href','src') if k in d)
results=[]
for name in ('async-analysis.html','plan.html'):
    p=R/name;d=Doc(p);assert len(d.ids)==len(set(d.ids))
    checked=0
    for link in d.links:
        u=urlsplit(link)
        if u.scheme or u.netloc:continue
        target=(p.parent/unquote(u.path)).resolve() if u.path else p
        assert target.exists(),(name,link)
        if u.fragment and target.suffix=='.html':assert unquote(u.fragment) in Doc(target).ids,(name,link)
        checked+=1
    results.append({'file':name,'local_links_and_anchors_verified':checked,'sha256':sha(p)})
protocol=json.loads((R/'crossover-k4-4096-v1.json').read_text())
for name,digest in protocol['implementation_sha256'].items():assert sha(R/'marin'/name)==digest,name
archive_manifest=json.loads((R/'reproduction/crossover-source-manifest.json').read_text())
with tarfile.open(R/'reproduction/crossover-source.tar.gz') as t:
    for name,digest in archive_manifest['files'].items():
        assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
mutable={'analyze_frontier.py','render_report.py','async-analysis.html','plan.html','measurements/resource-ledger.json','measurements/frontier-overview.html','measurements/frontier-opening.html','measurements/frontier-section.html','render_four_expert_efficiency.py','measurements/four-expert-efficiency-section.html'}
changes=[]
for name in ('frontier-manifest.json','endpoint-manifest.json','depth-large-manifest.json','latency-manifest.json','four-expert-analysis-manifest.json'):
    p=R/'reproduction'/name;d=json.loads(p.read_text())
    changed=[]
    for f,old in d['files'].items():
        new=sha(R/f)
        if old==new:continue
        assert f in mutable,(name,f)
        changed.append({'file':f,'old_sha256':old,'new_sha256':new});d['files'][f]=new
    if changed:
        d['current_artifact_refresh']={'at':datetime.now(timezone.utc).isoformat(),'reason':'4096-update follow-up report and analysis; historical archived source bytes remain unchanged.'}
        p.write_text(json.dumps(d,indent=2)+'\n');changes.append({'manifest':name,'changes':changed})
audit={'status':'passed','documents':results,'runtime_files_verified':len(protocol['implementation_sha256']),'frozen_archive_members_verified':len(archive_manifest['files']),'manifest_refresh':changes,'figure':'crossover-efficiency.png visually inspected; scientific plot only, not whole-page browser layout.','cold_reader':'measurements/crossover-prose-review.json'}
(R/'measurements/crossover-artifact-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
paths=set()
for glob in ('*crossover*.py','*crossover*.sh','crossover*.json','measurements/crossover*','scratch/*crossover*'):
    for p in R.glob(glob):
        if p.is_file() and p.suffix not in ('.zst',):paths.add(p)
        elif p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file())
paths.update(R/n for n in ('analyze_frontier.py','render_report.py','async-analysis.html','plan.html','measurements/resource-ledger.json','reproduction/crossover-source.tar.gz','reproduction/crossover-source-manifest.json'))
manifest={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Completed 4096-update paired crossover study, analysis, raw evidence and current report; source-only runtime archive retained separately. No model weights or training data bundled.','files':{str(p.relative_to(R)):sha(p) for p in sorted(paths)}}
(R/'reproduction/crossover-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'documents':results,'manifest_files':len(paths),'runtime_files':len(protocol['implementation_sha256'])},indent=2))
