import equinox as eqx
import jax
from jax.sharding import AbstractMesh, AxisType, use_abstract_mesh
from experiments.grug.fast_track.model import Transformer
from experiments.grug.noise_belay.candidate11 import load_model_config
from experiments.grug.tied_drafter.calibration import MODEL_SOURCE_SHA256
cfg=load_model_config(source_sha256=MODEL_SOURCE_SHA256)
mesh=AbstractMesh((1,1,8,1), ('replica_dcn','data','expert','model'),axis_types=(AxisType.Explicit,)*4)
key=jax.random.PRNGKey(0)
with use_abstract_mesh(mesh):
    model=eqx.filter_eval_shape(Transformer.init,cfg,key=key)
for path, x in jax.tree_util.tree_flatten_with_path(model)[0]:
    n=jax.tree_util.keystr(path)
    if 'mlp' in n: print(n,x.shape,x.sharding)
