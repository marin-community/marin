import json
from dataclasses import replace
from pathlib import Path
import draccus
import equinox as eqx
import jax
import jmp
from jax.sharding import AbstractMesh, AxisType
from jax.sharding import use_abstract_mesh
from experiments.grug.fast_track.optimizer import GrugMoeMuonHConfig
from experiments.grug.fast_track.train import initial_state
from experiments.grug.noise_belay.candidate11 import REFERENCE,load_model_config
from experiments.grug.tied_drafter_endpoints import check_state_coordinates
r=json.loads(REFERENCE.read_text())['config']
mesh=AbstractMesh((1,1,8,1),('replica_dcn','data','expert','model'),axis_types=(AxisType.Explicit,)*4)
cfg=load_model_config(); opt=draccus.decode(GrugMoeMuonHConfig,r['optimizer']).build(r['trainer']['trainer']['num_train_steps']);mp=jmp.get_policy('params=float32,compute=bfloat16,output=bfloat16'); key=jax.random.PRNGKey(0)
with use_abstract_mesh(mesh):
 states=[eqx.filter_eval_shape(initial_state,c,optimizer=opt,mp=mp,key=key,ema_beta=r['trainer']['ema_beta']) for c in [cfg,replace(cfg,num_experts_per_token=6)]]
 check_state_coordinates(*states)
 d={'status':'passed','state_leaf_count':len(jax.tree.leaves(states[0])),'state_bytes':sum(x.size*x.dtype.itemsize for x in jax.tree.leaves(states[0])),'per_device_state_bytes':sum((x.size if x.sharding is None else __import__('math').prod(x.sharding.shard_shape(x.shape)))*x.dtype.itemsize for x in jax.tree.leaves(states[0])),'parameters':sum(x.size for x in jax.tree.leaves(states[0].params)),'state_step_path':[jax.tree_util.keystr(p) for p,x in jax.tree_util.tree_leaves_with_path(states[0]) if jax.tree_util.keystr(p)=='.step']}
 Path('../measurements/endpoint-preflight.json').write_text(json.dumps(d,indent=2)+'\n');print(d)
