"""Own bounded read-only monitoring and collection of the twelve authorized jobs."""
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

R=Path(__file__).resolve().parents[1]
MAIN=Path('/Users/benfeuer/Documents/marin')
STATE=R/'scratch/crossover16k-monitoring-state.json'
INTERVAL=570
next_poll=time.time()+INTERVAL
while True:
    while time.time()<next_poll:
        time.sleep(min(60,next_poll-time.time()))
    now=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(['uv','run','iris','--config','lib/iris/config/cw-rno2a.yaml','job','list','--prefix','/benfeuer/tied-drafter-crossover16k-'],cwd=MAIN,capture_output=True,text=True,check=True)
    (R/'scratch/crossover16k-latest-jobs.txt').write_text(result.stdout)
    states={line.split()[0]:line.split()[1] for line in result.stdout.splitlines() if line.startswith('/benfeuer/')}
    assert len(states)==12,states
    failed={k:v for k,v in states.items() if v in {'failed','killed','cancelled'}}
    if failed:raise RuntimeError(f'Jobs require diagnosis: {failed}')
    collect=subprocess.run(['./collect-crossover16k.sh'],cwd=R,capture_output=True,text=True,check=True)
    (R/'scratch/crossover16k-latest-collection.txt').write_text(collect.stdout+collect.stderr)
    d=json.loads(STATE.read_text())
    pods=json.loads((R/'scratch/crossover16k-latest-pods.json').read_text())['pods']
    wb=json.loads((R/'scratch/crossover16k-wandb-latest.json').read_text())['runs']
    for key,job in d['jobs'].items():
        job['iris_state']=states[job['job_id']]
        matches=[p for p in pods if p['key']==key]
        if matches:
            p=max(matches,key=lambda x:x['attempt']);job.update(attempt=p['attempt'],pod=p['name'],scheduler_priority_class=p['labels']['kueue.x-k8s.io/priority-class'])
        matches=[r for r in wb if '/benfeuer/'+r['name']==job['job_id']]
        if matches:
            r=matches[0];job.update(wandb_url=r['url'],last_endpoint={'active_experts':r['last_active_experts'],'horizon':r['last_horizon']})
    d.update(last_full_poll_utc=now,phase='Monitoring running jobs and collecting completed outputs')
    complete=all(v=='succeeded' for v in states.values())
    d['next_full_poll_utc']=None if complete else datetime.fromtimestamp(time.time()+INTERVAL,timezone.utc).isoformat()
    STATE.write_text(json.dumps(d,indent=2)+'\n')
    print(now, 'Iris:',{v:list(states.values()).count(v) for v in set(states.values())},flush=True)
    print('Endpoints:',[(r['name'].split('-s')[-1],r['last_active_experts'],r['last_horizon']) for r in wb],flush=True)
    if complete:
        assert len(json.loads((R/'measurements/crossover16k-collection.json').read_text()))==12
        (R/'measurements/crossover16k-terminal-jobs.txt').write_text(result.stdout)
        print('All twelve jobs succeeded and outputs collected.',flush=True)
        break
    next_poll=time.time()+INTERVAL
