from pathlib import Path
import hashlib,json,tarfile
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n): return json.loads((R/n).read_text())
def write(n,d): (R/n).write_text(json.dumps(d,indent=2)+'\n')
initial=read('reproduction/frontier-source-manifest.json')
# Frozen archive verifies against its historical bytes, not updated analysis scripts.
with tarfile.open(R/'reproduction/frontier-source.tar.gz') as t:
 assert set(t.getnames())==set(initial['files']) | {'reproduction/frontier-source-manifest.json'}
 assert t.extractfile('reproduction/frontier-source-manifest.json').read()==(R/'reproduction/frontier-source-manifest.json').read_bytes()
 for n,h in initial['files'].items(): assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
for n,h in read('frontier-screen-v1.json')['implementation_sha256'].items(): assert sha(R/'marin'/n)==h,n
paths=set(initial['files'])
for pattern in ['frontier-*.json','marin/experiments/grug/frontier-*.json']:
 paths.update(str(p.relative_to(R)) for p in R.glob(pattern))
paths.update(['capture_frontier_history.py','select_frontier.py','prepare_frontier_confirmation.py','compare_frontier_horizons.py','render_frontier.py','reproduction/routing-weight-gradient-diagnostic.py'])
assert all((R/n).is_file() for n in paths)
manifest={'base_commit':initial['base_commit'],'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Final frontier runtime, protocols, launchers, audits, selection and phase renderer. Raw results and complete report are separate linked artifacts. No checkpoints, datasets or credentials bundled.','restore':'Extract at the experiment root. Check out the recorded Marin base into marin/ and overlay the archived marin/ files. endpoint-runtime.patch is a review reference for changes already present in the overlay; do not apply it a second time. Use the recorded regional checkpoints and dataset access. Install using marin/pyproject.toml and uv.lock. run-frontier.sh records the launch entrypoint; resource-ledger.json retains exact job commands.','files':{n:sha(R/n) for n in sorted(paths)}}
write('reproduction/frontier-final-source-manifest.json',manifest)
with tarfile.open(R/'reproduction/frontier-final-source.tar.gz','w:gz') as t:
 for n in sorted(paths): t.add(R/n,arcname=n,recursive=False)
with tarfile.open(R/'reproduction/frontier-final-source.tar.gz') as t:
 assert set(t.getnames())==paths
 for n,h in manifest['files'].items(): assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
write('measurements/frontier-final-source-audit.json',{'status':'passed','file_count':len(paths),'archive_sha256':sha(R/'reproduction/frontier-final-source.tar.gz'),'manifest_sha256':sha(R/'reproduction/frontier-final-source-manifest.json'),'initial_archive_preserved_and_verified':True,'frozen_runtime_files_verified':len(read('frontier-screen-v1.json')['implementation_sha256'])})
print('Verified final source archive:',len(paths),'files')
