"""Independently recompute equal-cost gains directly from raw evaluation arrays."""
import argparse
import bisect
import json
from pathlib import Path
from statistics import median
R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--study',default='crossover');parser.add_argument('--horizon',type=int,default=4096);args=parser.parse_args()
study=args.study
d=json.loads((R/f'measurements/{study}-efficiency.json').read_text())
expected={(x['seed'],x['trial'],x['horizon']):x for x in d['equal_cost_records']}
records=[];updates=0
for seed in range(3):
    for trial in range(4):
        p=R/f'measurements/{study}-s{seed}-t{trial}-v1/frontier.json'
        raw=json.loads(p.read_text());t=raw['trials'][0]
        updates+=sum(1 for _ in p.with_name('updates.jsonl').open())
        def loss(x):return sum(a*b for a,b in zip(x['losses'],x['counts']))/sum(x['counts'])
        start=loss(t['starting_fresh'])
        native=sorted((x for x in raw['endpoints'] if x['active_experts']==8),key=lambda x:x['horizon'])
        draft=sorted((x for x in raw['endpoints'] if x['active_experts']==4),key=lambda x:x['horizon'])
        costs=[0]+[x['update_seconds'] for x in native]
        gains=[0]+[start-loss(x['fresh']) for x in native]
        for x in draft:
            cost=x['update_seconds']+x['initial_copy_seconds']+t['baseline_check_seconds']+x['candidate_check_seconds']
            hi=bisect.bisect_left(costs,cost);assert 0<hi<len(costs)
            native_gain=gains[hi-1]+(cost-costs[hi-1])/(costs[hi]-costs[hi-1])*(gains[hi]-gains[hi-1])
            advantage=start-loss(x['fresh'])-native_gain
            e=expected[seed,trial,x['horizon']]
            assert abs(advantage-e['draft_equal_cost_gain_advantage'])<1e-12
            records.append({'seed':seed,'trial':trial,'horizon':x['horizon'],'advantage':advantage})
assert updates==12*2*args.horizon and len(records)==12*len(d['trajectory'])
for row in d['trajectory']:
    xs=[x['advantage'] for x in records if x['horizon']==row['horizon']]
    assert abs(median(xs)-row['median_equal_cost_gain_advantage'])<1e-12
result={'status':'passed','total_update_records':updates,'equal_cost_pairs_verified':len(records),'method':'Raw weighted loss arrays and manual adjacent-bracket interpolation, independently of summary gains and NumPy interpolation.','final':d['trajectory'][-1],'first_sustained_window':d['first_sustained_window']}
(R/f'measurements/{study}-numerical-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
