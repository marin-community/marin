"""Audit collected crossover runs and account for their completed allocations."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

R = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--study',default='crossover')
parser.add_argument('--horizon',type=int,default=4096)
parser.add_argument('--state',default='scratch/crossover-4096-monitoring-state.json')
args=parser.parse_args()
study=args.study
protocol=json.loads((R/f'crossover-k4-{args.horizon}-v1.json').read_text())
collection = json.loads((R / f'measurements/{study}-collection.json').read_text())
assert len(collection) == 12
assert all(x['attempt'] == 0 and x['endpoint_count'] == 2*len(protocol['horizons']) for x in collection)
state_path = R / args.state
state = json.loads(state_path.read_text())
ledger_path = R / 'measurements/resource-ledger.json'
ledger = json.loads(ledger_path.read_text())
for item in collection:
    job = state['jobs'][item['key']]
    row = next(r for r in ledger['runs'] if r['job_id'] == job['job_id'])
    pod=json.loads((R/item['pod_record']).read_text())
    assigned_priority=pod['labels']['kueue.x-k8s.io/priority-class'].removeprefix('iris-accelerator-')
    row.update(status='succeeded', gpu_hours=item['allocated_gpu_hours'], assigned_priority=assigned_priority, attempt=0,
               accounting='PodScheduled to final container completion, eight H100s; includes startup/preload/output capture, excludes queue; allocation estimate, not billing.',
               evidence=f"measurements/{study}-{item['key']}-v1-wandb.json")
    job['status'] = 'succeeded_collected'
ledger['final_gpu_hours'] = sum(r.get('gpu_hours', 0) for r in ledger['runs'])
assert all(r['status'] in {'succeeded', 'failed', 'killed', 'cancelled', 'preempted'} for r in ledger['runs']), {r['status'] for r in ledger['runs']}
ledger['all_jobs_terminal'] = True
ledger['current_followup'] = f'Completed twelve paired four-expert/native {args.horizon}-update windows; no interrupted attempts. Results in {study}-efficiency.json.'
state.update(phase='All twelve jobs succeeded and collected; analyzing crossover', updated_at=datetime.now(timezone.utc).isoformat())
ledger_path.write_text(json.dumps(ledger, indent=2)+'\n')
state_path.write_text(json.dumps(state, indent=2)+'\n')
inputs = [f'measurements/{study}-s{s}-t{t}-v1/frontier.json' for s in range(3) for t in range(4)]
protocols = [f'crossover-k4-{args.horizon}-p{t}-v1.json' for s in range(3) for t in range(4)]
command = ['uv','run','--project','marin','--no-sync','python','analyze_frontier.py',*inputs,
           '--protocol',f'crossover-k4-{args.horizon}-v1.json','--run-protocols',*protocols,
           '--driver-source','experiments/grug/tied_drafter_crossover.py','--output',f'measurements/{study}-summary.json']
with (R/f'measurements/{study}-audit.txt').open('w') as log:
    subprocess.run(command, cwd=R, stdout=log, stderr=subprocess.STDOUT, check=True)
subprocess.run(['uv','run','--project','marin','--no-sync','python','analyze_crossover.py','--prefix',study,'--protocol',f'crossover-k4-{args.horizon}-v1.json'],cwd=R,check=True)
print('Total recorded H100 GPU-hours:', ledger['final_gpu_hours'])
