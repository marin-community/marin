from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,math
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/n).read_text())
def sha(n):return hashlib.sha256((R/n).read_bytes()).hexdigest()
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
checks=[]
def record(requirement,evidence,detail):checks.append({'requirement':requirement,'evidence':evidence,'verified':detail})
e=read('measurements/endpoint-final-reaudit.json')
assert e['raw_summary_exact_match'] and e['frozen_runtime_hashes_match'] and e['accepted_blocks']==e['fresh_improved_blocks']==36 and e['predeclared_target_records_verified']==30
ck=read('measurements/endpoint-final-checkpoint-stat.json');assert len(ck['objects'])==9 and all(x['unchanged_since_original_audit'] for x in ck['objects'])
record('Original accepted-block trajectory, costs, loss targets and saved states',['measurements/endpoint-audit.json','measurements/endpoint-final-reaudit.json','measurements/endpoint-final-checkpoint-stat.json'], 'Three seeds, twelve accepted 64-update blocks each; complete state and following native steps; matched control and 128-step recovery audited. All 36 fresh gains positive. All 30 target records and nine live checkpoint metadata records verified. Checkpoint tensors were not re-downloaded.')
for phase,count in [('screen',192),('k1',48),('long',48),('confirmation',144)]:
 s=read(f'measurements/frontier-{phase}-summary.json');assert s['status']=='audited' and len(s['records'])==count
 keys={(x['seed'],x['trial'],x['active_experts'],x['horizon']) for x in s['records']};assert len(keys)==count
 for src in s['sources']:assert sha(src['path'])==src['sha256']
 record('Frontier '+phase,[f'measurements/frontier-{phase}-summary.json'],f'{count} unique audited endpoints; raw source hashes match.')
s=read('measurements/frontier-confirmation-summary.json')
expected={(seed,trial,k,h) for seed in range(3) for trial in range(4,16) for k in (1,8) for h in (256,512)}
assert {(x['seed'],x['trial'],x['active_experts'],x['horizon']) for x in s['records']}==expected
for x in s['records']:
 if x['active_experts']==1:assert x['accepted']==(x['horizon']==512) and (x['fresh_gain']>0)==(x['horizon']==512)
selection=read('frontier-confirmation-selection-v1.json'); state=read('scratch/frontier-next-actions.json')
assert selection['passing_candidate']['active_experts']==1 and selection['passing_candidate']['horizon']==512
assert selection['failing_neighbor']['horizon']==256
assert sha('frontier-analysis-protocol-v1.json')==selection['rule_sha256']
for x in selection['sources']:assert sha(x['path'])==x['sha256']
assert all(datetime.fromisoformat(selection['frozen_at'])<datetime.fromisoformat(j['submitted_at']) for j in state['jobs'].values())
record('Frozen selection and fresh confirmation',['frontier-confirmation-selection-v1.json','measurements/frontier-confirmation-summary.json'],'Selection predates all twelve submissions; 36 distinct seed/windows per cell, all four cells fully covered. One expert rejects 36/36 at256 and0/36 at512. Fresh loss signs match. Shared checkpoints/windows limit reliability inference.')
collection=read('measurements/frontier-confirm-collection.json');assert len(collection)==12
for x in collection:
 stem='measurements/frontier-confirm-'+x['key'];a=R/(stem+'.tar.zst');assert sha(stem+'.tar.zst')==x['archive_sha256'] and a.stat().st_size==x['bytes']
 w=read(stem+'-wandb.json');assert w['completed'] and w['state']=='finished' and len(w['history'])==12
 raw=read(stem+'/frontier.json'); rawmap={(z['trial'],z['active_experts'],z['horizon']):z for z in s['records'] if z['seed']==raw['seed'] and z['trial'] in raw['protocol']['trial_ids']}
 for z in w['history']:
  v=rawmap[(z['trial'],z['active_experts'],z['horizon'])];assert bool(z['accepted'])==v['accepted'] and z['update_seconds']==v['update_seconds']
 pod=read('scratch/frontier-confirm-'+x['key']+'-pod.json');assert pod['phase']=='Succeeded'
 assert all(z['state']['terminated']['exitCode']==0 for z in pod['containers'])
assert all(j['status']=='succeeded' for j in state['jobs'].values())
record('Successful task outputs and W&B',['measurements/frontier-confirm-collection.json','measurements/frontier-confirmation-audit.txt'],'Twelve archives hash/size verified; all pods Succeeded with zero-exit containers; all144 W&B records reconciled with audited raw values.')
for n,h in read('frontier-screen-v1.json')['implementation_sha256'].items():assert sha('marin/'+n)==h
long=read('measurements/frontier-long-summary.json');assert all(c['rejected']==0 for c in long['cells'])
x=read('measurements/frontier-long-cross-horizon-comparison.json');assert x['pairs']==x['native_dominates_pairs']==12 and x['source_sha256']==sha(x['source'])
record('Expansion stopping condition and quality/cost interpretation',['frontier-long-v1.json','measurements/frontier-long-cross-horizon-comparison.json'],'Minimum tested count one routed expert; no upper rejection boundary through1536 schedule-safe updates. Native1024 is cheaper and reaches lower fresh loss than draft1536 in12/12pairs. No production speedup claimed.')
ledger=read('measurements/resource-ledger.json');assert ledger['all_jobs_terminal'] and all(x['status'] in ('succeeded','failed','killed','cancelled') for x in ledger['runs'])
assert math.isclose(sum(x.get('gpu_hours',0) for x in ledger['runs']),ledger['final_gpu_hours'])
priority=read('measurements/frontier-confirm-priority-audit.json');assert len(priority['jobs'])==12 and all(x['requested_band']=='2' and x['assigned_band']=='3' for x in priority['jobs'])
ledger['current_followup']='Complete: all four frontier phases collected and audited, final report reviewed, source archive and local references verified. No active experiment jobs.';write('measurements/resource-ledger.json',ledger)
record('Resource accounting and authorization',['measurements/resource-ledger.json','measurements/frontier-preemption-record.json','measurements/frontier-confirm-preemption-record.json','measurements/frontier-confirm-priority-audit.json'],'All recorded jobs terminal; total141.1464468817181 estimated H100 GPU-hours. Frontier peak96 below256 concurrency cap. Interrupted attempts charged; observed queue intervals excluded. Interactive requested; all12confirmation jobs assigned BATCH, disclosed. No cumulative budget gate or manual priority change.')
for n in ['measurements/frontier-final-artifact-audit.json','measurements/frontier-final-source-audit.json']:assert read(n)['status']=='passed'
record('Report and reproduction',['measurements/frontier-final-artifact-audit.json','measurements/frontier-final-source-audit.json','measurements/frontier-final-prose-review.json'],'183 local report/plan references verified. Five cold-reader clarity gaps fixed. Scientific plots inspected. Final source archive91files verified; frozen initial archive preserved. Desktop/mobile HTML preview unavailable, explicitly recorded.')
write('measurements/frontier-completion-audit.json',{'status':'complete','completed_at':datetime.now(timezone.utc).isoformat(),'scope':'Original accepted-block trajectory objective plus requested faster-drafter/larger-block rejection frontier.','checks':checks,'remaining_required_work':[],'limitations':['Observed rejection frequencies share three checkpoints and data windows; they do not establish population rates.','Longer one-expert blocks were independent checkpoint branches, not a repeated-acceptance training trajectory.','No rejection ceiling found through the declared1536-update schedule bound; outside this schedule and architecture remains untested.','No end-to-end same-loss pretraining speedup established.','HTML browser rendering unavailable; plots, structure and references verified.']})
state['goal']='Complete: original endpoint trajectory and user-requested rejection frontier.';state['current_phase']='Complete. All GPU jobs terminal; final report, source archive, references and completion audit passed.';state['remaining']=[];state['next_routine_poll_utc']=None;state['final_completion_audit']='measurements/frontier-completion-audit.json';write('scratch/frontier-next-actions.json',state)
print('Completion checks passed:',len(checks))
