import argparse
from pathlib import Path
from datetime import datetime,timezone
import json
import wandb
R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--study',default='crossover');args=parser.parse_args()
runs=wandb.Api().runs('nyu-dice-lab/tied-drafter-endpoints',filters={'display_name':{'$regex':f'^tied-drafter-{args.study}-'}})
rows=[]
for run in runs:
 if not run.name.endswith('-v1-20261024'):continue
 s=run.summary
 rows.append({'name':run.name,'url':run.url,'state':run.state,'created_at':run.created_at,'last_horizon':s.get('horizon'),'last_active_experts':s.get('active_experts'),'last_fresh_gain':s.get('fresh_gain'),'completed':s.get('completed',False)})
p=R/f'scratch/{args.study}-wandb-latest.json';p.write_text(json.dumps({'observed_at':datetime.now(timezone.utc).isoformat(),'runs':rows},indent=2)+'\n')
for r in sorted(rows,key=lambda r:r['name']):print(r['name'],r['state'],r['last_active_experts'],r['last_horizon'],r['completed'])
