from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,hashlib
R=Path(__file__).resolve().parents[1]
class Doc(HTMLParser):
 def __init__(self,p):
  super().__init__();self.ids=[];self.links=[];self.feed(p.read_text())
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if 'id' in d:self.ids.append(d['id'])
  for key in ('href','src'):
   if key in d:self.links.append(d[key])
results=[]
for name in ['async-analysis.html','plan.html']:
 p=R/name;d=Doc(p);assert len(d.ids)==len(set(d.ids)),name
 checked=0
 for link in d.links:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  target=(p.parent/unquote(u.path)).resolve() if u.path else p
  assert target.exists(),(name,link)
  if u.fragment and target.suffix=='.html':assert unquote(u.fragment) in Doc(target).ids,(name,link)
  checked+=1
 text=p.read_text()
 for stale in ['27/36','confirmation remains incomplete','next boundary search','replica check below']:
  assert stale not in text,(name,stale)
 results.append({'file':name,'local_links_and_anchors_verified':checked,'unique_ids':len(d.ids),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
record={'status':'passed','documents':results,'figures':'Scientific plots inspected during analysis, including completed confirmation and long-horizon figures.','visual_preview_limitation':'Desktop/mobile browser rendering unavailable: earlier Chrome/Safari preview returned cgWindowNotFound. This audit checks local references, anchor uniqueness, and stale status text; it is not a rendered-layout check.','cold_reader_review':'measurements/frontier-final-prose-review.json'}
(R/'measurements/frontier-final-artifact-audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
