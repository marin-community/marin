"""Audit the completed long-horizon artifact without changing frozen runtime evidence."""
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import tarfile
from urllib.parse import urlsplit, unquote

R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Document(HTMLParser):
    def __init__(self,path):
        super().__init__();self.ids=[];self.links=[];self.feed(path.read_text())
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if 'id' in d:self.ids.append(d['id'])
        self.links.extend(d[k] for k in ('href','src') if k in d)
checks=[]
for name in ('async-analysis.html','plan.html'):
    path=R/name;doc=Document(path);assert len(doc.ids)==len(set(doc.ids))
    count=0
    for link in doc.links:
        u=urlsplit(link)
        if u.scheme or u.netloc:continue
        target=(path.parent/unquote(u.path)).resolve() if u.path else path
        assert target.exists(),(name,link)
        if u.fragment and target.suffix=='.html':assert unquote(u.fragment) in Document(target).ids,(name,link)
        count+=1
    checks.append({'file':name,'references_verified':count,'sha256':sha(path)})
p=json.loads((R/'crossover-k4-16384-v1.json').read_text())
for name,h in p['implementation_sha256'].items():assert sha(R/'marin'/name)==h,name
archive=R/'reproduction/crossover16k-source.tar.gz'
m=json.loads((R/'reproduction/crossover16k-source-manifest.json').read_text());assert sha(archive)==m['archive_sha256']
with tarfile.open(archive) as tar:
    for name,h in m['files'].items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h,name
mutable={'reproduction/four-expert-analysis-manifest.json','analyze_crossover.py','render_report.py','async-analysis.html','plan.html','measurements/resource-ledger.json','measurements/crossover-efficiency.json','measurements/crossover-efficiency.svg','measurements/crossover-efficiency.png','measurements/crossover-numerical-audit.json','scratch/collect-crossover.py','scratch/crossover-wandb-progress.py','scratch/finish-crossover-analysis.py','scratch/check-crossover-numbers.py'}
refresh=[]
for name in ('four-expert-analysis-manifest.json','frontier-manifest.json','endpoint-manifest.json','depth-large-manifest.json','latency-manifest.json','crossover-manifest.json'):
    path=R/'reproduction'/name;record=json.loads(path.read_text());changed=[]
    for f,h in record['files'].items():
        new=sha(R/f)
        if h==new:continue
        assert f in mutable,(name,f)
        changed.append({'file':f,'old_sha256':h,'new_sha256':new});record['files'][f]=new
    if changed:
        record['current_artifact_refresh']={'at':datetime.now(timezone.utc).isoformat(),'reason':'16384-update follow-up report and parameterized analysis/collection helpers. Prior4096 numerical results reproduced; historical archived source is unchanged.'}
        path.write_text(json.dumps(record,indent=2)+'\n');refresh.append({'manifest':name,'changes':changed})
ledger=json.loads((R/'measurements/resource-ledger.json').read_text());runs=[r for r in ledger['runs'] if '/tied-drafter-crossover16k-' in r['job_id']]
assert len(runs)==12 and all(r['status']=='succeeded' for r in runs)
assert (R/'measurements/crossover16k-terminal-jobs.txt').read_text().count('succeeded')==12
assert json.loads((R/'measurements/crossover16k-numerical-audit.json').read_text())['total_update_records']==393216
assert len(json.loads((R/'measurements/crossover16k-summary.json').read_text())['records'])==744
record={'status':'passed','documents':checks,'runtime_files_verified':len(p['implementation_sha256']),'source_archive_members_verified':len(m['files']),'manifest_refresh':refresh,'gpu_hours':sum(r['gpu_hours'] for r in runs),'figures':'crossover16k-efficiency.png visually inspected; whole-page browser layout not inspected.','cold_reader':'measurements/crossover16k-prose-review.json'}
(R/'measurements/crossover16k-artifact-audit.json').write_text(json.dumps(record,indent=2)+'\n')
paths=set()
for pattern in ('*crossover16k*','crossover-k4-16384*.json','measurements/crossover16k*','scratch/*crossover16k*'):
    for path in R.glob(pattern):
        if path.is_dir():paths.update(x for x in path.rglob('*') if x.is_file())
        elif path.suffix!='.zst':paths.add(path)
paths.update(R/n for n in ('analyze_crossover.py','analyze_frontier.py','capture_frontier_history.py','render_report.py','async-analysis.html','plan.html','measurements/resource-ledger.json','scratch/collect-crossover.py','scratch/crossover-wandb-progress.py','scratch/finish-crossover-analysis.py','scratch/check-crossover-numbers.py','reproduction/crossover16k-source.tar.gz','reproduction/crossover16k-source-manifest.json'))
manifest={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Completed16384-update paired study, raw results, analysis and current report. Model checkpoints/data/credentials are not bundled.','files':{str(path.relative_to(R)):sha(path) for path in sorted(paths)}}
(R/'reproduction/crossover16k-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':'passed','documents':checks,'manifest_files':len(paths),'gpu_hours':record['gpu_hours']},indent=2))
