from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
R=Path(__file__).resolve().parents[1]
state_path=R/'scratch/crossover16k-monitoring-state.json'
assert not state_path.exists()
state={'owner':'current thread','cluster_config':'/Users/benfeuer/Documents/marin/lib/iris/config/cw-rno2a.yaml','authorization':'16384-update four-expert/native crossover; interactive requested; no cumulative budget gate; up to256H100.','phase':'submitting','jobs':{},'restart_count':0,'protocol':'crossover-k4-16384-v1.json','latest_signal':'All22runtimehashes unchanged from completed4096study; native LR floor checked through17408; launcher shell syntax validated.'}
state_path.write_text(json.dumps(state,indent=2)+'\n')
ledger_path=R/'measurements/resource-ledger.json';ledger=json.loads(ledger_path.read_text());ledger['all_jobs_terminal']=False;ledger['current_followup']='User-authorized four-expert/native16384-update crossover study; submitting12pairedwindowjobs. Final GPU-hour total is completed historical work until new allocations are accounted.'
for seed in range(3):
 for trial in range(4):
  name=f'tied-drafter-crossover16k-s{seed}-t{trial}-v1-20261024'
  protocol=f'crossover-k4-16384-p{trial}-v1.json';cmd=['./run-crossover16k.sh',name,protocol,str(seed)]
  log=R/f'scratch/crossover16k-s{seed}-t{trial}-v1-submit.txt'
  with log.open('w') as f:subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
  assert '/benfeuer/'+name in log.read_text()
  job={'job_id':'/benfeuer/'+name,'seed':seed,'trial':trial,'protocol':protocol,'resubmit_command':' '.join(cmd),'submitted_at':datetime.now(timezone.utc).isoformat(),'status':'submitted','submit_log':str(log.relative_to(R)),'restart_count':0}
  state['jobs'][f's{seed}-t{trial}']=job;state_path.write_text(json.dumps(state,indent=2)+'\n')
  ledger['runs'].append({'job_id':job['job_id'],'cluster':'cw-rno2a','gpus':8,'requested_priority':'interactive','timeout_seconds':18000,'status':'submitted','submitted_utc':job['submitted_at'],'resubmit_command':job['resubmit_command'],'protocol':protocol,'purpose':'paired four-expert/native16384-update crossover, one data window'})
  ledger_path.write_text(json.dumps(ledger,indent=2)+'\n')
  print('Submitted',job['job_id'],flush=True)
state['phase']='waiting for admission/startup';state['latest_signal']='All12jobs submitted;96H100maximum. No conclusions from intermediate losses.';state_path.write_text(json.dumps(state,indent=2)+'\n')
