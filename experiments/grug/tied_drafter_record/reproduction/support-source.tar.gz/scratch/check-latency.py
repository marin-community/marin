import io
import json
from dataclasses import replace
import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np
from jax.sharding import AbstractMesh, AxisType, Mesh, NamedSharding, PartitionSpec, use_abstract_mesh
from experiments.grug.fast_track.model import Transformer
from experiments.grug.noise_belay.candidate11 import load_model_config
from experiments.grug.tied_drafter.audit import linear_weight_equivalents
from experiments.grug.tied_drafter.calibration import MODEL_SOURCE_SHA256
from experiments.grug.tied_drafter.coordinates import coordinate_map, restrict_model
from experiments.grug.tied_drafter_latency import VARIANTS, norm_selected_experts, restored_leaf, variant_config, variant_template
from experiments.grug.tied_drafter_approximations import modify_blocks, fp4_pack_rows, fp4_roundtrip

class Mlp(eqx.Module):
    w_up: jax.Array
    w_down: jax.Array

class Toy(eqx.Module):
    expert_mlp: Mlp

# Analytic example: channels 1 and 3 dominate, with different up/down weights.
up = jnp.asarray([[[1., 2., 3., 4.]]])
down = jnp.asarray([[[1.], [10.], [1.], [10.]]])
hero = Toy(Mlp(up, down))
selected = Toy(Mlp(up[..., :2], down[..., :2, :]))
mesh1=Mesh(np.asarray(jax.devices()[:1]), ('expert',),axis_types=(AxisType.Explicit,))
with jax.set_mesh(mesh1):
    actual = eqx.filter_jit(norm_selected_experts)(hero, selected, 2)
x = np.asarray([2.])
y = np.maximum(x @ np.asarray(actual.expert_mlp.w_up[0]), 0.)**2 @ np.asarray(actual.expert_mlp.w_down[0])
assert np.array_equal(y, np.asarray([800.])), y
mesh1=Mesh(np.asarray(jax.devices()[:1]), ('expert',),axis_types=(AxisType.Explicit,))
with jax.set_mesh(mesh1):
    sharding=NamedSharding(mesh1, PartitionSpec())
    data=(jax.device_put(np.arange(6,dtype=np.float32).reshape(2,3),sharding),None)
    template=jax.tree.map(lambda a: jax.ShapeDtypeStruct(a.shape,a.dtype), data)
    stream=io.BytesIO()
    eqx.tree_serialise_leaves(stream,data)
    stream.seek(0)
    restored=eqx.tree_deserialise_leaves(stream,template,filter_spec=lambda f,t:restored_leaf(f,t,mesh1))
    assert np.array_equal(restored[0],data[0]) and restored[1] is None
    assert stream.read()==b''
cfg=load_model_config(source_sha256=MODEL_SOURCE_SHA256)
key=jax.random.PRNGKey(0)
mesh=AbstractMesh((1,1,8,1),('replica_dcn','data','expert','model'),axis_types=(AxisType.Explicit,)*4)
rows=[]
with use_abstract_mesh(mesh):
    hero=eqx.filter_eval_shape(Transformer.init,cfg,key=key)
    for v in VARIANTS:
        config=variant_config(cfg,v)
        template=variant_template(config,key)
        selected=eqx.filter_eval_shape(restrict_model,hero,template,coordinate_map(hero,template))
        if v.selection=='norm':
            selected=eqx.filter_eval_shape(norm_selected_experts,hero,selected,v.expert_width)
        assert all(a.shape==b.shape for a,b in zip(jax.tree.leaves(selected),jax.tree.leaves(template),strict=True))
        if v.approximation in ('drop_shared','gate_half','gate_identity','rms_gain_only','fp4_expert_inputs'):
            selected=modify_blocks(selected,v.approximation)
        if v.approximation == 'fp4_expert_weights':
            selected=eqx.filter_eval_shape(modify_blocks, selected, v.approximation)
        rows.append({'name':v.name,'parameters':sum(x.size for x in jax.tree.leaves(selected)),'linear_fraction':linear_weight_equivalents(selected)/linear_weight_equivalents(hero)})
codebook=jnp.asarray([[0.,.5,1.,1.5,2.,3.,4.,6.,-0.,-.5,-1.,-1.5,-2.,-3.,-4.,-6.]],dtype=jnp.bfloat16)
np.testing.assert_array_equal(fp4_roundtrip(codebook),codebook)
np.testing.assert_array_equal(fp4_roundtrip(jnp.zeros_like(codebook)),jnp.zeros_like(codebook))
assert fp4_pack_rows(jnp.zeros((2,256),dtype=jnp.bfloat16)).shape==(2,148)
print(json.dumps({'checks':'analytic selected-channel output, checkpoint roundtrip, 32 full-scale shape/sharding traces and FP4 codebook/zero/packed-size checks','variants':rows},indent=2))
