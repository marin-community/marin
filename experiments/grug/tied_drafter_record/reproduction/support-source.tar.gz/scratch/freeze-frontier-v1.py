import datetime
import hashlib
import json
import re
from pathlib import Path

base=json.loads(Path('tied-endpoints-v4.json').read_text())
files=list(base['implementation_sha256'])+[
 'experiments/grug/tied_drafter_frontier.py',
 'experiments/grug/tied_drafter_latency.py',
 'experiments/grug/tied_drafter/calibration.py',
 'experiments/grug/tied_drafter/coordinates.py',
 'experiments/grug/tied_drafter/audit.py',
 'experiments/grug/noise_belay/candidate11.py',
 'experiments/grug/noise_belay/candidate11-reference.json',
 'experiments/grug/tied_drafter_activation/model.py',
 'experiments/grug/tied_drafter_approximations.py',
 'experiments/grug/tied_replica_sanity.py',
 'experiments/grug/tied_replica_sizes.py',
]
checkpoints={}
for seed in range(3):
 raw=json.loads(Path(f'measurements/endpoint-main-s{seed}-v4/endpoints.json').read_text())
 stat=Path(f'measurements/endpoint-main-s{seed}-initial-checkpoint-stat.txt').read_text()
 checkpoints[str(seed)]={**raw['checkpoints']['initial-full-state'],'etag':re.search(r'^ETag\s+(.+)',stat,re.M)[1]}
protocol={
 'phase':'paired rejection frontier, initial screen',
 'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'seeds':[0,1,2], 'trial_ids':[0,1,2,3], 'active_experts':[8,6,4,2],
 'horizons':[64,128,256,512], 'checkpoint_step':1024,
 'checkpoints':checkpoints, 'microbatches':2, 'minimum_loss_gain':1e-6,
 'training_batch_start':120000, 'training_window_stride':2048,
 'check_batch_start':160000, 'fresh_batch_start':161000, 'monitor_batches':4,
 'wandb_project':'tied-drafter-endpoints',
 'implementation_sha256':{f:hashlib.sha256((Path('marin')/f).read_bytes()).hexdigest() for f in files},
 'acceptance':'Full eight-expert check loss decrease > max(1e-6, twice the range of three repeated starting-check evaluations). No confidence or speed gate. Full prefix first-choice result; no fallback rescue counted as acceptance.',
 'clock_policy':'Every independent branch restores checkpoint optimizer step1024 and complete Muon/Adam, EMA and pending quantile state. Optimizer advances to1024+horizon. Training data indices are new window offsets and deliberately do not set the optimizer clock. Schedule remains2698.',
 'state_policy':'Same complete state coordinates for all expert counts; native evaluation applies pending quantile values. Independent on-device copies, exact input equality and retained-source isolation after donated updates. Native output bitwise determinism is not assumed.',
 'comparison':'Each initialization seed/window has one native eight-expert trajectory and three draft trajectories. Evaluate nested horizons without changing the training trajectory. Rotate execution order by trial id. Native control costs/results reused across drafts.',
 'measurement':'Check batch excluded from training; four fresh monitor batches excluded from selection. All are unused windows of the same pretraining stream. This is an independent-checkpoint screen, not continuing accepted-block training.',
 'failure_policy':'Nonfinite draft training loss stops that trajectory and marks all unreached horizons rejected, separately labeled. Nonfinite endpoint check rejects that prefix. Nonfinite native loss/evaluation aborts the run for diagnosis. Exceptions are not converted to rejections.',
 'screen_rule':'For each draft expert-count/horizon cell, pool twelve trials (four per seed). At most one rejection is <=10%; two or more exceeds10%. Report all cells and per-seed counts; rates are descriptive and trials sharing checkpoints are not independent population samples.',
 'expansion_rule':'After the complete screen: test one active expert on the same windows if two experts pass at any horizon. Extend the longest passing configuration and its next-faster tested neighbor to1024/1536 updates if512 remains feasible; always include an eight-expert native reference. The maximum1536 ends at optimizer step2560, inside schedule2698. Do not assume rejection is monotonic in horizon or expert count. If no boundary is found, report tested architectural/schedule limits.',
 'confirmation_rule':'Freeze selection after screening/expansion, before fresh confirmation results. Confirm the fastest passing setting by median measured update time per proposed update and the nearest observed failing neighbor, if present. Use twelve new windows per seed, trial ids4..15 (36 trials total per setting). Four rejections exceeds10%; up to three is <=10%. Report acceptance, fresh loss vs start/native and complete work costs. No claim of population rejection guarantees.',
 'cost':'Report synchronized updates, baseline/candidate checks, calibration, monitoring, state copies, data, restore and compilation separately; include whole-job GPU allocation. Full generation is charged even for rejected prefixes. Earlier prefix checks are diagnostic overhead for a hypothetical single-horizon policy.',
 'authorization':'User requested longer blocks/faster drafters after completed current batch; RNO2A interactive, no cumulative budget gating, at most256 H100 concurrently.',
}
for p in [Path('frontier-screen-v1.json'),Path('marin/experiments/grug/frontier-screen-v1.json')]:p.write_text(json.dumps(protocol,indent=2)+'\n')
Path('reproduction/frontier-v1-tied_drafter_frontier.py').write_bytes(Path('marin/experiments/grug/tied_drafter_frontier.py').read_bytes())
print('Frozen frontier source:',protocol['implementation_sha256']['experiments/grug/tied_drafter_frontier.py'])
