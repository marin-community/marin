import json
from collections import defaultdict
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=json.loads((root/'measurements/architecture-audit.json').read_text())
# Full shapes are already preserved in the original coordinate audit.
rows=[]
for x in a['recipes']['ffn_eighth']['coordinates']:
    n=x['path'];shape=x['hero_shape']
    size=1
    for dim in shape: size*=dim
    if any(s in n for s in ('token_embed','value_embed')): continue
    if 'expert_mlp' in n: cost=size*8/512
    elif len(shape)>=2 and not any(s in n for s in ('.weight','.dt_bias','.a_log','.router_bias')): cost=size
    else: continue
    rows.append((cost,n,shape))
for cost,n,shape in sorted(rows,reverse=True):print(f'{cost:12.0f} {n} {shape}')
