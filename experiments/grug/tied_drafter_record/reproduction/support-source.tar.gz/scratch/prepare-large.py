import json
from dataclasses import replace
from pathlib import Path
import draccus,equinox as eqx,jax
from jax.sharding import AbstractMesh,AxisType,use_abstract_mesh
from experiments.grug.fast_track.model import Transformer
from experiments.grug.noise_belay.candidate11 import load_model_config
from experiments.grug.tied_drafter.calibration import MODEL_SOURCE_SHA256
from experiments.grug.tied_drafter.audit import linear_weight_equivalents
cfg=load_model_config(source_sha256=MODEL_SOURCE_SHA256)
large=replace(cfg,num_layers=12,num_experts=1024,attn_res_num_blocks=16,global_layers=(3,5,9,11),latent_out_full_layers=(4,5,10,11))
root=Path('..')
Path('experiments/grug/tied-large-config.json').write_text(json.dumps(draccus.encode(large),indent=2)+'\n')
mesh=AbstractMesh((1,1,8,1),('replica_dcn','data','expert','model'),axis_types=(AxisType.Explicit,)*4)
key=jax.random.PRNGKey(0)
with use_abstract_mesh(mesh):
 small=eqx.filter_eval_shape(Transformer.init,cfg,key=key)
 model=eqx.filter_eval_shape(Transformer.init,large,key=key)
 out={'parameters':sum(x.size for x in jax.tree.leaves(model)),'parameter_ratio':sum(x.size for x in jax.tree.leaves(model))/sum(x.size for x in jax.tree.leaves(small)),'linear_compute_ratio':linear_weight_equivalents(model)/linear_weight_equivalents(small),'layer_stack_indices':model.stack_layer_indices(),'changes':{'num_layers':[6,12],'num_experts':[512,1024],'attn_res_num_blocks':[8,16],'global_layers':[[3,5],[3,5,9,11]],'latent_out_full_layers':[[4,5],[4,5,10,11]]},'architecture_policy':'Repeat the original six-block attention/full-width-expert-write layout twice; retain per-block widths and eight active experts.', 'steps':2116,'reason_for_residual_block_change':'Preserve a separate residual-history segment for each physical block as depth doubles.'}
(root/'measurements/large-model-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
