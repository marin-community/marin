"""Freeze the authorized 16,384-update extension without changing training code."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
p = json.loads((R/'crossover-k4-4096-v1.json').read_text())
for name, digest in p['implementation_sha256'].items():
    assert hashlib.sha256((R/'marin'/name).read_bytes()).hexdigest() == digest, name
p.update(phase='four-expert crossover through 16384 updates', frozen_at=datetime.now(timezone.utc).isoformat(),
         horizons=sorted(set(p['horizons'] + list(range(5120,16385,1024)))),
         training_batch_start=400000, training_window_stride=32768,
         check_batch_start=600000, fresh_batch_start=601000, final_optimizer_step=17408)
p['clock_policy']='Restore complete checkpoint at 1024; advance through 17408. Preserve native optimizer built with schedule_steps=2698, including Muon/Adam 5% floors and native slow-momentum/weight-decay tails. No schedule rescaling, restart or state reset. First 1674 updates use the original decay; remaining 14710 use its floor.'
p['comparison']='Four-expert and native-eight branches on the same allocation, starting state and new paired data window; alternate execution order by trial. Three checkpoint seeds by four disjoint training-index windows, shared across seeds. Full eight-expert raw-weight endpoint evaluation with pending routing adjustments.'
p['expansion_rule']='User requests 16384 updates. Stop at 16384; report all declared horizons, no adaptive expansion or pruning.'
p['confirmation_rule']='Twelve paired windows through 16384. No selection or separate confirmation stage.'
p['projection_comparison']='Compare against the completed 4096-update study and its brief near-tie at1536. New disjoint windows; this is not an exact continuation of saved4096 endpoints. The 4096 outputs did not preserve final optimizer checkpoints.'
p['authorization']='User requested16384 updates, RNO2A interactive requested, at most256H100 concurrently, no cumulative GPU-hour gate. Twelve8H100jobs=96H100peak. No architecture changes.'
p['screen_rule']='Report all12pairedwindows and per-seed values through16384, acceptance, matched-update cost and matched-loss cost. Acceptance remains the prior usefulness check, not an efficiency claim.'
p['primary_analysis'] += ' Extend the same predeclared common-loss target grid with0.35,0.40,0.45,0.50,0.60,0.70,0.80,1.00nats/token; preserve uncrossed targets.'
p['common_loss_targets']=[.02,.05,.10,.15,.20,.25,.30,.35,.40,.45,.50,.60,.70,.80,1.0]
intervals=[(p['training_batch_start']+t*p['training_window_stride'],p['training_batch_start']+t*p['training_window_stride']+16384) for t in p['trial_ids']]
assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:]))
assert intervals[-1][1]<p['check_batch_start']<p['fresh_batch_start']
assert intervals[0][0]>301016
for name,d in [('crossover-k4-16384-v1.json',p)]+[(f'crossover-k4-16384-p{t}-v1.json',dict(p,trial_ids=[t])) for t in p['trial_ids']]:
    for path in (R/name,R/'marin/experiments/grug'/name):
        assert not path.exists();path.write_text(json.dumps(d,indent=2)+'\n')
launch=R/'run-crossover16k.sh';assert not launch.exists()
launch.write_text((R/'run-crossover.sh').read_text().replace('--timeout 7200','--timeout 18000'));launch.chmod(0o755)
check=(R/'scratch/check-crossover-schedule.py').read_text().replace('5121','17409').replace('5120','17408').replace('crossover-schedule-check','crossover16k-schedule-check')
(R/'scratch/check-crossover16k-schedule.py').write_text(check)
print('Frozen',len(p['horizons']),'horizons; unchanged22runtimefiles;96H100;5hour timeout, not target runtime.')
