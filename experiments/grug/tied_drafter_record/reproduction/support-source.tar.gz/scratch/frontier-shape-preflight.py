"""Check state compatibility for the requested active-expert frontier."""
import json
from collections import Counter
from dataclasses import replace
from pathlib import Path

import draccus
import equinox as eqx
import jax
import jmp
from jax.sharding import AbstractMesh, AxisType, use_abstract_mesh

from experiments.grug.fast_track.optimizer import GrugMoeMuonHConfig
from experiments.grug.fast_track.train import initial_state
from experiments.grug.noise_belay.candidate11 import REFERENCE, load_model_config
from experiments.grug.tied_drafter.calibration import MODEL_SOURCE_SHA256
from experiments.grug.tied_drafter_endpoints import check_state_coordinates

record = json.loads(REFERENCE.read_text())['config']
cfg = load_model_config(source_sha256=MODEL_SOURCE_SHA256)
optimizer = draccus.decode(GrugMoeMuonHConfig, record['optimizer']).build(record['trainer']['trainer']['num_train_steps'])
mp = jmp.get_policy('params=float32,compute=bfloat16,output=bfloat16')
key = jax.random.PRNGKey(0)
mesh = AbstractMesh((1,1,8,1), ('replica_dcn','data','expert','model'), axis_types=(AxisType.Explicit,)*4)
with use_abstract_mesh(mesh):
    native = eqx.filter_eval_shape(initial_state, cfg, optimizer=optimizer, mp=mp, key=key, ema_beta=record['trainer']['ema_beta'])
    result = {'scope':'Shape/dtype/path compatibility only; no GPU frontier trial has run.', 'native_state_leaves':len(jax.tree.leaves(native)), 'state_dtypes':dict(Counter(str(x.dtype) for x in jax.tree.leaves(native))), 'variants':[]}
    for active in [6,4,2,1]:
        draft = eqx.filter_eval_shape(initial_state, replace(cfg,num_experts_per_token=active), optimizer=optimizer, mp=mp, key=key, ema_beta=record['trainer']['ema_beta'])
        check_state_coordinates(native,draft)
        result['variants'].append({'active_experts':active,'compatible':True})
Path('../measurements/frontier-shape-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
