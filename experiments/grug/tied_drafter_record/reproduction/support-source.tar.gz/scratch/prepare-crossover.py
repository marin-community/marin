from pathlib import Path
import json,hashlib,copy
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
old=R/'marin/experiments/grug/tied_drafter_frontier.py'
new=R/'marin/experiments/grug/tied_drafter_crossover.py'
s=old.read_text().replace('Map endpoint rejection over active-expert counts and nested update horizons.','Measure long-block four-expert learning efficiency against native training.\n\nFrozen frontier driver adapted only to permit a declared native learning-rate\nfloor tail and record its schedule. The original experiment source is preserved.')
s=s.replace('    if protocol["checkpoint_step"] + max(horizons) > schedule_steps:\n        raise ValueError("Proposal would exceed the native learning-rate schedule")','''    if protocol["schedule_steps"] != schedule_steps or protocol["learning_rate_tail"] != "native_floor":
        raise ValueError("This continuation preserves the native schedule and its existing floor tail")
    if protocol["checkpoint_step"] + max(horizons) != protocol["final_optimizer_step"]:
        raise ValueError("Continuation clock differs from the declared endpoint")''')
s=s.replace('        "status": "initializing",','        "status": "initializing",\n        "schedule_steps": schedule_steps,\n        "learning_rate_tail": protocol["learning_rate_tail"],')
assert not new.exists();new.write_text(s)
p=json.loads((R/'frontier-screen-v1.json').read_text())
p.update(phase='four-expert crossover through4096 updates',frozen_at=datetime.now(timezone.utc).isoformat(),trial_ids=[0,1,2,3],active_experts=[8,4],horizons=[64,128,256,512,768,1024,1280,1536,1674,1792,2048,2304,2560,2816,3072,3328,3584,3840,4096],training_batch_start=200000,training_window_stride=8192,check_batch_start=300000,fresh_batch_start=301000,schedule_steps=2698,learning_rate_tail='native_floor',final_optimizer_step=5120)
p['implementation_sha256']['experiments/grug/tied_drafter_crossover.py']=hashlib.sha256(new.read_bytes()).hexdigest()
p['clock_policy']='Restore complete checkpoint at1024; advance through5120. Build unchanged native optimizer with schedule_steps2698: Muon power decay and Adam cosine reach existing5% floors at2698 and remain there. No schedule rescaling, restart, moment reset or EMA policy change. First1674updates are within original schedule; later2422updates are floor-tail continuation.'
p['comparison']='Four-expert and native8 trajectories on the same allocation, starting state, new disjoint training window, and shared check/fresh batches. Rotate variant execution order by trial. Raw full-model weights evaluated with8experts and pending quantile state.'
p['screen_rule']='Report all12pairedwindows and per-seed values, acceptance, matched-update cost, and matched-loss cost. The endpoint check remains the prior relaxed acceptance rule; it is not a speedup claim.'
p['expansion_rule']='User requests4096updates. Stop at4096; no adaptive expansion or pruning based on intermediate results.'
p['confirmation_rule']='This is a new paired crossover test with all12windows run through4096; no winner selection or separate confirmation stage.'
p['primary_analysis']='Primary: paired cost to common fresh-loss reductions0.02,0.05,0.10,0.15,0.20,0.25,0.30nats/token from the common checkpoint. Report observed crossing intervals and uncrossed targets; interpolate only bracketed targets. Also compare draft endpoints with native at equal minimal execution cost where native observations bracket that cost. Call an observed sustained crossover only when draft has positive paired median equal-cost advantage at three consecutive measured draft horizons, with per-seed and12pair counts shown; disclose the interpolation. Report raw measured endpoint dominance when available. No claim of first exact crossing or population confidence.'
p['projection_comparison']='Earlier constant-slope projections are hypotheses. Show measured curve against those predictions; do not re-fit the old projection using this run. New windows mean comparison is across comparable experiments, not exact trajectory continuation.'
p['cost']='Minimal proposal cost includes updates+initialcopy+baselinecheck+candidatecheck; native update execution denominator. Also report every prefix check, calibration, fresh monitoring, data preload, restore/compile and whole-job allocation separately. Both use8H100; GPU-hours=executionseconds*8/3600. No full production latency claim from preloaded data.'
p['authorization']='User requested4096-update crossover test; RNO2A interactive requested, at most256H100concurrently, no cumulative GPU-hour gating. Twelve jobs8H100each:96H100peak; no additional experiments scheduled.'
for t in p['trial_ids']:
 interval=range(p['training_batch_start']+t*p['training_window_stride'],p['training_batch_start']+t*p['training_window_stride']+max(p['horizons']))
 assert p['check_batch_start']+t not in interval
 assert all(p['fresh_batch_start']+u*p['monitor_batches']+j not in interval for u in p['trial_ids'] for j in range(p['monitor_batches']))
for name,d in [('crossover-k4-4096-v1.json',p)]+[(f'crossover-k4-4096-p{t}-v1.json',dict(p,trial_ids=[t])) for t in p['trial_ids']]:
 b=json.dumps(d,indent=2)+'\n'
 for path in (R/name,R/'marin/experiments/grug'/name):
  assert not path.exists();path.write_text(b)
launcher=(R/'run-frontier.sh').read_text().replace('experiments.grug.tied_drafter_frontier','experiments.grug.tied_drafter_crossover')
(R/'run-crossover.sh').write_text(launcher);(R/'run-crossover.sh').chmod(0o755)
print('Prepared frozen crossover protocols and dedicated driver; model/optimizer sources unchanged.')
