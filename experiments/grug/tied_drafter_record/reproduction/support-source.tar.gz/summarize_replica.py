"""Render the full-width replica sanity result without inventing a tolerance."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
raw = json.loads((ROOT / 'measurements/replica-v1/replica.json').read_text())
if raw['status'] != 'complete':
    raise ValueError('The sanity probe is incomplete')
rows = []
for row in raw['checks']:
    values = row['batches']
    rows.append({
        'continuation_updates': row['continuation_updates'],
        'max_sequence_loss_difference': max(b['sequence_loss_difference']['max_absolute'] for b in values),
        'max_repeated_forward_loss_difference': max(b['repeat_forward_difference']['max_absolute'] for b in values),
        'max_sampled_target_loss_difference': max(b['sampled_target_loss_difference']['max_absolute'] for b in values),
        'minimum_top5_id_agreement': min(b['top5_ids_agreement'] for b in values),
        'max_top5_probability_difference': max(b['top5_probability_difference']['max_absolute'] for b in values),
        'parameter_difference': row['parameters'],
        'complete_state_difference': row['complete_state'],
        'hero_losses': [b['hero_loss'] for b in values],
        'replica_losses': [b['replica_loss'] for b in values],
    })
initial = rows[0]
exact_prediction = all(initial[k] == 0 for k in ('max_sequence_loss_difference','max_sampled_target_loss_difference','max_top5_probability_difference')) and initial['minimum_top5_id_agreement'] == 1
exact_continuation = all(r['complete_state_difference']['exact_equal'] for r in rows)
verdict = ('The full-width replica reproduced all checked initial losses and predictions exactly.' if exact_prediction else 'The copied full-width state is exact, but evaluated predictions show numerical differences; see measured deviations below.')
continuation = ('Both branches also retained exact complete-state equality through 16 ordinary updates.' if exact_continuation else 'Matched continuation did not remain exactly equal; the table reports the divergence without applying a posthoc pass threshold.')
table = ''.join(f"<tr><td>{r['continuation_updates']}</td><td>{r['max_sequence_loss_difference']:.3g}</td><td>{r['max_repeated_forward_loss_difference']:.3g}</td><td>{100*r['minimum_top5_id_agreement']:.6f}%</td><td>{r['parameter_difference']['max_absolute']:.3g}</td><td>{r['parameter_difference']['relative_rms']:.3g}</td></tr>" for r in rows)
html = f'''<section id="replica-sanity"><h2>Follow-up: full-width tied-replica sanity check</h2>
<p>{verdict} {continuation}</p>
<p>After 256 ordinary updates, the same full-width coordinate restriction code produced a replica with all {raw['parameter_count']:,} parameters retained. The coordinate map selected each tensor’s entire extent without reordering or rescaling it, then reconstructed the same model structure. A detached copy included native optimizer moments, EMA, router-balancing state and step counter. Initial complete-state array equality passed. Both branches then used the same native update executable and the exact same next 16 batches on one eight-H100 mesh. The recorded recipe disables Gumbel routing noise, ERC auxiliary noise and future-token subsampling; the native update passes no routing RNG key for this configuration. Both branches also have the same step counter. This is a sequential replication check, with no narrowing, optimizer reset or asynchronous transfer.</p>
<table><thead><tr><th>Continuation updates</th><th>Maximum per-sequence loss difference</th><th>Repeated-forward loss difference</th><th>Minimum top-5 ID agreement</th><th>Maximum weight difference</th><th>Relative RMS weight difference</th></tr></thead><tbody>{table}</tbody></table>
<p>Each checkpoint evaluates two full 128 × 4,096-token batches starting at reserved mixture indices 50000 and 50001. Loss differences cover all 256 sequence means; sampled token predictions cover 96 positions per batch, reporting top-five IDs/probabilities and actual-next-token loss through the native soft-capped prediction head. Top-five agreement is rank-by-rank ID agreement, taking the lower value across the two batches; it is not whole-set or top-one accuracy. Sampled positions are fixed across branches/checkpoints: sequence rows 0, 8, …, 120 and token positions 0, 31, 255, 1023, 2047 and 4094. These checks do not compare the entire vocabulary distribution at every position. Relative RMS weight difference is the square root of the sum of squared parameter differences divided by the sum of squared hero parameters, aggregated globally over all parameter elements. Repeated-forward differences use the unchanged hero on the same batch.</p>
<p>The first continuation update had identical logged training loss in both branches (2.7016487), yet its resulting weights already differed. By update 16, relative RMS weight difference was 2.575%, while the two reserved-batch mean loss differences (replica minus hero) were +0.0002866 and −0.0002027. Repeated forwards on unchanged hero weights remained exact. This reveals non-reproducibility in the native continuation/update path; this probe does not isolate the responsible backward kernel or optimizer behavior. It also does not establish a 64-update noise floor for the earlier late-gain experiments.</p>
<p>Identical weights are sufficient to specify the same current model function. Predicting subsequent optimizer updates also requires matching moments, step-dependent schedules, router state and data. This control matches those quantities; the narrowed drafter used reset AdamW instead. Agreement here cannot establish useful incremental progress from applying a proposal to a hero that has already trained concurrently on the same examples.</p>
<p>Sources: <a href="measurements/replica-v1/replica.json">complete replica measurements</a>, <a href="replica-sanity-protocol.json">predeclared check</a>, <a href="marin/experiments/grug/tied_replica_sanity.py">probe source</a>, <a href="run-replica-sanity.sh">launcher</a>, and <a href="measurements/replica-cpu-test.txt">CPU forward/gradient identity check</a>.</p></section>'''
summary = {'exact_initial_checked_predictions':exact_prediction,'exact_continuation_complete_state':exact_continuation,'checkpoints':rows,'report_html':html}
(ROOT / 'measurements/replica-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='report_html'},indent=2))
