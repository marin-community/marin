"""Aggregate completed drafter latency screens without mixing calibration and confirmation."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def aggregate(raw):
    if raw["status"] != "complete":
        raise ValueError("Cannot summarize an incomplete sweep")
    names = [row["name"] for row in raw["replicas"]]
    if len(names) != len(set(names)) or "identity" not in names:
        raise ValueError("A sweep needs unique variants and an identity control")
    summary = []
    for row in raw["replicas"]:
        if len(row["batches"]) != len(raw["batch_indices"]):
            raise ValueError(f"Missing batches for {row['name']}")
        hero_ids = np.concatenate([b["hero_top5_ids"] for b in row["batches"]])
        replica_ids = np.concatenate([b["replica_top5_ids"] for b in row["batches"]])
        positions = sum(b["sampled_valid_positions"] for b in row["batches"])
        if hero_ids.shape != replica_ids.shape or len(hero_ids) != positions or positions == 0:
            raise ValueError("Prediction counts or shapes disagree")
        matches = int(np.count_nonzero(hero_ids[:, 0] == replica_ids[:, 0]))
        hero_loss = np.concatenate([b["hero_sequence_losses"] for b in row["batches"]])
        replica_loss = np.concatenate([b["replica_sequence_losses"] for b in row["batches"]])
        counts = np.concatenate([b["sequence_token_counts"] for b in row["batches"]])
        hero_ce = float(np.average(hero_loss, weights=counts))
        replica_ce = float(np.average(replica_loss, weights=counts))
        candidate_times = np.asarray(row["forward_seconds"])
        control_times = np.asarray(row["paired_hero_forward_seconds"])
        if candidate_times.shape != control_times.shape or not np.all(candidate_times > 0):
            raise ValueError("Invalid paired timing series")
        if not np.all(control_times > 0):
            raise ValueError("Invalid reference timing series")
        if row["name"] == "identity" and (matches != positions or not np.array_equal(hero_loss, replica_loss)):
            raise ValueError("Identity control failed")
        summary.append({
            "name": row["name"],
            "parameters": row["parameters"],
            "linear_compute_fraction": row["linear_compute_fraction"],
            "sampled_positions": positions,
            "top1_matches": matches,
            "top1_agreement": matches / positions,
            "top5_set_overlap": float((hero_ids[:, :, None] == replica_ids[:, None, :]).any(axis=2).mean()),
            "scored_tokens": float(counts.sum()),
            "hero_cross_entropy": hero_ce,
            "replica_cross_entropy": replica_ce,
            "cross_entropy_increase": replica_ce - hero_ce,
            "perplexity_ratio": float(np.exp(replica_ce - hero_ce)),
            "median_forward_ms": float(1000 * np.median(candidate_times)),
            "median_paired_hero_ms": float(1000 * np.median(control_times)),
            "speed_ratio": float(np.median(control_times) / np.median(candidate_times)),
            "paired_speed_ratio_p10_p90": np.quantile(control_times / candidate_times, [0.1, 0.9]).tolist(),
            "timing_pairs": len(control_times),
        })
    for row in summary:
        row["pareto_candidate"] = row["name"] != "identity" and not any(
            other["top1_agreement"] >= row["top1_agreement"]
            and other["speed_ratio"] >= row["speed_ratio"]
            and (other["top1_agreement"] > row["top1_agreement"] or other["speed_ratio"] > row["speed_ratio"])
            for other in summary
        )
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=("calibration", "confirmation"), required=True)
    args = parser.parse_args()
    raw_bytes = args.input.read_bytes()
    raw = json.loads(raw_bytes)
    rows = aggregate(raw)
    result = {
        "phase": args.phase,
        "input_sha256": hashlib.sha256(raw_bytes).hexdigest(),
        "measurement_source_sha256": raw["source_sha256"],
        "checkpoint": raw["checkpoint"],
        "batch_indices": raw["batch_indices"],
        "scope": raw["scope"],
        "timing_note": "Paired timing percentiles describe within-job variation, not a confidence interval.",
        "sampling_note": "Fixed teacher-forced positions; no population-confidence or update-quality claim.",
        "replicas": rows,
    }
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("Variant                    Top-1 agreement    CE increase    Forward ms    Speed ratio")
    for row in rows:
        print(f"{row['name']:26} {100 * row['top1_agreement']:12.2f}% "
              f"{row['cross_entropy_increase']:14.4f} {row['median_forward_ms']:13.2f} "
              f"{row['speed_ratio']:13.3f}")


if __name__ == "__main__":
    main()
