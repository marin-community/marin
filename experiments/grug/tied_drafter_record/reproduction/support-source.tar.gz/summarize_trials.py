"""Summarize bounded proposal trials; keep hypothetical speed ratios separate from observations."""

import json
from pathlib import Path

import matplotlib
import numpy as np
from scipy.stats import t

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent


def paired_gain(before, after):
    gain = np.asarray(before) - np.asarray(after)
    error = gain.std(ddof=1) / np.sqrt(gain.size)
    margin = t.ppf(0.975, gain.size - 1) * error
    return {"mean": float(gain.mean()), "standard_error": float(error),
            "ci95": [float(gain.mean() - margin), float(gain.mean() + margin)]}


def main():
    summary = {"trials": [], "missing_horizons": [],
               "uncertainty": "Pointwise paired-group t intervals; possible group correlation and one initialization.",
               "speed_caveat": "Conditional ratios give credit for a rejected proposal's later benefit; they are not measured speedups."}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    colors = {8: "#216b96", 16: "#ad4b38", 32: "#578140"}
    for horizon in (8, 16, 32):
        source = ROOT / f"measurements/h{horizon}-v1-hero/trial.json"
        if not source.exists():
            summary["missing_horizons"].append(horizon)
            continue
        trial = json.loads(source.read_text())
        assert trial["status"] == "complete"
        native = {r["continuation_updates"]: r for r in trial["persistence"]["native"]}
        rows = []
        for branch in ("draft", "extrapolation"):
            for row in trial["persistence"][branch]:
                step = row["continuation_updates"]
                rows.append({"branch": branch, "updates": step,
                             "persistence": paired_gain(native[step]["groups"], row["groups"]),
                             "target": paired_gain(native[step]["target_groups"], row["target_groups"])})
        late = next(r for r in rows if r["branch"] == "draft" and r["updates"] == 64)
        control_rate = (np.mean(native[16]["groups"]) - np.mean(native[64]["groups"])) / 48
        equivalent = late["persistence"]["mean"] / control_rate
        duration = trial["draft_overlap_seconds"] + trial["production_snapshot_seconds"] + trial["verification_pause_seconds"]
        hypothetical = ((trial["staleness_steps"] + 0.8 * equivalent) * trial["native_step_seconds"] / duration)
        record = {"horizon": horizon, "accepted": trial["accepted"], "selected_scale": trial["selected_scale"],
                  "staleness": trial["staleness_steps"], "operational_episode_seconds": duration,
                  "snapshot_pause_seconds": trial["production_snapshot_seconds"],
                  "verification_pause_seconds": trial["verification_pause_seconds"],
                  "draft_overlap_seconds": trial["draft_overlap_seconds"],
                  "initial_candidates": [{"scale": c["scale"], **c["decision"]} for c in trial["candidates"]],
                  "persistence": rows, "local_continuation_loss_per_step": float(control_rate),
                  "provisional_extra_steps_at_64": float(equivalent),
                  "hypothetical_speed_ratio_at_80_percent_acceptance": float(hypothetical),
                  "committed_outcome": trial["committed_outcome"]}
        summary["trials"].append(record)
        points = [r for r in rows if r["branch"] == "draft"]
        axes[0].plot([r["updates"] for r in points], [r["persistence"]["mean"] for r in points],
                     "o-", color=colors[horizon], markersize=4, label=f"{horizon} draft updates")
        ci = late["persistence"]["ci95"]
        value = late["persistence"]["mean"]
        axes[1].errorbar(str(horizon), value, yerr=[[value - ci[0]], [ci[1] - value]],
                         fmt="o", capsize=5, color=colors[horizon])
    axes[0].set_xscale("symlog", linthresh=1, base=2)
    axes[0].set_xticks([0, 1, 4, 16, 64], ["0", "1", "4", "16", "64"])
    axes[0].set(title="Diagnostic draft branch versus native", xlabel="Matched continuation updates",
                ylabel="Native loss minus draft loss")
    axes[0].legend(frameon=False, fontsize=8)
    axes[1].set(title="Gain after 64 updates (nominal 95% CI)", xlabel="Draft updates per proposal",
                ylabel="Positive means lower draft-branch loss")
    for axis in axes:
        axis.axhline(0, color="#555", linewidth=0.8)
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(alpha=0.15)
    fig.savefig(ROOT / "measurements/persistence.svg")
    fig.savefig(ROOT / "measurements/persistence.png", dpi=160)
    (ROOT / "measurements/trial-summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
