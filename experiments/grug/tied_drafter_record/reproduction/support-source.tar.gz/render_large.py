"""Render the frozen six-strategy transfer test at matched evaluation batches."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT/'measurements'/name).read_text())

selection=read('top-six-selection.json')
small=read('small-finalists-confirmation-summary.json')
large=read('large-finalists-summary.json')
training=read('large-train-v4/training.json')
audit=read('large-model-audit.json')
assert training['status']=='complete' and training['completed_updates']==2116
assert small['batch_indices']==large['batch_indices']==[57000,57001,57002,57003]
smap={r['name']:r for r in small['replicas']};lmap={r['name']:r for r in large['replicas']}
labels={'fp8_dispatch':'FP8 dispatch','fp4_expert_inputs':'FP4 input roundtrip','fp4_expert_weights':'FP4 weight roundtrip','k6_gain1':'6 experts, gain 1','k6_gain0.75':'6 experts, gain 0.75','gate_half':'Constant output gates ×0.5','k4_gain0.75':'4 experts, gain 0.75'}
rows=[]
for name in selection['selected_variants']:
    a,b=smap[name],lmap[name]
    rows.append(f"<tr><td>{labels.get(name,name)}</td><td>{100*a['top1_agreement']:.2f}%</td><td>{100*b['top1_agreement']:.2f}%</td><td>{a['speed_ratio']:.3f}× / {b['speed_ratio']:.3f}×</td><td>{b['median_forward_ms']:.2f}</td><td>{b['cross_entropy_increase']:+.4f}</td></tr>")
fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
colors=['#16776c','#4868ac','#b25b26','#79549d','#9b3942','#647640']
for i,name in enumerate(selection['selected_variants']):
    a,b=smap[name],lmap[name]; label=labels.get(name,name)
    axes[0].plot([1,2],[100*a['top1_agreement'],100*b['top1_agreement']],'-o',label=label,color=colors[i])
    axes[1].plot([1,2],[a['speed_ratio'],b['speed_ratio']],'-o',color=colors[i])
for ax in axes:
    ax.set_xticks([1,2],['1.03B reference','3.18B reference']);ax.grid(alpha=.15);ax.set_xlim(.8,2.2)
axes[0].set_ylabel('Top-1 agreement with that reference (%)');axes[0].set_title('Agreement on matched fresh batches')
axes[1].set_ylabel('Native / candidate forward time');axes[1].set_title('Within-model paired speed ratios');axes[1].axhline(1,color='#999999',ls='--',lw=1)
fig.legend(*axes[0].get_legend_handles_labels(),loc='outside lower center',ncol=3,fontsize=9)
fig.savefig(ROOT/'measurements/large-transfer.svg');fig.savefig(ROOT/'measurements/large-transfer.png',dpi=150);plt.close(fig)
fastest=max((lmap[n] for n in selection['selected_variants']),key=lambda x:x['speed_ratio'])
best=max((lmap[n] for n in selection['selected_variants']),key=lambda x:x['top1_agreement'])
html=f'''<section id="large-model"><h2>Six small-model finalists evaluated on the larger model</h2>
<p>The enlarged reference has {audit['parameters']:,} parameters, 12 blocks and 1,024 experts per block. It still selects eight experts per token. Among the six transferred configurations, {labels.get(best['name'],best['name'])} retains the most agreement ({100*best['top1_agreement']:.2f}%). The fastest measured configuration is {labels.get(fastest['name'],fastest['name'])}, at {fastest['speed_ratio']:.3f}× native forward speed and {100*fastest['top1_agreement']:.2f}% agreement. These are forward-only results at one trained checkpoint; no training-update or pretraining speedup is established.</p>
<p>Selection used all 44 small-model configurations on the same batches 56000–56003. The two exact identity controls were excluded. The top six were ranked by top-1 agreement, with lower cross-entropy and then faster forward time as tie-breakers. They are configurations, so two gain settings of one expert-count strategy may both qualify. Hyperparameters were frozen before larger-model scoring. Both model sizes were then evaluated on the same fresh batches 57000–57003, with 4,096 sampled positions per configuration, full-batch cross-entropy and 20 alternating timing pairs. The table reports agreement with each model’s own native predictions.</p>
<p>Top-1 agreement compares each approximation with its own full reference model. Δ CE is the approximation’s minus the reference’s cross-entropy, in nats per token; positive means worse. The six-expert variants retain the six highest-scoring learned routes. Gain 1 normalizes their combined router weights to sum to 2.5; gain 0.75 lowers that sum to 1.875. Constant output gates replace the learned attention and feedforward block-output gates with multiplication by 0.5.</p>
<table><thead><tr><th>Configuration</th><th>Small agreement</th><th>Large agreement</th><th>Speed: small / large</th><th>Large forward ms</th><th>Large Δ CE</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<p>Native forward medians are {smap['identity']['median_forward_ms']:.2f} ms for the small reference and {lmap['identity']['median_forward_ms']:.2f} ms for the large reference. Each speed ratio uses that candidate’s own paired native median. Ratios near 1 should not be read as established gains across runs. FP4 weights are decoded before timing and still use dense matrix multiplies; FP4 inputs are decoded before ordinary dispatch. Their timing does not measure native FP4 compute or packed FP4 communication.</p>
<figure><img src="measurements/large-transfer.svg" alt="Agreement and forward speed of the six fixed configurations across the two model sizes."><figcaption>Matched evaluation tokens and eight-H100 topology; independently trained reference models. Lines connect corresponding recipes and do not represent a fitted scaling law.</figcaption></figure>
<h3>What doubled, and how the reference was trained</h3>
<p>The original six-block attention and full-width expert-write layout is repeated twice. Global-attention blocks are 4, 6, 10 and 12; the other blocks use KDA, a recurrent attention mechanism. Full-width expert output writes occur in blocks 5, 6, 11 and 12. In the other blocks, experts produce 256-channel outputs that a shared learned projection expands to the 512-channel residual stream. In the listed blocks, experts directly produce all 512 output channels and omit that expansion. Hidden width remains 512; expert and attention widths remain fixed. The residual-history capacity increases from 8 to 16 so each physical block retains its own segment: a saved sum of that block’s residual contributions, available to the learned attention over earlier residual states. Doubling both depth and expert-bank size gives four times the routed-expert weights, {audit['parameter_ratio']:.3f}× total parameters and approximately {audit['linear_compute_ratio']:.3f}× leading linear training FLOPs per global update relative to the small reference. This proxy counts active linear-weight work and the vocabulary head, excluding attention interactions, recurrent-state operations, optimizer work and transport; it is not a measurement of total compute. Embeddings and other shared costs do not all quadruple.</p>
<p>The larger model trains from initialization for 2,116 updates on the same data sequence as the small reference, with the original 2,698-step optimizer schedule and exponential-moving-average (EMA) settings. It is a matched-update comparison, not an equal-compute or equal-wall-time training comparison. Both see about 1.109 billion presented tokens; the larger reference therefore receives fewer training tokens per parameter. Differences across model sizes cannot be attributed to architecture alone. The completed training window took {training['training_seconds']/60:.2f} minutes, excluding setup, compilation and checkpoint serialization. Final minibatch training loss was {training['final_training_loss']:.4f}; this is not a validation score.</p>
<p>Full-batch training exceeded H100 memory in two attempts, including a retry with a larger allocator allowance. The successful run uses the native accumulation path over two 64-sequence microbatches per 128-sequence global update. This changes reduction order and averages per-microbatch routing statistics; it is not claimed to reproduce the full-batch trajectory exactly. One earlier attempt failed because the batch-fingerprint file was excluded from the bundle. All attempts are charged in the resource ledger. Only the experiment jobs were stopped; no cluster was restarted.</p>
<p>The model source remains the pinned Belay candidate 11 implementation, the six-block mixture-of-experts reference architecture used throughout this report, with the configuration changes listed above. The actual parameter count, first native batch fingerprint and final optimizer step count are checked; all recorded training losses are finite. EMA weights are serialized to the recorded regional checkpoint. This agreement artifact contains weights, not the complete optimizer state needed for the next training experiment. Both final native identity comparisons preserve per-sequence losses and sampled predictions exactly.</p>
<p><a href="finalist-selection-protocol.json">Common-batch selection protocol</a> · <a href="measurements/top-six-selection.json">Frozen six finalists</a> · <a href="large-transfer-protocol.json">Transfer protocol</a> · <a href="large-training-protocol-v4.json">Successful training protocol</a> · <a href="measurements/large-model-audit.json">Architecture audit</a> · <a href="measurements/large-train-v4/training.json">Training result</a> · <a href="measurements/finalist-selection-summary.json">All 44 common-batch scores</a> · <a href="measurements/small-finalists-confirmation-summary.json">Fresh small-model scores</a> · <a href="measurements/large-finalists-summary.json">Fresh large-model scores</a>.</p>
<h3>Follow-up: useful update endpoints per total compute</h3>
<p>The subsequent <a href="#endpoint-results">three-seed endpoint experiment</a> accepted all 36 blocks of 64 cheap updates, and all improved fresh loss from their starting states. Native training still retained lower loss at equal consumed data. That study uses the original 1.03B model, carries complete optimizer state and reports actual update/check/copy costs. The completed <a href="#frontier-results">boundary search above</a> tested longer blocks and faster drafters against a 10% observed rejection threshold.</p>
</section>'''
(ROOT/'measurements/large-section.html').write_text(html)
print('Rendered large-model transfer results.')
