"""Preserve completed W&B run status and episode timestamps for allocation accounting."""
import argparse
import json
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import wandb

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('input', type=Path)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--pod-record', type=Path, required=True)
args = parser.parse_args()
raw = json.loads(args.input.read_text())
parts = urlparse(raw['wandb_url']).path.strip('/').split('/')
if len(parts) != 4 or parts[2] != 'runs':
    raise ValueError('Unexpected W&B run URL')
run = wandb.Api().run('/'.join([parts[0], parts[1], parts[3]]))
if run.state != 'finished' or run.summary.get('completed') is not True:
    raise ValueError(f'W&B run is not complete: {run.state}')
history = list(run.scan_history(keys=['_timestamp', 'episode', 'cursor']))
if [row['episode'] for row in history] != list(range(raw['protocol']['episodes'])):
    raise ValueError('Missing or duplicate W&B episode observations')
for row, episode in zip(history, raw['episodes'], strict=True):
    if row['cursor'] != episode['end_cursor']:
        raise ValueError('W&B and raw output cursors disagree')
pod = json.loads(args.pod_record.read_text())
created = datetime.fromisoformat(pod['created'].replace('Z', '+00:00')).timestamp()
for row in history:
    row['study_allocated_gpu_hours'] = 8 * (row['_timestamp'] - created) / 3600
    if row['study_allocated_gpu_hours'] <= 0:
        raise ValueError('Episode timestamp predates pod creation')
args.output.write_text(json.dumps({'pod_created': pod['created'], 'url': raw['wandb_url'], 'state': run.state, 'completed': True, 'created_at': run.created_at, 'history': history}, indent=2) + '\n')
