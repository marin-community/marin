"""Render depth and model-size follow-ups into the existing report."""

import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'measurements/depth-summary.json').read_text())
rows=[]
for x in r['replicas']:
    name=x['name']
    if name=='activation_identity':continue
    if name.startswith('depth_drop'):label='Omit block '+str(int(name[-1])+1)+' (keep 5)'
    elif name.startswith('depth_keep'):label='Keep blocks '+', '.join(str(int(i)+1) for i in name.removeprefix('depth_keep'))
    else:label={'identity':'Full-depth copy (identity control)','k4_gain0.75':'All 6 blocks, 4 experts/token'}[name]
    rows.append(f"<tr><td>{label}</td><td>{100*x['top1_agreement']:.2f}%</td><td>{x['cross_entropy_increase']:+.4f}</td><td>{x['median_forward_ms']:.2f}</td><td>{x['speed_ratio']:.3f}×</td></tr>")
fig,ax=plt.subplots(figsize=(10,4.5),layout='constrained')
for count,color in [(5,'#4868ac'),(4,'#b25b26'),(3,'#79549d')]:
    selected=[x for x in r['replicas'] if (x['name'].startswith('depth_drop') and count==5) or (x['name'].startswith('depth_keep') and len(x['name'].removeprefix('depth_keep'))==count)]
    ax.scatter([x['speed_ratio'] for x in selected],[100*x['top1_agreement'] for x in selected],color=color,label=f'{count} surviving blocks',s=55)
for name,label in [('identity','Native'),('k4_gain0.75','6 blocks / 4 experts')]:
    x=next(x for x in r['replicas'] if x['name']==name);ax.scatter(x['speed_ratio'],100*x['top1_agreement'],marker='D',s=70,color='#16776c');ax.annotate(label,(x['speed_ratio'],100*x['top1_agreement']),xytext=(8,-5),textcoords='offset points')
ax.set(xlabel='Native forward time / candidate forward time',ylabel='Agreement with native top-1 token (%)',title='Removing depth loses more agreement than reducing expert count',xlim=(.95,2.08),ylim=(10,107));ax.legend(loc='lower left');ax.grid(alpha=.15)
fig.savefig(ROOT/'measurements/depth-agreement.svg');fig.savefig(ROOT/'measurements/depth-agreement.png',dpi=150);plt.close(fig)
html='''<section id="depth-results"><h2>Shallower tied replicas</h2>
<p>Every five-block variant is both slower and lower in agreement than the full-depth four-expert model. Deeper pruning buys additional speed at a substantial agreement cost. The highest-agreement five-block variant preserves 79.69% top-1 agreement at 1.182× forward speed. The highest-agreement tested four-block variant preserves 68.12% at 1.390×. Three-block variants range from 17.82% to 47.56% agreement. On these same batches, retaining all six blocks but using four experts per token preserves 90.28% at 1.297×.</p>
<p>The full reference model, also called the hero or native model, is the 1.03-billion-parameter Belay candidate 11 with six blocks and eight active experts per token. A tied replica here copies its surviving parameters from that same trained checkpoint; no further training or weight synchronization occurs. Top-1 agreement compares the replica’s highest-probability next token with the reference’s at fixed sampled positions. Positive Δ cross-entropy means worse loss than the reference, in nats per scored token.</p>
<p>Residual connections have been part of Transformers since <a href="https://arxiv.org/abs/1706.03762">the original architecture</a>: a conventional block adds attention and feedforward corrections to the incoming representation. Belay candidate 11 uses <a href="https://arxiv.org/abs/2603.15031">attention over residuals, or AttnRes</a>, which learns a mixture of earlier block representations. Skipping a block therefore changes the sources available to later layers. Our implementation removes the block’s computation and its residual-history entry. Surviving blocks keep their weights, attention types, attention masks and original learned queries for mixing residual sources. It does not substitute a zero source into the learned mixture or fine-tune after pruning.</p>
<p>The screen uses the same 2,116-update exponential-moving-average (EMA) checkpoint and eight-H100 mesh as the preceding study. It tests all six single-block omissions and six predetermined three-/four-block subsets on batches 55000–55001: 2,048 sampled positions, full-batch loss and 20 alternating timing pairs. Table labels use one-based block numbers; raw variant names use zero-based indices. Each timing ratio divides the paired reference median by the replica median. The full-depth copy is timed separately from its identical reference; timing noise allows its ratio to be 1.004×. The prototype retains bypassed arrays in storage, so these results establish reduced execution depth, not a measured reduction in resident parameter memory.</p>
<table><thead><tr><th>Configuration</th><th>Top-1 agreement</th><th>Δ cross-entropy</th><th>Forward ms</th><th>Speed ratio</th></tr></thead><tbody>@@ROWS@@</tbody></table>
<figure><img src="measurements/depth-agreement.svg" alt="Depth-pruned variants trade substantial token agreement for faster forwards; four-expert full-depth model retains much higher agreement."><figcaption>Each point is a different fixed layer selection. No recovery training, distillation or learned layer selection was tested.</figcaption></figure>
<p>The copied full-depth implementation matches the native reference exactly. For every pruned variant, zeroing all bypassed block parameters leaves per-sequence loss exactly unchanged, verifying that the skipped weights cannot affect the result. A more competitive shallow student may require distillation or training with variable depth; this screen does not test either approach.</p>
<p><a href="depth-protocol.json">Frozen depth protocol</a> · <a href="measurements/depth-v1/latency.json">Raw results</a> · <a href="measurements/depth-summary.json">Aggregated results</a> · <a href="measurements/depth-validation.json">Identity and bypass checks</a> · <a href="reproduction/depth-model.patch">Model diff</a>.</p>
</section>'''.replace('@@ROWS@@',''.join(rows))
(ROOT/'measurements/depth-section.html').write_text(html)
print('Rendered depth results.')
