"""Render the completed drafter-design screen into the existing experiment report."""

import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT / 'measurements' / name).read_text())

cal = read('latency-calibration-summary.json')
confirm = read('latency-confirmation-summary.json')
ablate = read('ablation-summary.json')
fp4 = read('fp4-confirmation-summary.json')
boundary = read('route-boundary-summary.json')
ledger = read('resource-ledger.json')
new_cost = sum(r.get('gpu_hours', 0) for r in ledger['runs'] if any(s in r['job_id'] for s in ('tied-drafter-latency', 'tied-drafter-ablations', 'tied-route-boundary', 'tied-drafter-fp4')))
labels = {
    'identity':'Native reference', 'activation_identity':'Activation-copy identity control',
    'k6_gain1':'6 learned experts, gain 1', 'k4_gain0.75':'4 learned experts, gain 0.75',
    'k2_gain0.75':'2 learned experts, gain 0.75', 'k1_gain0.75':'1 learned expert, gain 0.75',
    'fp8_dispatch':'FP8 expert dispatch', 'half_compute_baseline':'Half-compute width restriction',
    'quarter_compute_baseline':'Quarter-compute width restriction',
    'hash_k8':'8 token-hash experts', 'hash_k2':'2 token-hash experts',
    'drop_shared':'Remove shared expert', 'gate_half':'Replace learned output gates with ×0.5',
    'gate_identity':'Replace learned output gates with identity', 'rms_gain_only':'Remove block-input RMS; retain gain',
    'routed_relu':'Plain ReLU in routed experts', 'shared_relu':'Plain ReLU in shared experts',
    'all_experts_relu':'Plain ReLU in both expert branches',
    'fp4_expert_inputs':'FP4 expert-input roundtrip', 'k4_fp4_inputs':'4 experts + FP4 input roundtrip',
    'fp4_expert_weights':'FP4 expert-weight roundtrip', 'k4_fp4_weights':'4 experts + FP4 weight roundtrip',
    'ffn_half_norm':'Half expert width, norm selection', 'ffn_quarter_norm':'Quarter expert width, norm selection',
    'ffn_half_prefix':'Half expert width, prefix selection', 'ffn_quarter_prefix':'Quarter expert width, prefix selection',
}

def table(record, names=None):
    rows=[]
    for r in record['replicas']:
        if names is not None and r['name'] not in names:
            continue
        rows.append(f"<tr><td>{labels.get(r['name'], r['name'])}</td><td>{100*r['top1_agreement']:.2f}%</td><td>{r['cross_entropy_increase']:+.4f}</td><td>{r['median_forward_ms']:.2f}</td><td>{r['speed_ratio']:.3f}×</td></tr>")
    return '<table><thead><tr><th>Variant</th><th>Top-1 agreement</th><th>Δ cross-entropy</th><th>Forward, ms</th><th>Speed ratio</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table>'

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig, ax = plt.subplots(figsize=(10,5), layout='constrained')
plot_labels = {'identity':('Native', (8,-17)), 'k6_gain1':('6 experts',(8,6)), 'k4_gain0.75':('4 experts',(8,6)), 'k2_gain0.75':('2 experts',(8,6)), 'fp8_dispatch':('FP8',(8,8)), 'half_compute_baseline':('Half compute',(8,6)), 'quarter_compute_baseline':('Quarter compute',(-117,8))}
for r in confirm['replicas']:
    color = '#b25b26' if r['name']=='fp8_dispatch' else '#79549d' if 'baseline' in r['name'] else '#16776c'
    ax.scatter(r['speed_ratio'],100*r['top1_agreement'],s=70,color=color)
    label, offset=plot_labels[r['name']]
    ax.annotate(label,(r['speed_ratio'],100*r['top1_agreement']),xytext=offset,textcoords='offset points')
ax.axvline(1,color='#999999',linewidth=1,linestyle='--')
ax.set(xlabel='Native forward time / candidate forward time (higher is faster)',ylabel='Agreement with native top-1 token (%)',xlim=(.93,1.77),ylim=(15,110),title='Keep full-width features; execute fewer learned experts')
ax.grid(alpha=.15)
fig.savefig(ROOT/'measurements/latency-agreement.svg'); fig.savefig(ROOT/'measurements/latency-agreement.png',dpi=150); plt.close(fig)

fig, axes = plt.subplots(1,2,figsize=(12,4.5),layout='constrained',sharey=True)
for ax, capacity in zip(axes,(32,128)):
    for method, label, color in [('oracle','Future-route oracle','#16776c'),('recent','Previous window','#b25b26'),('token_id_forecast','Token-ID forecast','#4868ac'),('random','Random cache','#777777')]:
        rows=[r for r in boundary['aggregate'] if r['capacity_experts']==capacity and r['method']==method]
        ax.plot([r['window_tokens'] for r in rows],[100*r['hit_rate'] for r in rows],'-o',label=label,color=color,markersize=4)
    ax.set(xscale='log',xlabel='Tokens per window in one sequence',title=f'{capacity} resident experts out of 512',ylim=(0,105))
    ax.grid(alpha=.15)
axes[0].set_ylabel('Assignments served by selected expert set (%)')
axes[1].legend(fontsize=9,loc='upper right')
fig.savefig(ROOT/'measurements/route-cache-boundary.svg'); fig.savefig(ROOT/'measurements/route-cache-boundary.png',dpi=150); plt.close(fig)

comm_rows=[]
for row in boundary['communication']:
    if row['encoding']!='bf16': continue
    others={r['encoding']:r for r in boundary['communication'] if r['width']==row['width'] and r['rows_per_destination']==row['rows_per_destination']}
    comm_rows.append(f"<tr><td>{row['rows_per_destination']:,} × {row['width']}</td><td>{row['bytes_per_rank']/2**20:.0f}</td><td>{row['median_ms']:.3f}</td><td>{others['fp8']['median_ms']:.3f}</td><td>{others['fp4']['median_ms']:.3f}</td></tr>")

html = '''<section id="drafter-design">
<h2>Latest design screen: preserve features and reduce active experts</h2>
<p>Reducing the number of learned expert routes gives the strongest observed forward-latency versus token-agreement tradeoff. Six, four and two experts per token preserve 95.19%, 90.87% and 83.20% of the native model’s top-1 predictions at 1.139×, 1.295× and 1.520× forward speed. At this same checkpoint, models that shrink feature widths throughout the network to approximately half and quarter compute preserve only 40.62% and 25.61%. These measurements establish faster approximate forwards. They do not establish useful transferred training updates or faster pretraining.</p>
<p>The native reference is Belay candidate 11: 1.026 billion parameters, six layers, hidden width 512, 512 routed experts per layer and eight selected experts per token. Experts are feedforward modules; a learned router chooses eight for each token. All variants start from the same exponential-moving-average (EMA) weights saved after 2,116 training updates. They run BF16 computation on eight H100s with the native expert-parallel mesh, at RNO2A interactive priority. No variant is fine-tuned. The earlier replica-size results below used update 256 and are retained as a separate experiment.</p>
<p>Agreement means that two models choose the same highest-probability next token when given the same real-text prefix. It is measured at eight fixed positions in each of 128 sequences. It is neither accuracy against the true token nor a speculative-decoding acceptance rate. Cross-entropy is scored across valid tokens in each full 128 × 4,096 batch; positive Δ means worse loss. Timings are warmed loss forwards, excluding compilation, data loading, weight construction and hero-to-drafter weight synchronization. Timers wait for GPU completion and include any communication inside the forward. Each candidate has 20 paired, alternating measurements against the native reference on the first batch. All variants in a comparison use the same hardware and batches. Each speed ratio divides that candidate’s paired native median by its own median; it does not use the single native row as a common denominator. Independent timing noise therefore permits the identity control to read 1.003×.</p>
<h3>Fresh-batch confirmation</h3>
<p>The initial screen used batches 51000–51001. Settings selected from that screen were frozen before confirmation on batches 52000–52003: 4,096 sampled token positions and about two million loss-scored tokens. Selected expert outputs are combined using router weights normalized to sum to 2.5; gain 0.75 lowers that sum to 1.875. This scalar branch multiplier is separate from learned normalization gains. The learned router still selects the highest-scoring experts.</p>
@@CONFIRM@@
<figure><img src="measurements/latency-agreement.svg" alt="Six, four and two learned experts give progressively faster forwards with higher agreement than width-restricted models."><figcaption>Same-checkpoint, same-batch confirmation. Each point summarizes one run; this is not a confidence region across checkpoints or seeds.</figcaption></figure>
<p>Fewer active experts retain all stored expert weights. Six, four and two experts use approximately 93.0%, 86.0% and 78.9% of native leading linear FLOPs. Thus four experts is half of routed-expert execution, not half of total model compute. The half/quarter-compute controls restrict residual, attention, routed/shared feedforward and latent widths together, to 49.5%/25.2% of native leading linear FLOPs. Narrowing only each routed expert to half its channels has the same leading-linear estimate as four full-width experts, but measured only 1.034× speed and 83.69% agreement with weight-norm channel selection. Prefix channel selection was worse. The timing difference shows why arithmetic counts alone cannot rank these implementations.</p>
<p>Related work, <a href="https://arxiv.org/abs/2609.04575">Training-Free Halving of Activated Experts</a>, separates the number of executed experts from the router mass used for normalization. Our fixed-gain sweep tests a related idea; it does not implement that paper’s separate reference-set normalization. Layer-adaptive routing counts and joint training across counts remain untested.</p>
<h3>Cheaper activations, normalization and more aggressive sparsity</h3>
<p>Simply replacing squared ReLU with plain ReLU leaves latency near 62 ms while reducing agreement to 69–81%, depending on the branch changed. Removing block-input RMS normalization while preserving its learned gains gives 39.94% agreement and no speed gain. Replacing the learned block-output gates with a constant factor of 0.5 gives 92.14% agreement and 1.030× speed. Those gates include two small matrix multiplies; they are distinct from the input RMS normalizers.</p>
<p>Removing the shared expert, the feedforward branch that runs for every token, gives 77.93% agreement and 1.003× speed. Selecting routed experts with a fixed random table keyed by token ID gives 52.93% agreement with eight experts, or 50.39% with two. This hash baseline retains learned combine weights for the chosen experts. Random selection keeps the model runnable, but it is a poor quality fallback here. A random resident cache, evaluated below, is a different intervention: its misses can still be served by fetching the correct expert.</p>
<p>These were direct checkpoint edits with no recovery training. Their negative results do not rule out a student trained to use simpler nonlinearities. They do argue against spending more on these particular edits before addressing the larger expert-execution costs. Structured expert/channel removal actually changes executed shapes. Arbitrary zeroing of weights has not been benchmarked with a sparse kernel, so no speedup from unstructured sparsity is claimed.</p>
<details><summary>All activation, normalization and sparsity ablations: calibration batches</summary>@@ABLATE@@</details>
<details><summary>Initial expert-count, gain and channel-pruning screen</summary>@@CAL@@<p>Channel ranking uses ‖up‖⁴ × ‖down‖², a weight-only heuristic for squared-ReLU experts. It is not an activation-calibrated pruning method. The gain alternatives and these channel variants were evaluated on the calibration data only.</p></details>
<h3 id="fp4-results">FP4: low measured error; hardware speedup remains open</h3>
<p>A final fresh-batch test on 54000–54003 confirms 97.63% agreement after FP4 quantization/dequantization of routed-expert inputs. Quantizing/dequantizing the routed-expert weight matrices preserves 97.31%. With four experts, either approximation remains near 91% agreement. A one-expert candidate reaches 1.635× speed with 75.22% agreement. These seven variants were declared before the final run; expert-weight FP4 was a new error-tolerance pilot, not a previously selected recipe.</p>
@@FP4@@
<p>The format uses signed E2M1 values, an E4M3 scale per 16 values and an FP32 scale per row. It is NVFP4-inspired. <a href="https://docs.nvidia.com/deeplearning/transformer-engine/features/low_precision_training/nvfp4/nvfp4.html">NVIDIA’s NVFP4 recipe</a> instead specifies a tensor-wide FP32 scale and native hardware support on Blackwell. These H100 tests emulate the quantization error. Expert-input variants decode before ordinary BF16 dispatch; expert-weight variants decode once before timing and retain dense FP32 parameter storage with BF16 matrix multiplies. Neither measures native FP4 GEMM throughput, packed weight residency, training gradients or accumulated quantization error across updates.</p>
<p>FP8 dispatch quantizes token activations sent between expert-parallel GPUs, then converts them back to BF16 before expert computation. Expert weights and arithmetic are unchanged; output-combine and backward collectives retain their native dtype. This integrated variant preserves 99.19% agreement, but runs at 0.970× native speed in the fresh confirmation. Keep it as an option for larger or multinode models where communication may cost more. The present local result cannot establish that crossover.</p>
<h3>Does packing actually accelerate the exchange?</h3>
<p>A separate eight-H100 microbenchmark measures pack → all-to-all → unpack on normally distributed BF16 payloads. FP4 uses 148 bytes per 256-value row versus 512 bytes for BF16, a 3.46× payload reduction including scales. Packing overhead outweighs the saved traffic at the larger tested sizes. This is an activation exchange only: expert IDs, combine traffic and actual expert execution are excluded. The table gives medians of ten warmed measurements, without a cross-run confidence estimate.</p>
<table><thead><tr><th>Rows per destination × width</th><th>BF16 MiB per rank</th><th>BF16 ms</th><th>FP8 ms</th><th>FP4 ms</th></tr></thead><tbody>@@COMM@@</tbody></table>
<p>The smallest FP4 exchange is about 1.06× faster in this short sample; the largest width-256 case is about 0.63×. These prototype results support retaining compressed transport as a hardware-dependent option, while avoiding an end-to-end speed claim. CPU tests on eight virtual devices confirm that packing and the collective preserve the intended decoded row ordering.</p>
<h3 id="route-cache">Route forecasting and expert-cache boundary conditions</h3>
<p>Counts over all 128 sequences show that all 512 experts appear in every layer of both instrumented batches. Small resident expert sets therefore need a finer scheduling unit, such as a token window or microbatch, or must accept frequent fetches. <a href="https://marin.community/blog/2026/04/10/quantile-balancing/">Quantile balancing</a> adjusts routing biases to balance load; it does not determine the future token-to-expert schedule. At fixed weights, context still changes router scores.</p>
<p>For detailed window analysis, the offline test retains route arrays for only the first 16 sequences of batches 53100 and 53101. For each layer, a token-ID predictor estimates expert frequencies from the first batch and chooses a fixed-capacity expert set for each window in the second. Upcoming input token IDs are available during pretraining. Comparison sets come from the preceding window, uniform random selection, or an oracle that knows the future routes and selects the most frequent experts. The oracle is an upper bound for assignment-count coverage with one fixed expert set per window. Ties use expert-ID order; the previous-window baseline does not maintain a long-lived LRU cache.</p>
<p>A cache set contains expert identities per layer; each token contributes eight token-to-expert assignments. For a 32-expert set, the token-ID forecast serves 50.1% of single-token assignments versus 6.3% for random selection. At 16 tokens the forecast serves 30.2%, recent-use selection 33.3% and the oracle 64.7%. At 1,024 tokens even the oracle covers only 37.2%. A 128-expert set covers more: at 64 tokens, forecast/recent/oracle reach 61.0%/66.6%/89.8%. Those are per-sequence windows. Concurrent windows from many sequences can require a much larger shared working set.</p>
<figure><img src="measurements/route-cache-boundary.svg" alt="Expert-cache assignment coverage falls as token windows grow, with an oracle above recent-use, token-ID and random caches."><figcaption>Offline coverage on an instrumented, fixed-checkpoint graph. A hit counts an expert assignment, without weighting by its contribution to the output. It does not measure token agreement or avoided wall time.</figcaption></figure>
<p>Capturing routing arrays changes GPU compilation: relative hidden-state RMS differences versus the uncaptured graph are 0.74% and 0.42% for the two batches. Respectively 13.72% and 5.61% of elements differ, with maximum absolute differences 10.92 and 8.59. Repeated captured routes agree exactly, but equivalence to the uninstrumented graph is unverified. Treat these curves as exploratory boundaries for the captured model, not exact native route forecasts. The forward-latency and token-agreement screens above use separate uncaptured paths with exact identity controls.</p>
<p>Selective synchronization has a memory floor: routed-expert matrices account for 704.6 million of the 1,026.5 million parameters. Keeping every other weight resident leaves 31.35% of total parameter count even with no expert weights cached. Expert caching alone therefore cannot make the complete same-precision parameter store one-eighth the size. Quantizing or caching other large tables, or narrowing shared layers, would change that bound. Activations and optimizer state are additional costs.</p>
<p>The remaining useful test is a versioned prefetch/cache prototype over short windows, with a correct-expert fetch fallback and a separately scored approximate/random fallback. Measure bytes, stalls, synchronization age and model quality together. A forecast ahead in sequence position at fixed weights is not yet a forecast several optimizer updates ahead. Arrival order, missed routing-weight mass, router drift, selective weight synchronization and live cache speed have not been measured. The <a href="plan.html#route-forecast-followup">existing follow-up design</a> records those requirements.</p>
<h3>Limits, checks and reproduction for this screen</h3>
<p>The 32 configurations are bounded checkpoint probes. Reusing a calibration batch is intentional; only the indicated confirmation batches were fresh for the selected recipes. They are different loader indices, not proven document-disjoint test sets. Fixed sampled positions, one training checkpoint and one device topology limit generalization. No new optimizer updates or asynchronous proposals were run in this design screen. Higher top-1 agreement is a useful screening signal, but has not been shown to predict gradient alignment, update transfer or accepted training progress.</p>
<p>All native identity comparisons and the isolated activation-copy identity control preserve per-sequence loss and sampled predictions exactly. CPU checks cover checkpoint restoration, structured channel selection, all 32 shape/sharding traces, the FP4 codebook/zero case/packed size, packed collective ordering and an analytical route-cache example. Targeted repository lint passed. An initial checkpoint restore failed on a leaf without annotated sharding; that leaf is now explicitly replicated. No numeric tolerance was relaxed for these screens.</p>
<p>This iteration used @@NEWCOST@@ H100 GPU-hours including its failed attempt and output capture, with eight GPUs per job and peak concurrency sixteen. All jobs are terminal and outputs are preserved locally. The earlier proposed ten-GPU-hour first-stage allowance is not a cumulative gate on the subsequent user-authorized experiments.</p>
<ul><li>Protocols: <a href="latency-protocol-v2.json">initial screen</a>, <a href="latency-confirmation-protocol.json">first confirmation</a>, <a href="latency-ablations-protocol.json">ablations</a>, <a href="latency-fp4-confirmation-protocol.json">FP4/one-expert confirmation</a>, <a href="route-boundary-protocol.json">route/transport boundary</a>.</li>
<li>Raw results: <a href="measurements/latency-v2/latency.json">screen</a>, <a href="measurements/latency-confirm-v3/latency.json">confirmation</a>, <a href="measurements/ablations-v4/latency.json">ablations</a>, <a href="measurements/fp4-confirm-v5/latency.json">FP4</a>, <a href="measurements/route-boundary-v1/boundary.json">capture diagnostics and transport</a>, and <a href="measurements/route-boundary-summary.json">cache summaries</a>.</li>
<li>Reproduction: <a href="run-latency.sh">latency launcher</a>, <a href="run-route-boundary.sh">boundary launcher</a>, <a href="summarize_latency.py">latency analysis</a>, <a href="summarize_route_boundary.py">cache analysis</a>, <a href="render_latency.py">tables and figures</a>, <a href="reproduction/latency-manifest.json">source and artifact hashes</a>, <a href="measurements/resource-ledger.json">resource ledger with exact commands</a>.</li></ul>
</section>'''
for marker, value in {'@@CONFIRM@@':table(confirm), '@@ABLATE@@':table(ablate), '@@CAL@@':table(cal), '@@FP4@@':table(fp4), '@@COMM@@':''.join(comm_rows),'@@NEWCOST@@':f'{new_cost:.4f}'}.items():
    html=html.replace(marker,value)
(ROOT/'measurements/drafter-design-section.html').write_text(html)
print(f'Wrote design section and figures; iteration cost {new_cost:.4f} GPU-hours')
