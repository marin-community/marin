"""Plot fixed-window loss against arithmetic proxies and measured execution cost."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--summary', type=Path, default=ROOT / 'measurements/endpoint-main-summary.json')
parser.add_argument('--output', type=Path, default=ROOT / 'measurements/endpoint-cost-trajectories')
parser.add_argument('--allocation-records', type=Path, nargs='+')
args = parser.parse_args()
summary = json.loads(args.summary.read_text())
audit = json.loads((ROOT / 'measurements/architecture-audit.json').read_text())
calibration = json.loads((ROOT / 'measurements/latency-confirmation-summary.json').read_text())
ratio = next(r['linear_compute_fraction'] for r in calibration['replicas'] if r['name'] == 'k6_gain1')
hero_flops = 6 * audit['hero_linear_weight_equivalents'] * 128 * 4096
allocations = {}
if args.allocation_records:
    for path in args.allocation_records:
        record = json.loads(path.read_text())
        allocations[record['url']] = record
    if set(allocations) != {r['wandb_url'] for r in summary['runs']}:
        raise ValueError('Allocation records must match all result runs')
row_count = 3 if allocations else 2
fig, axes = plt.subplots(row_count, len(summary['runs']), figsize=(15, row_count * 4), squeeze=False, layout='constrained')
records = []
for column, run in enumerate(sorted(summary['runs'], key=lambda r: r['seed'])):
    raw = json.loads((ROOT / run['source']).read_text())
    treatment_loss = [run['initial_loss']] + [e['treatment_loss'] for e in run['episodes']]
    control_loss = [run['initial_loss']] + [e['control_loss'] for e in run['episodes']]
    native_flops = [0.0]; cheap_flops = [0.0]; conservative_flops = [0.0]
    native_gpu = [0.0]; cheap_gpu = [0.0]; conservative_gpu = [0.0]
    check_forwards = 0
    for index, (episode, source) in enumerate(zip(run['episodes'], raw['episodes'], strict=True), 1):
        check_forwards += 1 + len(source['trials'])
        native_flops.append((episode['cursor'] - run['initial_cursor']) * hero_flops)
        cheap_flops.append((64 * index * ratio + index + check_forwards / 3) * hero_flops)
        # Four initial anchor forwards plus 24 monitoring forwards per episode;
        # this deliberately charges both treatment and control monitoring.
        conservative_flops.append(cheap_flops[-1] + (4 + 24 * index) * hero_flops / 3)
        cost = episode['cost_seconds']
        online = sum(cost.get(k, 0) for k in ['draft_updates', 'treatment_native_updates', 'acceptance_forward'])
        native_gpu.append(8 * cost['control_updates'])
        cheap_gpu.append(8 * online)
        conservative_gpu.append(8 * (online + cost.get('state_copy', 0) + cost.get('monitor_forward', 0)))
    for row, datasets, scale in [(0, [native_flops, cheap_flops, conservative_flops], 1e15), (1, [native_gpu, cheap_gpu, conservative_gpu], 3600)]:
        ax = axes[row, column]
        for values, losses, label, color, style in zip(datasets, [control_loss, treatment_loss, treatment_loss], ['Native updates', 'Draft + checks', 'Draft + all copies/monitors'], ['#194f86', '#b14916', '#b14916'], ['-', '-', '--']):
            ax.plot([x / scale for x in values], losses, style, marker='.', color=color, label=label)
        ax.set_title(f"Initialization seed {run['seed']}")
        ax.set_xlabel('Leading linear FLOPs (10¹⁵)' if row == 0 else 'Timed GPU execution (GPU-hours)')
        ax.grid(alpha=.2)
        if column == 0: ax.set_ylabel('Fixed-window cross-entropy (nats/token)')
    if allocations:
        history = allocations[run['wandb_url']]['history']
        if [h['cursor'] for h in history] != [e['cursor'] for e in run['episodes']]:
            raise ValueError('Allocation history cursor mismatch')
        x = [h['study_allocated_gpu_hours'] for h in history]
        axes[2, column].plot(x, control_loss[1:], '-.', color='#194f86', label='Native')
        axes[2, column].plot(x, treatment_loss[1:], '-.', color='#b14916', label='Treatment')
        axes[2, column].set_xlabel('Whole paired-study allocation (GPU-hours)')
        axes[2, column].set_title(f"Initialization seed {run['seed']}")
        axes[2, column].grid(alpha=.2)
        if column == 0: axes[2, column].set_ylabel('Fixed-window cross-entropy (nats/token)')
    records.append({'seed': run['seed'], 'native_flops': native_flops, 'minimal_draft_flops': cheap_flops, 'conservative_draft_flops': conservative_flops, 'native_gpu_seconds': native_gpu, 'minimal_draft_gpu_seconds': cheap_gpu, 'conservative_draft_gpu_seconds': conservative_gpu})
axes[0, 0].legend(fontsize=8)
fig.savefig(args.output.with_suffix('.svg'))
fig.savefig(args.output.with_suffix('.png'), dpi=150)
args.output.with_suffix('.json').write_text(json.dumps({'native_linear_flops_per_update': hero_flops, 'draft_linear_ratio': ratio, 'allocation_records': allocations, 'scope': 'Arithmetic and timed execution concern post-warmup proposal episodes only. Whole-study allocation includes warmup, setup, paired control work and waits through each episode timestamp. Linear proxy excludes attention interactions, KDA recurrence, optimizer arithmetic and transport. Timed GPU execution excludes data/setup/checkpoint waits and is not total allocated job time. Whole job allocation is reported separately in the resource ledger.', 'runs': records}, indent=2) + '\n')
