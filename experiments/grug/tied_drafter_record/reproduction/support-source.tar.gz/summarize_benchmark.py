"""Compare first-observed target times; do not infer statistical speedup."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
native = json.loads((ROOT / 'measurements/bench-native-v2/benchmark.json').read_text())
draft = json.loads((ROOT / 'measurements/bench-draft-v2-hero/benchmark.json').read_text())
previous = json.loads((ROOT / 'measurements/bench-native-v1/benchmark.json').read_text())
assert native['status'] == draft['status'] == 'complete'
assert native['benchmark_protocol'] == draft['benchmark_protocol']
comparisons = []
rows = ''
for a, b in zip(native['target_attainment'], draft['target_attainment'], strict=True):
    assert a['target'] == b['target']
    if a['first_observed_wall_seconds'] is None or b['first_observed_wall_seconds'] is None:
        raise ValueError('A target was not attained; report censoring explicitly')
    ratio = a['first_observed_wall_seconds'] / b['first_observed_wall_seconds']
    comparisons.append({'target_loss': a['target'], 'native': a, 'draft': b, 'observed_native_over_draft_time_ratio': ratio})
    rows += f"<tr><td>{a['target']:.6f}</td><td>{a['first_observed_step']}</td><td>{a['first_observed_wall_seconds']:.2f} s</td><td>{b['first_observed_step']}</td><td>{b['first_observed_wall_seconds']:.2f} s</td><td>{ratio:.3f}×</td></tr>"
fig, ax = plt.subplots(figsize=(10,5.3), layout='constrained')
for label, record, color, style in [('Native v2',native,'#225f8c','-'),('Hero + draft v2',draft,'#b04934','-'),('Native v1 (shutdown failure)',previous,'#808080',':')]:
    ax.plot([r['wall_seconds'] for r in record['evaluation']], [r['loss'] for r in record['evaluation']],label=label,color=color,linestyle=style,marker='o',markersize=3)
for i, a in enumerate(native['target_attainment']):
    ax.axhline(a['target'],color='#999999',ls='--',lw=.8)
    ax.text(ax.get_xlim()[0]+.3,a['target']+.001,f"Target {i+1}",fontsize=9,color='#555555')
ax.set_xlabel('Seconds since first real update (includes validation and proposal overhead)')
ax.set_ylabel('Reserved-target cross-entropy loss')
ax.set_title('One-seed wall-clock measurements; target checks every eight updates')
ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.15);ax.legend(fontsize=9)
for ext in ['svg','png']:fig.savefig(ROOT / f'measurements/time-to-quality.{ext}',dpi=160)
html = f'''<p>The primary 16-step configuration was measured in a separate matched benchmark: native training on eight H100s versus the same hero plus a four-H100 drafter. Both ran from initialization through 368 real updates, used the same frozen target losses and checked them every eight updates from 256 onward. The two targets were set to the native calibration’s measured final-target losses at updates 288 and 320, before treatment; they were not chosen from candidate outcomes. No diagnostic forks run inside these arms. The clock starts before the first real update and includes data waits, target evaluation and proposal operations; initialization, compilation and matched forward/application warmup are outside this clock.</p>
<table><thead><tr><th>Target loss</th><th>Native first observed update</th><th>Native time</th><th>Draft arm first observed update</th><th>Draft arm time</th><th>Native time / draft time</th></tr></thead><tbody>{rows}</tbody></table>
<p>The proposal arrived at hero update {draft['proposal_ready_step']} from snapshot update {draft['snapshot_step']} ({draft['staleness_steps']} updates stale); acceptance was {str(draft['accepted']).lower()}. The complete 368-update training clocks were {native['training_wall_seconds']:.2f} s native and {draft['training_wall_seconds']:.2f} s with the drafter. Compile/forward warmup took {native['compile_and_forward_warmup_seconds']:.2f} s and {draft['compile_and_forward_warmup_seconds']:.2f} s respectively and is reported separately; full pod lifetime is included in GPU-hour accounting.</p>
<figure><img src="measurements/time-to-quality.svg" alt="Reserved-target loss against measured training wall time for native and draft arms"><figcaption>First-observed target attainment is quantized by the eight-update evaluation cadence. These lines connect measured points; they do not identify exact crossing times.</figcaption></figure>
<p>This is one paired-seed timing comparison, with no interval over independent runs. Native v1, whose output was complete before a shutdown crash, crossed the same targets at updates 288 and 328; native v2 crossed at 296 and 320. Their training losses already differ by about 10⁻⁶ in the first few updates and their trajectories diverge slightly thereafter. Seed and data matching therefore do not imply bitwise-identical independent GPU runs. Evaluation cadence, numerical variation and data-wait variation can move apparent crossing times. With no accepted update, a favorable ratio would not establish learning acceleration from drafting.</p>
<p>Sources: <a href="measurements/bench-native-v2/benchmark.json">clean native benchmark</a>, <a href="measurements/bench-draft-v2-hero/benchmark.json">draft-arm benchmark</a>, <a href="measurements/bench-draft-v2-draft/proposals.jsonl">draft timing</a>, <a href="measurements/bench-native-v1/benchmark.json">native run with shutdown failure</a>, and <a href="benchmark-protocol.json">frozen benchmark protocol</a>.</p>'''
result = {'comparisons':comparisons,'native_training_wall_seconds':native['training_wall_seconds'],'draft_training_wall_seconds':draft['training_wall_seconds'],'accepted':draft['accepted'],'limitation':'One paired seed, first-observed target crossings every eight updates, no statistical speedup claim','report_html':html}
(ROOT / 'measurements/benchmark-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='report_html'},indent=2))
