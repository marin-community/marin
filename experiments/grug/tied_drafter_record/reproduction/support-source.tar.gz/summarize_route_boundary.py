"""Estimate expert-cache boundaries from captured fixed-checkpoint routes."""

import argparse
import json
from pathlib import Path

import numpy as np

EXPERTS = 512
VOCAB = 16384
WINDOWS = (1, 4, 16, 64, 256, 1024)
CAPACITIES = (8, 32, 128, 256)


def counts_by_window(assignments):
    rows = assignments.shape[0]
    flat = assignments.reshape(rows, -1).astype(np.int64)
    encoded = np.arange(rows)[:, None] * EXPERTS + flat
    return np.bincount(encoded.reshape(-1), minlength=rows * EXPERTS).reshape(rows, EXPERTS)


def analyze(fit, evaluate):
    rng = np.random.default_rng(0)
    fit_tokens = fit["tokens"].reshape(-1).astype(np.int64)
    routes = evaluate["routes"]
    result = []
    for layer in range(routes.shape[0]):
        fitted = np.zeros((VOCAB, EXPERTS), dtype=np.float32)
        fit_routes = fit["routes"][layer].reshape(-1, routes.shape[-1]).astype(np.int64)
        np.add.at(fitted, (np.repeat(fit_tokens, fit_routes.shape[-1]), fit_routes.reshape(-1)), 1.0)
        seen = fitted.sum(axis=1) > 0
        prior = fitted.sum(axis=0)
        prior /= prior.sum()
        fitted[seen] /= fitted[seen].sum(axis=1, keepdims=True)
        fitted[~seen] = prior
        for window in WINDOWS:
            available = routes.shape[2] // window
            chosen = np.unique(np.linspace(1, available - 1, min(128, available - 1), dtype=int))
            current = np.stack([routes[layer, row, n*window:(n+1)*window]
                                for row in range(routes.shape[1]) for n in chosen])
            previous = np.stack([routes[layer, row, (n-1)*window:n*window]
                                 for row in range(routes.shape[1]) for n in chosen])
            tokens = np.stack([evaluate["tokens"][row, n*window:(n+1)*window]
                               for row in range(routes.shape[1]) for n in chosen])
            actual = counts_by_window(current)
            recent = counts_by_window(previous)
            # Sum in bounded chunks so long windows do not materialize N x W x E.
            forecast = np.zeros_like(actual, dtype=np.float32)
            for start in range(0, window, 16):
                forecast += fitted[tokens[:, start:start+16]].sum(axis=1)
            scores = {"oracle": actual, "recent": recent, "token_id_forecast": forecast,
                      "random": rng.random(actual.shape)}
            for method, score in scores.items():
                order = np.argsort(-score, axis=1, kind="stable")
                for capacity in CAPACITIES:
                    picks = order[:, :capacity]
                    hits = np.take_along_axis(actual, picks, axis=1).sum(axis=1)
                    result.append({"layer": layer, "window_tokens": window, "capacity_experts": capacity,
                                   "method": method, "windows": len(actual),
                                   "assignments": int(actual.sum()), "hits": int(hits.sum()),
                                   "hit_rate": float(hits.sum()/actual.sum()),
                                   "mean_experts_used": float((actual > 0).sum(axis=1).mean()),
                                   "fully_covered_window_fraction": float(np.mean(hits == actual.sum(axis=1))),
                                   "unseen_token_fraction": float(np.mean(~seen[tokens]))})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    record = json.loads((args.directory / "boundary.json").read_text())
    if record["status"] != "complete":
        raise ValueError("Incomplete boundary run")
    with np.load(args.directory / "routes-0.npz") as fit, np.load(args.directory / "routes-1.npz") as evaluate:
        rows = analyze(fit, evaluate)
    aggregate = []
    for window in WINDOWS:
        for capacity in CAPACITIES:
            for method in ("oracle", "recent", "token_id_forecast", "random"):
                selected = [r for r in rows if r["window_tokens"] == window and
                            r["capacity_experts"] == capacity and r["method"] == method]
                aggregate.append({"window_tokens": window, "capacity_experts": capacity, "method": method,
                                  "hit_rate": sum(r["hits"] for r in selected)/sum(r["assignments"] for r in selected),
                                  "mean_experts_used": float(np.mean([r["mean_experts_used"] for r in selected])),
                                  "fully_covered_window_fraction": float(np.mean([r["fully_covered_window_fraction"] for r in selected]))})
    communications = []
    for row in record["communication"]:
        control = next(r for r in record["communication"] if r["encoding"] == "bf16" and
                       r["width"] == row["width"] and r["rows_per_destination"] == row["rows_per_destination"])
        communications.append({**row, "median_ms": float(1000*np.median(row["seconds"])),
                               "speed_ratio": float(np.median(control["seconds"])/np.median(row["seconds"]))})
    output = {"scope": record["scope"], "per_layer": rows, "aggregate": aggregate,
              "capture_diagnostics": [{k: v for k, v in row.items() if k != "full_batch_expert_counts"}
                                      for row in record["routes"]],
              "uniform_independent_route_reference": [
                  {"window_tokens": w, "expected_distinct_experts": EXPERTS*(1-(1-8/EXPERTS)**w)} for w in WINDOWS],
              "random_cache_expected_hit_rate": {str(m):m/EXPERTS for m in CAPACITIES},
              "communication": communications,
              "full_batch_experts_used": [(np.asarray(r["full_batch_expert_counts"])>0).sum(axis=1).tolist() for r in record["routes"]],
              "limitations": "Instrumented graph changes hidden outputs relative to the uncaptured graph; routes are repeatable but native-route equivalence is unverified. One fixed checkpoint; token-ID predictor fits one batch and scores the next. Recent-use caches see the preceding actual window. Oracle uses future routes and is unattainable. Windows are within individual sequences, not across the parallel batch. Assignment counts are unweighted. No live cache, arrival-time, weight-staleness, synchronization, or end-to-end performance test."}
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
    for r in aggregate:
        if r["capacity_experts"] == 32:
            print(f"W={r['window_tokens']:4} {r['method']:18} hit={r['hit_rate']:.3f} "
                  f"union={r['mean_experts_used']:.1f} full={r['fully_covered_window_fraction']:.3f}")
    for r in communications:
        print(f"{r['encoding']:4} rows={r['rows_per_destination']:6} H={r['width']:4} "
              f"ms={r['median_ms']:.3f} speed={r['speed_ratio']:.2f}")


if __name__ == "__main__":
    main()
