"""Summarize paired forward fidelity at fixed half/quarter compute budgets."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
raw = json.loads((ROOT / 'measurements/replica-sizes-v1/replica-sizes.json').read_text())
if raw['status'] != 'complete':
    raise ValueError('Incomplete size comparison')
summary = []
for row in raw['replicas']:
    h = np.concatenate([b['hero_sequence_losses'] for b in row['batches']])
    r = np.concatenate([b['replica_sequence_losses'] for b in row['batches']])
    w = np.concatenate([b['sequence_token_counts'] for b in row['batches']])
    hmean, rmean = float(np.average(h,weights=w)), float(np.average(r,weights=w))
    summary.append({
        'name': row['name'], 'parameters':row['parameters'], 'parameter_fraction':row['parameter_fraction'],
        'linear_compute_fraction':row['linear_compute_fraction'], 'hero_loss':hmean, 'replica_loss':rmean,
        'loss_increase':rmean-hmean, 'perplexity_ratio_to_hero':float(np.exp(rmean-hmean)),
        'sequence_loss_correlation':float(np.corrcoef(h,r)[0,1]),
        'sampled_top1_agreement':float(np.mean([b['sampled_top1_agreement'] for b in row['batches']])),
        'sampled_top5_set_overlap':float(np.mean([b['sampled_top5_set_overlap'] for b in row['batches']])),
        'median_forward_seconds':float(np.median(row['forward_seconds'])),
        'hidden_width':row['hidden_width'],'heads':row['heads'],'routed_expert_width':row['routed_expert_width'],
        'shared_expert_width':row['shared_expert_width'],
    })
labels = ['Full identity','Half compute','Quarter compute']
fig, axs = plt.subplots(1,2,figsize=(11,4.4), layout='constrained')
colors=['#235d83','#b04e35','#5a7e44']
axs[0].bar(labels,[r['replica_loss'] for r in summary],color=colors)
axs[0].set_ylabel('Token-weighted cross-entropy');axs[0].set_title('Prediction loss immediately after restriction')
axs[1].bar(labels,[r['sampled_top1_agreement']*100 for r in summary],color=colors)
axs[1].set_ylabel('Agreement with hero, percent');axs[1].set_ylim(0,105);axs[1].set_title('Top-one token prediction at 192 fixed positions')
for ax in axs:ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
for extension in ('svg','png'):fig.savefig(ROOT/f'measurements/replica-sizes.{extension}',dpi=160)
table=''
for label,r in zip(labels,summary,strict=True):
    table += f"<tr><td>{label}</td><td>{100*r['linear_compute_fraction']:.1f}%</td><td>{r['parameters']/1e6:.1f}M ({100*r['parameter_fraction']:.1f}%)</td><td>{r['replica_loss']:.4f}</td><td>{100*r['sampled_top1_agreement']:.2f}%</td><td>{r['sequence_loss_correlation']:.3f}</td><td>{1000*r['median_forward_seconds']:.1f} ms</td></tr>"
html=f'''<section id="replica-sizes"><h2>Half- and quarter-compute tied replicas</h2>
<p>The half-compute model retains strong agreement about which sequences are difficult (loss correlation 0.982) but predicts the same top token at only 53.6% of sampled positions. Its cross-entropy rises from 2.723 to 4.419. The quarter-compute model reaches loss 6.908, top-token agreement 31.25%, and sequence-loss correlation 0.843. Thus raw slicing preserves some predictive structure, especially at half compute, while changing absolute predictions and loss substantially.</p>
<p>Both replicas were sliced from one hero after 256 native updates and evaluated immediately, with no additional optimization or weight rescaling. “Half” and “quarter” refer to the leading linear-matrix FLOP estimate per equal-token batch. Their audited ratios are 49.5% and 25.2%; their parameter counts are 40.2% and 19.5% of the hero. These are approximate compute targets, not measured total-training FLOP ratios.</p>
<table><thead><tr><th>Model</th><th>Estimated linear compute</th><th>Parameters</th><th>Loss</th><th>Top-one agreement</th><th>Sequence-loss correlation</th><th>Median loss-forward latency</th></tr></thead><tbody>{table}</tbody></table>
<figure><img src="measurements/replica-sizes.svg" alt="Prediction loss and agreement for full, half-compute and quarter-compute restrictions"><figcaption>All three models use the same checkpoint and evaluation examples. The full identity restriction is the control. No replicas were trained on these evaluation batches.</figcaption></figure>
<p>The half-compute restriction retains hidden width 384, three intact 128-dimensional attention heads, routed expert width 128 and shared expert width 256. The quarter-compute restriction retains hidden width 256, two intact heads, routed expert width 48 and shared expert width 96. The expert-input latent dimensions are 192 and 128, versus 256 in the hero; attention key/value latent widths are 384 and 256, versus 512. Both keep the hero’s six layers, vocabulary and expert identities; For every changed tensor axis, the slice retains indices from zero to the new width: the same residual channels, complete attention heads, and expert hidden channels are retained across their connected input/output matrices. No coordinates are reordered or rescaled. Other allocations of the same compute budget remain untested.</p>
<p>Loss is token-weighted cross-entropy over the same two reserved 128 × 4,096-position batches used in the full-replica sanity check (mixture indices 50000 and 50001). Sequence-loss correlation is Pearson correlation across 256 sequence means; it is not a measurement of future-training loss forecasting. Top-one agreement uses 192 fixed positions: rows 0, 8, …, 120 at token positions 0, 31, 255, 1023, 2047 and 4094 in each batch. This sparse deterministic sample has no population-confidence claim. These mixture indices are not proven document-disjoint from training data.</p>
<p>Forward latency is the median of five warm calls on one batch, with all models using the same eight H100s and mesh. It excludes compilation, copying and data loading and does not measure update throughput. The arithmetic estimate excludes attention interactions, recurrent-state work, optimizer work and transport. A smaller FLOP count therefore need not yield a proportional latency reduction.</p>
<p>This checks function preservation under direct slicing. It does not test joint nested-width training, distillation, adaptation, optimizer-state transfer or the quality of proposed parameter updates. The high half-size correlation is across examples at one checkpoint. It does not measure correlation between the models’ gradients, agreement on the effects of candidate parameter changes, or forecasting over training time. Those are the quantities that would connect this result to a useful drafter. Absolute-loss calibration and further adaptation remain untested.</p>
<p>Sources: <a href="measurements/replica-sizes-v1/replica-sizes.json">complete paired measurements</a>, <a href="replica-sizes-protocol.json">predeclared protocol and size audit</a>, <a href="marin/experiments/grug/tied_replica_sizes.py">probe source</a>, <a href="run-replica-sizes.sh">launcher</a>, and <a href="summarize_replica_sizes.py">summary and figure code</a>.</p></section>'''
result={'replicas':summary,'scope':'Immediate prediction fidelity only; one shared trained checkpoint, no replica adaptation','report_html':html}
(ROOT/'measurements/replica-sizes-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'replicas':summary},indent=2))
