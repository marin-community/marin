"""Render the measured native-control curve and the rejected linear extrapolation."""

import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
record = json.loads((ROOT / "measurements/calibration-v4/calibration.json").read_text())
rows = record["checkpoints"]
steps = np.array([r["step"] for r in rows])
groups = np.array([r["groups"]["check"] for r in rows])
means = groups.mean(axis=1)
fig, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
axes[0].plot(steps, means, "o-", color="#216b96", markersize=4)
axes[0].set(title="Native control: measured validation curve", xlabel="Ordinary training updates", ylabel="Cross-entropy (lower is better)")
early = steps <= 320
anchor = means[np.flatnonzero(steps == 256)[0]]
slope = record["forecasts"][0]["fit"]["loss_per_step"]
axes[1].plot(steps[early], means[early], "o-", color="#216b96", label="Measured on reserved check data")
axes[1].plot([256, 320], [anchor, anchor - 64 * slope], "--", color="#ad4b38", label="Earlier slope extrapolated forward")
axes[1].axvline(256, color="#7c858b", linewidth=0.8)
axes[1].set(title="Early linear extrapolation misses deceleration", xlabel="Ordinary training updates", ylabel="Cross-entropy")
axes[1].legend(fontsize=8, frameon=False)
for axis in axes:
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(alpha=0.15)
fig.savefig(ROOT / "measurements/control-calibration.svg")
fig.savefig(ROOT / "measurements/control-calibration.png", dpi=160)
