"""Audit paired rejection-frontier outputs and summarize observed acceptance rates."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def loss(values):
    a=np.asarray(values['losses']);w=np.asarray(values['counts'])
    if a.shape!=w.shape or not np.all(np.isfinite(a)) or not np.all(np.isfinite(w)) or np.any(w<0) or w.sum()<=0:
        raise ValueError('Invalid evaluation arrays')
    return float(np.average(a,weights=w))


def difference(before,after):
    if not np.array_equal(before['counts'],after['counts']):raise ValueError('Compared token counts differ')
    return loss(before)-loss(after)


def audit(path,protocol_path):
    raw=json.loads(path.read_text());p=json.loads(protocol_path.read_text())
    if raw['status']!='complete' or raw['snapshot_isolation']!='passed':raise ValueError('Incomplete run or copy-isolation audit')
    if raw['protocol']!=p or raw['protocol_sha256']!=hashlib.sha256(protocol_path.read_bytes()).hexdigest():raise ValueError('Frozen protocol mismatch')
    if raw['source_sha256']!=p['implementation_sha256']['experiments/grug/tied_drafter_frontier.py']:raise ValueError('Source hash mismatch')
    if raw['seed'] not in p['seeds']:raise ValueError('Unexpected initialization seed')
    if raw['checkpoint']['restored_step']!=p['checkpoint_step']:raise ValueError('Wrong optimizer start clock')
    for k,v in p['checkpoints'][str(raw['seed'])].items():
        if raw['checkpoint'][k]!=v:raise ValueError('Wrong source checkpoint')
    trials={r['trial']:r for r in raw['trials']}
    if len(trials)!=len(raw['trials']) or sorted(trials)!=p['trial_ids'] or raw['completed_trials']!=len(trials):raise ValueError('Missing or duplicate trials')
    updates=[json.loads(line) for line in path.with_name('updates.jsonl').read_text().splitlines()]
    rows={}
    for row in raw['endpoints']:
        key=(row['trial'],row['active_experts'],row['horizon'])
        if key in rows:raise ValueError('Duplicate endpoint')
        rows[key]=row
    expected={(t,k,h) for t in p['trial_ids'] for k in p['active_experts'] for h in p['horizons']}
    if set(rows)!=expected:raise ValueError('Missing or unexpected endpoints')
    for trial,t in trials.items():
        if t['training_batch_start']!=p['training_batch_start']+trial*p['training_window_stride']:raise ValueError('Training window mismatch')
        if t['check_batch']!=p['check_batch_start']+trial or t['fresh_batch_start']!=p['fresh_batch_start']+trial*p['monitor_batches']:raise ValueError('Evaluation window mismatch')
        floor=max(p['minimum_loss_gain'],2*(max(t['repeated_loss'])-min(t['repeated_loss'])))
        if t['acceptance_floor']!=floor:raise ValueError('Incorrect acceptance floor')
        offset=trial%len(p['active_experts']);order=p['active_experts'][offset:]+p['active_experts'][:offset]
        if t['variant_order']!=order:raise ValueError('Execution order mismatch')
        for active in p['active_experts']:
            branch=[u for u in updates if u['trial']==trial and u['active_experts']==active]
            failures=[r['failure_step'] for key,r in rows.items() if key[:2]==(trial,active) and r['failure_step'] is not None]
            limit=min(failures) if failures else max(p['horizons'])
            if [u['proposal_step'] for u in branch]!=list(range(1,limit+1)):raise ValueError('Missing update records')
            for u in branch:
                i=u['proposal_step']
                if u['optimizer_step']!=p['checkpoint_step']+i or u['data_step']!=t['training_batch_start']+i-1:raise ValueError('Data offset incorrectly changes optimizer clock')
                if u['seconds']<=0 or not np.isfinite(u['seconds']):raise ValueError('Invalid update timing')
                if u['finite']!=(u['loss'] is not None and np.isfinite(u['loss'])):raise ValueError('Invalid nonfinite-loss record')
                if not u['finite'] and (i!=limit or not failures):raise ValueError('Invalid divergence boundary')
            for h in p['horizons']:
                r=rows[(trial,active,h)];reached=min(h,limit)
                if r['optimizer_step']!=p['checkpoint_step']+reached:raise ValueError('Endpoint clock mismatch')
                if not np.isclose(r['update_seconds'],sum(u['seconds'] for u in branch[:reached]),rtol=0,atol=1e-8):raise ValueError('Endpoint cost omits generated updates')
                accepted=r['check'] is not None and difference(t['starting_check'],r['check'])>floor
                if accepted!=r['accepted']:raise ValueError('Incorrect endpoint acceptance')
                if r['check'] is not None and not np.isclose(r['check_gain'],difference(t['starting_check'],r['check']),rtol=0,atol=1e-12):raise ValueError('Incorrect check gain')
                if r['fresh'] is not None and not np.isclose(r['fresh_gain'],difference(t['starting_fresh'],r['fresh']),rtol=0,atol=1e-12):raise ValueError('Incorrect fresh gain')
                if failures and h>=limit and r['failure_step']!=limit:raise ValueError('Missing unreached-horizon failure label')
    if len(updates)!=sum(len([u for u in updates if u['trial']==t and u['active_experts']==k]) for t in trials for k in p['active_experts']):raise ValueError('Unexpected update branch')
    return raw


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inputs',type=Path,nargs='+');parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();runs=[audit(path,args.protocol) for path in args.inputs];p=runs[0]['protocol']
    if sorted(r['seed'] for r in runs)!=p['seeds']:raise ValueError('Missing/duplicate seeds')
    fingerprints={}
    records=[]
    for path,run in zip(args.inputs,runs,strict=True):
        trials={t['trial']:t for t in run['trials']}
        native={(r['trial'],r['horizon']):r for r in run['endpoints'] if r['active_experts']==8}
        for t in trials.values():
            fp={k:t[k] for k in ['first_training_token_sha256','last_training_token_sha256','prefix_last_token_sha256','check_token_sha256','fresh_token_sha256']}
            if t['trial'] in fingerprints and fingerprints[t['trial']]!=fp:raise ValueError('Data differs across seeds')
            fingerprints[t['trial']]=fp
        for row in run['endpoints']:
            baseline=native[(row['trial'],row['horizon'])];trial=trials[row['trial']]
            cost=row['update_seconds']+row['initial_copy_seconds']+trial['baseline_check_seconds']+row['candidate_check_seconds']
            records.append({'seed':run['seed'],'trial':row['trial'],'active_experts':row['active_experts'],'horizon':row['horizon'],'accepted':row['accepted'],'failure_step':row['failure_step'],'fresh_gain':row['fresh_gain'],'fresh_gain_vs_native':None if row['fresh'] is None else difference(baseline['fresh'],row['fresh']),'check_gain':row['check_gain'],'native_fresh_gain':difference(trial['starting_fresh'],baseline['fresh']),'update_seconds':row['update_seconds'],'native_update_seconds':baseline['update_seconds'],'update_time_ratio':row['update_seconds']/baseline['update_seconds'] if row['failure_step'] is None else None,'single_horizon_execution_seconds':cost,'single_horizon_cost_ratio':cost/baseline['update_seconds'] if row['failure_step'] is None else None})
    cells=[]
    for active in p['active_experts']:
        for h in p['horizons']:
            group=[r for r in records if r['active_experts']==active and r['horizon']==h]
            rejected=sum(not r['accepted'] for r in group)
            per_seed={str(seed):sum(not r['accepted'] for r in group if r['seed']==seed) for seed in p['seeds']}
            valid=[r for r in group if r['fresh_gain_vs_native'] is not None]
            timing=[r for r in group if r['update_time_ratio'] is not None]
            cells.append({'active_experts':active,'horizon':h,'trials':len(group),'rejected':rejected,'rejection_rate':rejected/len(group),'passes_observed_10_percent_rule':rejected/len(group)<=.1,'rejections_by_seed':per_seed,'rejected_with_passing_shorter_prefix':sum(not r['accepted'] and any(x['accepted'] and x['seed']==r['seed'] and x['trial']==r['trial'] and x['active_experts']==active and x['horizon']<h for x in records) for r in group),'nonfinite_fresh':len(group)-len(valid),'mean_fresh_gain':None if not valid else float(np.mean([r['fresh_gain'] for r in valid])),'mean_fresh_gain_vs_native':None if not valid else float(np.mean([r['fresh_gain_vs_native'] for r in valid])),'median_update_time_ratio':None if not timing else float(np.median([r['update_time_ratio'] for r in timing])),'median_single_horizon_cost_ratio':None if not timing else float(np.median([r['single_horizon_cost_ratio'] for r in timing]))})
    result={'status':'audited','protocol_sha256':runs[0]['protocol_sha256'],'scope':'Independent checkpoint branches; observed rates on shared states, no population guarantee. No shorter-prefix fallback counted as full-horizon acceptance.','sources':[{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seed':run['seed'],'wandb_url':run['wandb_url'],'cost_seconds':run['cost_seconds']} for path,run in zip(args.inputs,runs,strict=True)],'cells':cells,'records':records}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    lookup={(c['active_experts'],c['horizon']):c for c in cells}
    for ax,field,title in [(axes[0],'rejection_rate','Observed endpoint rejection'),(axes[1],'mean_fresh_gain_vs_native','Fresh loss gain vs native (nats/token)')]:
        matrix=np.array([[lookup[(k,h)][field] if lookup[(k,h)][field] is not None else np.nan for k in p['active_experts']] for h in p['horizons']])
        limit=max(float(np.nanmax(np.abs(matrix))),1e-6) if np.any(np.isfinite(matrix)) else 1.0
        picture=ax.imshow(matrix,cmap='Reds' if field=='rejection_rate' else 'RdBu',aspect='auto',vmin=0 if field=='rejection_rate' else -limit,vmax=1 if field=='rejection_rate' else limit)
        for i,h in enumerate(p['horizons']):
            for j,k in enumerate(p['active_experts']):
                c=lookup[(k,h)];label=f"{c['rejected']}/{c['trials']}" if field=='rejection_rate' else ('nonfinite' if c[field] is None else f"{c[field]:+.4f}")
                ax.text(j,i,label,ha='center',va='center',fontsize=10,bbox={'facecolor':'white','alpha':.75,'edgecolor':'none'})
        ax.set_xticks(range(len(p['active_experts'])),p['active_experts']);ax.set_yticks(range(len(p['horizons'])),p['horizons']);ax.set_xlabel('Active experts (8 = native)');ax.set_ylabel('Proposed update horizon');ax.set_title(title);fig.colorbar(picture,ax=ax)
    fig.savefig(args.output.with_suffix('.svg'));fig.savefig(args.output.with_suffix('.png'),dpi=150)
    for c in cells:print(c)


if __name__=='__main__':main()
