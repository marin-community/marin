import math
from dataclasses import dataclass
from typing import Any

import torch
import torch.distributed as dist
import torch.distributed._symmetric_memory as symm_mem

from .ops import (
    LATENT_GEMM_AB,
    LATENT_GEMM_ABT,
    LATENT_GEMM_ATB,
    all_gather_top_experts,
    barrier_all,
    bwd_epilogue,
    dispatch_mlp_swiglu_combine_bwd_mxfp8,
    dispatch_mlp_swiglu_combine_bwd_bf16,
    dispatch_mlp_swiglu_combine_fwd_mxfp8,
    dispatch_mlp_swiglu_combine_fwd_bf16,
    fwd_epilogue,
    fwd_epilogue_routed,
    latent_gemm,
    latent_gemm_out,
    latent_rmsnorm_bwd,
    latent_rmsnorm_fwd,
    schedule,
)


@dataclass(frozen=True, slots=True)
class MoKConfig:
    fwd_num_comm_sms: int = 40
    bwd_num_comm_sms: int = 28
    minibatch_size: int = 4096
    macrobatch_size: int = 131072
    schedule_capacity_multiplier: float = 0.5
    all_gather_top_experts_chunk_bytes: int = 2048


@dataclass(frozen=True, slots=True)
class MoKSchedule:
    peer_rank: torch.Tensor          # (schedule_capacity,) int32
    peer_token_idx: torch.Tensor     # (schedule_capacity,) int32
    num_tokens: torch.Tensor         # (1,) int32
    tokens_per_expert: torch.Tensor  # (num_local_experts,) int32


@dataclass(frozen=True, slots=True)
class MoKLatentWeights:
    """The LatentMoE projections that bracket the megakernel.

    `down` narrows tokens from the hidden width to the latent width before the dispatch, which is
    what halves the all-to-all's wire traffic; `up` expands the routed combine back. Both are stored
    out-features-major so that neither direction ever has to materialize a transpose.
    """
    down: torch.Tensor         # bfloat16 [latent_size, hidden_size]
    norm_weight: torch.Tensor  # float32 [latent_size]
    up: torch.Tensor           # bfloat16 [hidden_size, latent_size]
    eps: float = 1e-6


@dataclass(frozen=True, slots=True)
class MoKLatentContext:
    projected: torch.Tensor  # bfloat16 [num_local_tokens, latent_size]; pre-norm down-projection
    rstd: torch.Tensor       # float32 [num_local_tokens]
    combined: torch.Tensor   # bfloat16 [num_local_tokens, latent_size]; router-weighted routed sum


@dataclass(frozen=True, slots=True)
class MoKForwardContext:
    x_routed: torch.Tensor | tuple[torch.Tensor, torch.Tensor]
    gate_shared: torch.Tensor
    gate_routed: torch.Tensor | tuple[torch.Tensor, torch.Tensor]
    up_shared: torch.Tensor
    up_routed: torch.Tensor | tuple[torch.Tensor, torch.Tensor]
    hidden_shared: torch.Tensor
    hidden_routed: torch.Tensor | tuple[torch.Tensor, torch.Tensor]


@dataclass(slots=True)
class MoKWorkspace:
    group_name: str                                   # () str
    ep_rank: int                                      # () int
    ep_size: int                                      # () int
    device: torch.device                              # () torch.device
    num_local_tokens: int                             # () int
    hidden_size: int                                  # () int
    routed_size: int                                  # () int; latent width, or hidden_size
    topk: int                                         # () int
    schedule_capacity: int                            # () int
    x_buffer: torch.Tensor                            # (num_local_tokens, routed_size) bfloat16
    x_buffer_handle: Any                              # () SymmetricMemory handle
    x_buffer_ptrs: list[int]                          # (ep_size,) uintptr64
    combine_buffer: torch.Tensor                      # (num_local_tokens * topk, routed_size) bfloat16
    combine_buffer_handle: Any                        # () SymmetricMemory handle
    combine_buffer_ptrs: list[int]                    # (ep_size,) uintptr64
    d_y_buffer: torch.Tensor                          # (num_local_tokens, routed_size) bfloat16
    d_y_buffer_handle: Any                            # () SymmetricMemory handle
    d_y_buffer_ptrs: list[int]                        # (ep_size,) uintptr64
    d_x_routed_buffer: torch.Tensor                   # (num_local_tokens * topk, routed_size) bfloat16
    d_x_routed_buffer_handle: Any                     # () SymmetricMemory handle
    d_x_routed_buffer_ptrs: list[int]                 # (ep_size,) uintptr64
    router_weight_buffer: torch.Tensor                # (num_local_tokens, topk) float32
    router_weight_buffer_handle: Any                  # () SymmetricMemory handle
    router_weight_buffer_ptrs: list[int]              # (ep_size,) uintptr64
    d_router_weight_buffer: torch.Tensor              # (num_local_tokens, topk) float32
    d_router_weight_buffer_handle: Any                # () SymmetricMemory handle
    d_router_weight_buffer_ptrs: list[int]            # (ep_size,) uintptr64
    all_gather_top_experts_buffer: torch.Tensor       # (ep_size, num_local_tokens, topk) int32
    all_gather_top_experts_buffer_handle: Any         # () SymmetricMemory handle
    all_gather_top_experts_buffer_multicast_ptr: int  # () uintptr64
    barrier_buffer: torch.Tensor                      # (1,) int32
    barrier_buffer_handle: Any                        # () SymmetricMemory handle
    barrier_buffer_ptrs: list[int]                    # (ep_size,) uintptr64
    barrier_buffer_multicast_ptr: int                 # () uintptr64
    barrier_target: torch.Tensor                      # (1,) int32


_WORKSPACE_CACHE: dict[tuple[str, int, int, int, int, int, int], MoKWorkspace] = {}


def validate_workspace_args(
    config: MoKConfig,
    group: dist.ProcessGroup,
    *,
    device: torch.device,
    num_local_tokens: int,
    hidden_size: int,
    topk: int,
    latent_size: int | None = None,
) -> None:
    """Validates the arguments used to create or retrieve a workspace.

    Inputs:
        config:           MoKConfig
        group:            torch.distributed.ProcessGroup
        device:           torch.device
        num_local_tokens: int
        hidden_size:      int
        topk:             int
        latent_size:      int | None

    Outputs:
        None

    `latent_size` sizes every symmetric buffer the routed path touches. Leaving it None keeps them
    at `hidden_size`, which is the non-latent shape.
    """
    if (
        type(config.schedule_capacity_multiplier) not in (int, float)
        or not math.isfinite(config.schedule_capacity_multiplier)
        or config.schedule_capacity_multiplier <= 0
    ):
        raise ValueError("schedule_capacity_multiplier must be a positive finite number")
    if not dist.is_initialized():
        raise RuntimeError("torch.distributed must be initialized")
    if not isinstance(group, dist.ProcessGroup):
        raise TypeError("group must be a torch.distributed.ProcessGroup")
    if not isinstance(device, torch.device):
        raise TypeError("device must be a torch.device")
    if device.type != "cuda":
        raise ValueError("device must be a CUDA device")
    device_index = device.index if device.index is not None else torch.cuda.current_device()
    device = torch.device("cuda", device_index)
    if device_index != torch.cuda.current_device():
        raise ValueError("MoK workspace device must be the current CUDA device")
    if torch.cuda.get_device_capability(device) not in ((10, 0), (10, 3)):
        raise NotImplementedError("MoK currently requires an SM100 or SM103 GPU")
    device_properties = torch.cuda.get_device_properties(device)
    if type(num_local_tokens) is not int or num_local_tokens < 512:
        raise ValueError("num_local_tokens must be an integer at least 512")
    if num_local_tokens % 256 != 0:
        raise ValueError("num_local_tokens must be divisible by 256")
    if type(hidden_size) is not int or hidden_size <= 0:
        raise ValueError("hidden_size must be a positive integer")
    if hidden_size % 256 != 0:
        raise ValueError("hidden_size must be divisible by 256")
    if latent_size is not None:
        if type(latent_size) is not int or latent_size <= 0:
            raise ValueError("latent_size must be a positive integer")
        if latent_size % 256 != 0:
            raise ValueError("latent_size must be divisible by 256")
    if type(topk) is not int or not 0 < topk <= 255:
        raise ValueError("topk must be an integer in [1, 255]")
    fwd_epilogue_smem_bytes = 2 * ((topk + 1) * 2048 + topk * 4) + 1024
    if fwd_epilogue_smem_bytes > device_properties.shared_memory_per_block_optin:
        raise ValueError("topk requires more dynamic shared memory than the device supports")

    group_name = group.group_name
    if not isinstance(group_name, str) or not group_name:
        raise RuntimeError("process group must have a nonempty group_name")
    ep_rank = dist.get_rank(group=group)
    ep_size = dist.get_world_size(group=group)
    if ep_size not in (4, 8, 16, 32, 64):
        raise ValueError("MoK EP size must be one of 4, 8, 16, 32, 64")
    if not 0 <= ep_rank < ep_size:
        raise RuntimeError("current process is not a member of the EP process group")


def create_workspace(
    config: MoKConfig,
    group: dist.ProcessGroup,
    *,
    device: torch.device,
    num_local_tokens: int,
    hidden_size: int,
    topk: int,
    latent_size: int | None = None,
) -> MoKWorkspace:
    """Creates a new caller-owned workspace.

    Inputs:
        config:           MoKConfig
        group:            torch.distributed.ProcessGroup
        device:           torch.device
        num_local_tokens: int
        hidden_size:      int
        topk:             int
        latent_size:      int | None

    Outputs:
        workspace: MoKWorkspace

    With `latent_size` set, every buffer the all-to-all touches is allocated at the latent width
    instead of the hidden one -- which is the whole point of a latent MoE, since those buffers are
    the wire.
    """
    validate_workspace_args(
        config,
        group,
        device=device,
        num_local_tokens=num_local_tokens,
        hidden_size=hidden_size,
        topk=topk,
        latent_size=latent_size,
    )

    device_index = device.index if device.index is not None else torch.cuda.current_device()
    device = torch.device("cuda", device_index)
    group_name = group.group_name
    ep_rank = dist.get_rank(group=group)
    ep_size = dist.get_world_size(group=group)
    schedule_capacity_factor = max(2, math.ceil(ep_size * config.schedule_capacity_multiplier))
    routed_size = hidden_size if latent_size is None else latent_size

    local_shape = torch.tensor([num_local_tokens, hidden_size, routed_size, topk],
                               dtype=torch.int64, device=device)
    gathered_shapes = torch.empty(ep_size * local_shape.numel(), dtype=torch.int64, device=device)
    dist.all_gather_into_tensor(gathered_shapes, local_shape, group=group)
    gathered_shapes = gathered_shapes.view(ep_size, local_shape.numel())
    if not torch.all(gathered_shapes == local_shape).item():  # .item() here is fine since this is one-time setup
        raise ValueError("MoK requires identical token, hidden, latent, and top-k shapes on every EP rank")
    symm_mem.enable_symm_mem_for_group(group_name)

    schedule_capacity = num_local_tokens * topk * schedule_capacity_factor

    x_buffer = symm_mem.empty(num_local_tokens, routed_size, dtype=torch.bfloat16, device=device)
    x_buffer_handle = symm_mem.rendezvous(x_buffer, group_name)
    x_buffer_ptrs = [int(x_buffer_handle.buffer_ptrs[peer_rank]) for peer_rank in range(ep_size)]

    combine_buffer = symm_mem.empty(num_local_tokens * topk, routed_size,
                                    dtype=torch.bfloat16, device=device)
    combine_buffer_handle = symm_mem.rendezvous(combine_buffer, group_name)
    combine_buffer_ptrs = [int(combine_buffer_handle.buffer_ptrs[peer_rank])
                           for peer_rank in range(ep_size)]

    d_y_buffer = symm_mem.empty(num_local_tokens, routed_size, dtype=torch.bfloat16, device=device)
    d_y_buffer_handle = symm_mem.rendezvous(d_y_buffer, group_name)
    d_y_buffer_ptrs = [int(d_y_buffer_handle.buffer_ptrs[peer_rank])
                       for peer_rank in range(ep_size)]

    d_x_routed_buffer = symm_mem.empty(num_local_tokens * topk, routed_size,
                                      dtype=torch.bfloat16, device=device)
    d_x_routed_buffer_handle = symm_mem.rendezvous(d_x_routed_buffer, group_name)
    d_x_routed_buffer_ptrs = [int(d_x_routed_buffer_handle.buffer_ptrs[peer_rank])
                              for peer_rank in range(ep_size)]

    router_weight_buffer = symm_mem.empty(num_local_tokens, topk, dtype=torch.float32, device=device)
    router_weight_buffer_handle = symm_mem.rendezvous(router_weight_buffer, group_name)
    router_weight_buffer_ptrs = [int(router_weight_buffer_handle.buffer_ptrs[peer_rank])
                                 for peer_rank in range(ep_size)]

    d_router_weight_buffer = symm_mem.empty(num_local_tokens, topk,
                                            dtype=torch.float32, device=device)
    d_router_weight_buffer_handle = symm_mem.rendezvous(d_router_weight_buffer, group_name)
    d_router_weight_buffer_ptrs = [int(d_router_weight_buffer_handle.buffer_ptrs[peer_rank])
                                   for peer_rank in range(ep_size)]

    all_gather_top_experts_buffer = symm_mem.empty(
        ep_size, num_local_tokens, topk, dtype=torch.int32, device=device)
    all_gather_top_experts_buffer_handle = symm_mem.rendezvous(all_gather_top_experts_buffer,
                                                               group_name)
    all_gather_top_experts_buffer_multicast_ptr = int(all_gather_top_experts_buffer_handle.multicast_ptr)

    barrier_buffer = symm_mem.empty(1, dtype=torch.int32, device=device)
    barrier_buffer.zero_()
    barrier_buffer_handle = symm_mem.rendezvous(barrier_buffer, group_name)
    barrier_buffer_ptrs = [int(barrier_buffer_handle.buffer_ptrs[peer_rank])
                           for peer_rank in range(ep_size)]
    barrier_buffer_multicast_ptr = int(barrier_buffer_handle.multicast_ptr)
    barrier_target = torch.zeros(1, dtype=torch.int32, device=device)

    dist.barrier(group=group, async_op=True, device_ids=[device_index]).block_current_stream()

    workspace = MoKWorkspace(
        group_name=group_name, ep_rank=ep_rank, ep_size=ep_size, device=device,
        num_local_tokens=num_local_tokens, hidden_size=hidden_size, routed_size=routed_size,
        topk=topk, schedule_capacity=schedule_capacity,
        x_buffer=x_buffer, x_buffer_handle=x_buffer_handle, x_buffer_ptrs=x_buffer_ptrs,
        combine_buffer=combine_buffer, combine_buffer_handle=combine_buffer_handle,
        combine_buffer_ptrs=combine_buffer_ptrs,
        d_y_buffer=d_y_buffer, d_y_buffer_handle=d_y_buffer_handle,
        d_y_buffer_ptrs=d_y_buffer_ptrs,
        d_x_routed_buffer=d_x_routed_buffer, d_x_routed_buffer_handle=d_x_routed_buffer_handle,
        d_x_routed_buffer_ptrs=d_x_routed_buffer_ptrs,
        router_weight_buffer=router_weight_buffer,
        router_weight_buffer_handle=router_weight_buffer_handle,
        router_weight_buffer_ptrs=router_weight_buffer_ptrs,
        d_router_weight_buffer=d_router_weight_buffer,
        d_router_weight_buffer_handle=d_router_weight_buffer_handle,
        d_router_weight_buffer_ptrs=d_router_weight_buffer_ptrs,
        all_gather_top_experts_buffer=all_gather_top_experts_buffer,
        all_gather_top_experts_buffer_handle=all_gather_top_experts_buffer_handle,
        all_gather_top_experts_buffer_multicast_ptr=all_gather_top_experts_buffer_multicast_ptr,
        barrier_buffer=barrier_buffer, barrier_buffer_handle=barrier_buffer_handle,
        barrier_buffer_ptrs=barrier_buffer_ptrs,
        barrier_buffer_multicast_ptr=barrier_buffer_multicast_ptr,
        barrier_target=barrier_target,
    )
    return workspace


def get_workspace(
    config: MoKConfig,
    group: dist.ProcessGroup,
    *,
    device: torch.device,
    num_local_tokens: int,
    hidden_size: int,
    topk: int,
    latent_size: int | None = None,
) -> MoKWorkspace:
    """Returns a cached workspace, creating and caching one if absent.

    Inputs:
        config:           MoKConfig
        group:            torch.distributed.ProcessGroup
        device:           torch.device
        num_local_tokens: int
        hidden_size:      int
        topk:             int
        latent_size:      int | None

    Outputs:
        workspace: MoKWorkspace
    """
    validate_workspace_args(
        config,
        group,
        device=device,
        num_local_tokens=num_local_tokens,
        hidden_size=hidden_size,
        topk=topk,
        latent_size=latent_size,
    )

    device_index = device.index if device.index is not None else torch.cuda.current_device()
    device = torch.device("cuda", device_index)
    group_name = group.group_name
    ep_size = dist.get_world_size(group=group)
    schedule_capacity_factor = max(2, math.ceil(ep_size * config.schedule_capacity_multiplier))
    routed_size = hidden_size if latent_size is None else latent_size

    cache_key = (group_name, device_index, num_local_tokens, hidden_size, routed_size, topk,
                 schedule_capacity_factor)
    cached_workspace = _WORKSPACE_CACHE.get(cache_key)
    if cached_workspace is not None:
        return cached_workspace

    workspace = create_workspace(
        config,
        group,
        device=device,
        num_local_tokens=num_local_tokens,
        hidden_size=hidden_size,
        topk=topk,
        latent_size=latent_size,
    )
    _WORKSPACE_CACHE[cache_key] = workspace
    return workspace


def clear_workspace_cache() -> None:
    """Clears cached workspaces after all participating ranks synchronize.

    Inputs:
        None

    Outputs:
        None
    """
    for workspace in _WORKSPACE_CACHE.values():
        barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                    workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)
        torch.cuda.synchronize(workspace.device)
    _WORKSPACE_CACHE.clear()


def build_schedule(
    workspace: MoKWorkspace,
    config: MoKConfig,
    top_experts: torch.Tensor,
    *,
    num_local_experts: int,
) -> MoKSchedule:
    """All-gathers routing choices and builds this rank's padded expert schedule.

    Inputs:
        workspace:         MoKWorkspace
        config:            MoKConfig
        top_experts:       int64 [num_local_tokens, topk]
        num_local_experts: int

    Outputs:
        schedule: MoKSchedule
    """
    if not isinstance(workspace, MoKWorkspace):
        raise TypeError("workspace must be a MoKWorkspace")
    if not isinstance(config, MoKConfig):
        raise TypeError("config must be a MoKConfig")
    device_properties = torch.cuda.get_device_properties(workspace.device)
    if type(config.fwd_num_comm_sms) is not int or config.fwd_num_comm_sms <= 0:
        raise ValueError("fwd_num_comm_sms must be a positive integer")
    if config.fwd_num_comm_sms % 2 != 0:
        raise ValueError("fwd_num_comm_sms must be even")
    if type(config.bwd_num_comm_sms) is not int or config.bwd_num_comm_sms <= 0:
        raise ValueError("bwd_num_comm_sms must be a positive integer")
    if config.bwd_num_comm_sms % 2 != 0:
        raise ValueError("bwd_num_comm_sms must be even")
    if (config.fwd_num_comm_sms >= device_properties.multi_processor_count
            or config.bwd_num_comm_sms >= device_properties.multi_processor_count):
        raise ValueError("communication-SM counts must leave at least one compute SM")
    if (type(config.minibatch_size) is not int or config.minibatch_size <= 0
            or config.minibatch_size % 256 != 0):
        raise ValueError("minibatch_size must be positive and divisible by 256")
    if (type(config.macrobatch_size) is not int or config.macrobatch_size <= 0
            or config.macrobatch_size % config.minibatch_size != 0):
        raise ValueError("macrobatch_size must be a positive multiple of minibatch_size")
    if (type(config.all_gather_top_experts_chunk_bytes) is not int
            or config.all_gather_top_experts_chunk_bytes <= 0
            or config.all_gather_top_experts_chunk_bytes % 16 != 0):
        raise ValueError("all_gather_top_experts_chunk_bytes must be a positive multiple of 16")
    if (config.all_gather_top_experts_chunk_bytes + 1024
            > device_properties.shared_memory_per_block_optin):
        raise ValueError("all_gather_top_experts_chunk_bytes exceeds device dynamic shared-memory capacity")
    route_buffer_bytes = workspace.num_local_tokens * workspace.topk * 4
    if route_buffer_bytes % config.all_gather_top_experts_chunk_bytes != 0:
        raise ValueError("all_gather_top_experts_chunk_bytes must divide one rank's route-buffer bytes")
    if not top_experts.is_cuda or top_experts.device != workspace.device:
        raise ValueError("top_experts must be on the workspace CUDA device")
    if top_experts.dtype != torch.int64:
        raise TypeError("top_experts must have dtype torch.int64")
    if not top_experts.is_contiguous():
        raise ValueError("top_experts must be contiguous")
    if tuple(top_experts.shape) != (workspace.num_local_tokens, workspace.topk):
        raise ValueError("top_experts must have shape (num_local_tokens, topk)")
    if type(num_local_experts) is not int or num_local_experts <= 0:
        raise ValueError("num_local_experts must be a positive integer")

    top_experts_int32 = top_experts.to(torch.int32)
    all_gather_top_experts(
        top_experts_int32, workspace.all_gather_top_experts_buffer,
        workspace.all_gather_top_experts_buffer_multicast_ptr, workspace.ep_rank,
        config.all_gather_top_experts_chunk_bytes,
    )
    barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)
    (schedule_peer_rank, schedule_peer_token_idx,
     num_tokens, tokens_per_expert) = schedule(
        workspace.all_gather_top_experts_buffer, num_local_experts,
        workspace.schedule_capacity, workspace.ep_rank)
    return MoKSchedule(
        peer_rank=schedule_peer_rank, peer_token_idx=schedule_peer_token_idx,
        num_tokens=num_tokens, tokens_per_expert=tokens_per_expert,
    )


def validate_inputs(
    config: MoKConfig,
    workspace: MoKWorkspace,
    schedule: MoKSchedule,
    x: torch.Tensor,
    router_weights: torch.Tensor,
    grad_output: torch.Tensor | None = None,
) -> None:
    """Validates runtime inputs against the workspace and schedule.

    Inputs:
        config:         MoKConfig
        workspace:      MoKWorkspace
        schedule:       MoKSchedule
        x:              bfloat16 [num_local_tokens, hidden_size]
        router_weights: float32 [num_local_tokens, topk]
        grad_output:    bfloat16 [num_local_tokens, hidden_size] | None

    Outputs:
        None
    """
    if not isinstance(config, MoKConfig):
        raise TypeError("config must be a MoKConfig")
    if not isinstance(workspace, MoKWorkspace):
        raise TypeError("workspace must be a MoKWorkspace")
    if not isinstance(schedule, MoKSchedule):
        raise TypeError("schedule must be a MoKSchedule")
    expected_activation_shape = (workspace.num_local_tokens, workspace.hidden_size)
    tensors = [("x", x, torch.bfloat16, expected_activation_shape)]
    if grad_output is not None:
        tensors.append(("grad_output", grad_output, torch.bfloat16, expected_activation_shape))
    tensors.append(("router_weights", router_weights, torch.float32, (workspace.num_local_tokens, workspace.topk)))
    for tensor_name, tensor, expected_dtype, expected_shape in tensors:
        if not tensor.is_cuda or tensor.device != workspace.device or tensor.dtype != expected_dtype or not tensor.is_contiguous():
            raise ValueError(f"{tensor_name} must be contiguous {expected_dtype} on the workspace CUDA device")
        if tuple(tensor.shape) != expected_shape:
            raise ValueError(f"{tensor_name} shape does not match the workspace")
    if schedule.peer_rank.numel() != workspace.schedule_capacity:
        raise ValueError("schedule capacity does not match the workspace")


def validate_latent_weights(workspace: MoKWorkspace, latent: MoKLatentWeights) -> None:
    """Validates a latent projection against the workspace it will feed.

    Inputs:
        workspace: MoKWorkspace
        latent:    MoKLatentWeights

    Outputs:
        None
    """
    if not isinstance(latent, MoKLatentWeights):
        raise TypeError("latent must be a MoKLatentWeights")
    hidden_size, latent_size = workspace.hidden_size, workspace.routed_size
    expected = (
        ("latent.down", latent.down, torch.bfloat16, (latent_size, hidden_size)),
        ("latent.norm_weight", latent.norm_weight, torch.float32, (latent_size,)),
        ("latent.up", latent.up, torch.bfloat16, (hidden_size, latent_size)),
    )
    for name, tensor, dtype, shape in expected:
        if (not tensor.is_cuda or tensor.device != workspace.device
                or tensor.dtype != dtype or not tensor.is_contiguous()):
            raise ValueError(f"{name} must be contiguous {dtype} on the workspace CUDA device")
        if tuple(tensor.shape) != shape:
            raise ValueError(f"{name} must have shape {shape}")
    if not latent.eps > 0.0:
        raise ValueError("latent.eps must be positive")


def forward(
    config: MoKConfig,
    workspace: MoKWorkspace,
    schedule: MoKSchedule,
    x: torch.Tensor,
    router_weights: torch.Tensor,
    shared_gate_weights: torch.Tensor,
    shared_up_weights: torch.Tensor,
    shared_down_weights: torch.Tensor,
    routed_gate_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
    routed_up_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
    routed_down_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
    latent: MoKLatentWeights | None = None,
) -> (tuple[torch.Tensor, MoKForwardContext]
     | tuple[torch.Tensor, MoKForwardContext, MoKLatentContext]):
    """Runs the MoE forward pass.

    Inputs:
        config:              MoKConfig
        workspace:           MoKWorkspace
        schedule:            MoKSchedule
        x:                   bfloat16 [num_local_tokens, hidden_size]
        router_weights:      float32 [num_local_tokens, topk]
        shared_gate_weights: bfloat16 [shared_intermediate_size, hidden_size]
        shared_up_weights:   bfloat16 [shared_intermediate_size, hidden_size]
        shared_down_weights: bfloat16 [hidden_size, shared_intermediate_size]
        routed_gate_weights: bfloat16 [num_local_experts, routed_intermediate_size, hidden_size] or MXFP8 data/scale tuple
        routed_up_weights:   bfloat16 [num_local_experts, routed_intermediate_size, hidden_size] or MXFP8 data/scale tuple
        routed_down_weights: bfloat16 [num_local_experts, hidden_size, routed_intermediate_size] or MXFP8 data/scale tuple
        latent:              MoKLatentWeights | None

    Outputs:
        output:          bfloat16 [num_local_tokens, hidden_size]
        forward_context: MoKForwardContext
        latent_context:  MoKLatentContext  -- only when `latent` is given

    The BF16 path permits distinct shared and routed intermediate sizes. The
    MXFP8 path currently requires them to be equal.

    With `latent` given, the fused prologue runs before the pre-dispatch barrier and the fused
    epilogue after the post-combine one. Neither can move inside the megakernel: the dispatch reads
    peers' `x` buffers and the combine writes peers' combine buffers, so both orderings are
    cross-rank, and the megakernel's readiness counters are rank-local.
    """
    validate_inputs(config, workspace, schedule, x, router_weights)
    if latent is not None:
        validate_latent_weights(workspace, latent)
        if isinstance(routed_gate_weights, tuple):
            raise NotImplementedError("the latent projection currently requires the BF16 routed path")

    if latent is None:
        workspace.x_buffer.copy_(x)  # TODO: we can remove this
        x_shared = None
        projected = None
        rstd = None
    else:
        # Prologue: narrow the tokens, then normalize straight into the symmetric buffer the
        # dispatch will read. `projected` is the pre-norm result, which the backward needs.
        projected = latent_gemm(x, latent.down, LATENT_GEMM_ABT)
        rstd = latent_rmsnorm_fwd(workspace.x_buffer, projected, latent.norm_weight, latent.eps)
        x_shared = x
    workspace.router_weight_buffer.copy_(router_weights)
    barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)

    if isinstance(routed_gate_weights, tuple):
        routed_gate_weights_fp8, routed_gate_weights_sc = routed_gate_weights
        routed_up_weights_fp8, routed_up_weights_sc = routed_up_weights
        routed_down_weights_fp8, routed_down_weights_sc = routed_down_weights
        (x_fp8_t_routed, x_sc_t_routed,
         gate_shared, gate_fp8_routed, gate_sc_routed,
         up_shared, up_fp8_routed, up_sc_routed,
         hidden_shared, hidden_fp8_t_routed, hidden_sc_t_routed,
         y_shared, y_routed) = dispatch_mlp_swiglu_combine_fwd_mxfp8(
            workspace.x_buffer, workspace.x_buffer_ptrs,
            workspace.combine_buffer, workspace.combine_buffer_ptrs,
            shared_gate_weights, routed_gate_weights_fp8, routed_gate_weights_sc,
            shared_up_weights, routed_up_weights_fp8, routed_up_weights_sc,
            shared_down_weights, routed_down_weights_fp8, routed_down_weights_sc,
            schedule.peer_rank, schedule.peer_token_idx,
            schedule.num_tokens, schedule.tokens_per_expert,
            workspace.topk, config.fwd_num_comm_sms,
            config.macrobatch_size, config.minibatch_size,
        )
        forward_context = MoKForwardContext(
            x_routed=(x_fp8_t_routed, x_sc_t_routed),
            gate_shared=gate_shared,
            gate_routed=(gate_fp8_routed, gate_sc_routed),
            up_shared=up_shared,
            up_routed=(up_fp8_routed, up_sc_routed),
            hidden_shared=hidden_shared,
            hidden_routed=(hidden_fp8_t_routed, hidden_sc_t_routed),
        )
    else:
        (x_routed, gate_shared, gate_routed, up_shared, up_routed,
         hidden_shared, hidden_routed, y_shared, y_routed) = dispatch_mlp_swiglu_combine_fwd_bf16(
            workspace.x_buffer, workspace.x_buffer_ptrs,
            workspace.combine_buffer, workspace.combine_buffer_ptrs,
            shared_gate_weights, routed_gate_weights,
            shared_up_weights, routed_up_weights,
            shared_down_weights, routed_down_weights,
            schedule.peer_rank, schedule.peer_token_idx,
            schedule.num_tokens, schedule.tokens_per_expert,
            workspace.topk, config.fwd_num_comm_sms,
            config.macrobatch_size, config.minibatch_size,
            x_shared,
        )
        forward_context = MoKForwardContext(
            x_routed=x_routed,
            gate_shared=gate_shared,
            gate_routed=gate_routed,
            up_shared=up_shared,
            up_routed=up_routed,
            hidden_shared=hidden_shared,
            hidden_routed=hidden_routed,
        )

    barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)
    if latent is None:
        output = fwd_epilogue(y_shared, workspace.combine_buffer, workspace.router_weight_buffer)
        return output, forward_context

    # Epilogue: reduce the routed rows at the latent width, then expand on top of the shared
    # experts' output in place. `y_shared` is megakernel scratch nothing else reads, so accumulating
    # into it is what removes the separate add pass a functional expand-then-add would cost.
    combined = fwd_epilogue_routed(workspace.combine_buffer, workspace.router_weight_buffer)
    latent_gemm_out(y_shared, combined, latent.up, LATENT_GEMM_ABT, True)
    latent_context = MoKLatentContext(projected=projected, rstd=rstd, combined=combined)
    return y_shared, forward_context, latent_context


def backward(
    config: MoKConfig,
    workspace: MoKWorkspace,
    schedule: MoKSchedule,
    forward_context: MoKForwardContext,
    grad_output: torch.Tensor,
    x: torch.Tensor,
    router_weights: torch.Tensor,
    shared_gate_weights: torch.Tensor,
    shared_up_weights: torch.Tensor,
    shared_down_weights: torch.Tensor,
    routed_gate_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor],
    routed_up_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor],
    routed_down_weights: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
    latent: MoKLatentWeights | None = None,
    latent_context: MoKLatentContext | None = None,
) -> tuple[torch.Tensor, ...]:
    """Runs the MoE backward pass.

    Inputs:
        config:              MoKConfig
        workspace:           MoKWorkspace
        schedule:            MoKSchedule
        forward_context:     MoKForwardContext
        grad_output:         bfloat16 [num_local_tokens, hidden_size]
        x:                   bfloat16 [num_local_tokens, hidden_size]
        router_weights:      float32 [num_local_tokens, topk]
        shared_gate_weights: bfloat16 [shared_intermediate_size, hidden_size]
        shared_up_weights:   bfloat16 [shared_intermediate_size, hidden_size]
        shared_down_weights: bfloat16 [hidden_size, shared_intermediate_size]
        routed_gate_weights: bfloat16 [num_local_experts, routed_intermediate_size, hidden_size] or MXFP8 tensor tuple
        routed_up_weights:   bfloat16 [num_local_experts, routed_intermediate_size, hidden_size] or MXFP8 tensor tuple
        routed_down_weights: bfloat16 [num_local_experts, hidden_size, routed_intermediate_size] or MXFP8 tensor tuple

    Outputs:
        d_x:                   bfloat16 [num_local_tokens, hidden_size]
        d_router_weights:      float32 [num_local_tokens, topk]
        d_routed_gate_weights: bfloat16 [num_local_experts, routed_intermediate_size, hidden_size]
        d_routed_up_weights:   bfloat16 [num_local_experts, routed_intermediate_size, hidden_size]
        d_routed_down_weights: bfloat16 [num_local_experts, hidden_size, routed_intermediate_size]
        d_shared_gate_weights: bfloat16 [shared_intermediate_size, hidden_size]
        d_shared_up_weights:   bfloat16 [shared_intermediate_size, hidden_size]
        d_shared_down_weights: bfloat16 [hidden_size, shared_intermediate_size]

    With `latent` given, three more gradients follow the eight above:

        d_latent_down_weights: bfloat16 [latent_size, hidden_size]
        d_latent_norm_weight:  float32 [latent_size]
        d_latent_up_weights:   bfloat16 [hidden_size, latent_size]

    The BF16 path permits distinct shared and routed intermediate sizes. The
    MXFP8 path currently requires them to be equal.
    """
    validate_inputs(config, workspace, schedule, x, router_weights, grad_output)
    if not isinstance(forward_context, MoKForwardContext):
        raise TypeError("forward_context must be a MoKForwardContext")
    if latent is not None:
        validate_latent_weights(workspace, latent)
        if not isinstance(latent_context, MoKLatentContext):
            raise TypeError("latent_context must be the MoKLatentContext the forward returned")
        if isinstance(routed_gate_weights, tuple):
            raise NotImplementedError("the latent projection currently requires the BF16 routed path")

    if latent is None:
        workspace.d_y_buffer.copy_(grad_output)            # TODO: we can remove this
        workspace.x_buffer.copy_(x)                        # TODO: we can remove this
        x_shared = None
        d_y_shared = None
    else:
        # The routed path carries the up-projection's input gradient at the latent width; the shared
        # experts keep the full-width one. Writing d_r straight into the symmetric buffer is again
        # what removes the staging copy.
        latent_gemm_out(workspace.d_y_buffer, grad_output, latent.up, LATENT_GEMM_AB, False)
        # The megakernel replays the routed forward, so `x_buffer` has to hold the projected tokens
        # again. Renormalizing `projected` reproduces them exactly and costs one elementwise pass,
        # which is cheaper than carrying another [tokens, latent] tensor through the graph.
        latent_rmsnorm_fwd(workspace.x_buffer, latent_context.projected,
                           latent.norm_weight, latent.eps)
        x_shared = x
        d_y_shared = grad_output
    workspace.router_weight_buffer.copy_(router_weights)   # TODO: we can remove this
    barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)
    if isinstance(routed_gate_weights, tuple):
        (routed_gate_weights_fp8, routed_gate_weights_sc,
         routed_gate_weights_t_fp8, routed_gate_weights_t_sc) = routed_gate_weights
        (routed_up_weights_fp8, routed_up_weights_sc,
         routed_up_weights_t_fp8, routed_up_weights_t_sc) = routed_up_weights
        routed_down_weights_t_fp8, routed_down_weights_t_sc = routed_down_weights
        x_fp8_t_routed, x_sc_t_routed = forward_context.x_routed
        gate_fp8_routed, gate_sc_routed = forward_context.gate_routed
        up_fp8_routed, up_sc_routed = forward_context.up_routed
        hidden_fp8_t_routed, hidden_sc_t_routed = forward_context.hidden_routed
        (d_x_shared, d_x_routed,
         d_gate_shared, d_gate_fp8_routed, d_gate_sc_routed,
         d_up_shared, d_up_fp8_routed, d_up_sc_routed,
         d_hidden_shared, d_hidden_routed, d_y_fp8_routed, d_y_sc_routed,
         d_w_shared_gate, d_w_routed_gate, d_w_shared_up, d_w_routed_up,
         d_w_shared_down, d_w_routed_down) = dispatch_mlp_swiglu_combine_bwd_mxfp8(
            workspace.d_y_buffer, workspace.d_y_buffer_ptrs,
            workspace.d_x_routed_buffer, workspace.d_x_routed_buffer_ptrs,
            workspace.router_weight_buffer, workspace.router_weight_buffer_ptrs,
            workspace.d_router_weight_buffer, workspace.d_router_weight_buffer_ptrs,
            shared_gate_weights, routed_gate_weights_t_fp8, routed_gate_weights_t_sc,
            shared_up_weights, routed_up_weights_t_fp8, routed_up_weights_t_sc,
            shared_down_weights, routed_down_weights_t_fp8, routed_down_weights_t_sc,
            x_fp8_t_routed, x_sc_t_routed,
            forward_context.gate_shared, gate_fp8_routed, gate_sc_routed,
            forward_context.up_shared, up_fp8_routed, up_sc_routed,
            forward_context.hidden_shared, hidden_fp8_t_routed, hidden_sc_t_routed,
            workspace.x_buffer, workspace.x_buffer_ptrs,
            routed_gate_weights_fp8, routed_gate_weights_sc,
            routed_up_weights_fp8, routed_up_weights_sc,
            schedule.peer_rank, schedule.peer_token_idx,
            schedule.num_tokens, schedule.tokens_per_expert,
            workspace.topk, config.bwd_num_comm_sms,
            config.macrobatch_size, config.minibatch_size,
        )
    else:
        x_routed = forward_context.x_routed
        gate_routed = forward_context.gate_routed
        up_routed = forward_context.up_routed
        hidden_routed = forward_context.hidden_routed
        (d_x_shared, d_x_routed, d_gate_shared, d_gate_routed,
         d_up_shared, d_up_routed, d_hidden_shared, d_hidden_routed, d_y_routed,
         d_w_shared_gate, d_w_routed_gate, d_w_shared_up, d_w_routed_up,
         d_w_shared_down, d_w_routed_down) = dispatch_mlp_swiglu_combine_bwd_bf16(
            workspace.d_y_buffer, workspace.d_y_buffer_ptrs,
            workspace.d_x_routed_buffer, workspace.d_x_routed_buffer_ptrs,
            workspace.router_weight_buffer, workspace.router_weight_buffer_ptrs,
            workspace.d_router_weight_buffer, workspace.d_router_weight_buffer_ptrs,
            shared_gate_weights, routed_gate_weights,
            shared_up_weights, routed_up_weights,
            shared_down_weights, routed_down_weights,
            x_routed, forward_context.gate_shared, gate_routed,
            forward_context.up_shared, up_routed,
            forward_context.hidden_shared, hidden_routed,
            workspace.x_buffer, workspace.x_buffer_ptrs,
            schedule.peer_rank, schedule.peer_token_idx,
            schedule.num_tokens, schedule.tokens_per_expert,
            workspace.topk, config.bwd_num_comm_sms,
            config.macrobatch_size, config.minibatch_size,
            x_shared,
            d_y_shared,
        )

    barrier_all(workspace.barrier_buffer, workspace.barrier_buffer_ptrs,
                workspace.barrier_buffer_multicast_ptr, workspace.barrier_target)
    d_router_weights = workspace.d_router_weight_buffer.clone()  # TODO: we can remove this
    if latent is None:
        d_x = bwd_epilogue(d_x_shared, workspace.d_x_routed_buffer)
        return (d_x, d_router_weights, d_w_routed_gate, d_w_routed_up, d_w_routed_down,
                d_w_shared_gate, d_w_shared_up, d_w_shared_down)

    # Reduce the routed rows and backpropagate the norm in one pass, then take the down-projection's
    # dgrad straight on top of `d_x_shared`. Between them these do what `bwd_epilogue` does for the
    # non-latent path, without either the reduced gradient or the expanded one reaching HBM.
    d_projected, d_latent_norm_weight = latent_rmsnorm_bwd(
        workspace.d_x_routed_buffer, latent_context.projected, latent_context.rstd,
        latent.norm_weight, workspace.topk)
    d_latent_down_weights = latent_gemm(d_projected, x, LATENT_GEMM_ATB)
    d_latent_up_weights = latent_gemm(grad_output, latent_context.combined, LATENT_GEMM_ATB)
    latent_gemm_out(d_x_shared, d_projected, latent.down, LATENT_GEMM_AB, True)
    return (d_x_shared, d_router_weights, d_w_routed_gate, d_w_routed_up, d_w_routed_down,
            d_w_shared_gate, d_w_shared_up, d_w_shared_down,
            d_latent_down_weights, d_latent_norm_weight, d_latent_up_weights)
