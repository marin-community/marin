# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Provenance of a built artifact: a content-addressed tree hash plus the human
and launch context (branch, base commit, builder, origin, time, argv) needed to read it.

The ``tree_hash`` is content-addressed and deterministic — the same working-tree
content always produces the same hash regardless of when or by whom it is built —
so it is the natural deduplication key for image tags and version comparisons. The
remaining fields render that hash in a form a human can recognize and record the
launch that produced an artifact.

Two constructors capture it. :meth:`Provenance.from_git` is strict — it raises if git
is unavailable — for an image build, where the content-addressed ``tree_hash`` must
exist. :meth:`Provenance.capture` is best-effort — every field degrades to empty
outside a checkout — for stamping an artifact built by an arbitrary launch.
"""

import dataclasses
import functools
import getpass
import json
import logging
import os
import re
import subprocess
import sys
import threading
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from rigging.secrets import looks_like_credential

logger = logging.getLogger(__name__)

LAUNCH_PROVENANCE_ENV = "MARIN_PROVENANCE"
"""Env var carrying the launch's :class:`Provenance` as JSON.

A submitting client stamps it into a job's environment (see iris
``EnvironmentSpec.to_proto``), so a process running from a ``.git``-less bundle inherits the
submission's provenance — :meth:`Provenance.capture` prefers it over shelling out to git.
"""


# The JSON type each field may hold in ``Provenance.to_json`` output.
_JSON_FIELD_TYPES: dict[str, tuple[type, ...]] = {
    "tree_hash": (str,),
    "base_commit": (str,),
    "dirty": (bool,),
    "branch": (str, type(None)),
    "built_by": (str, type(None)),
    "git_remote": (str, type(None)),
    "created_at": (str,),
    "command_line": (list,),
}
_REQUIRED_JSON_FIELDS = frozenset({"tree_hash", "base_commit", "dirty"})


@dataclass(frozen=True)
class Provenance:
    """Identity, human context, and launch context of a built artifact.

    Attributes:
        tree_hash: Short git tree hash of the tracked working-tree content. The
            deduplication key — content-addressed and stable across builds.
        base_commit: Short hash of the HEAD commit the tree was built from.
        dirty: Whether the working tree had uncommitted or untracked changes.
        branch: Branch name at build time, or ``None`` for a detached HEAD.
        built_by: OS user that ran the build, or ``None`` if unknown.
        git_remote: ``origin`` remote URL, or ``None`` if unknown.
        created_at: ISO-8601 time the launch was captured, or ``""`` if uncaptured.
        command_line: ``sys.argv`` of the launching process; empty if uncaptured.
    """

    tree_hash: str
    base_commit: str
    dirty: bool
    branch: str | None
    built_by: str | None
    git_remote: str | None = None
    created_at: str = ""
    command_line: tuple[str, ...] = ()

    @staticmethod
    def _redact_credentials(argv: Sequence[str]) -> tuple[str, ...]:
        """Replace values of credential-named flags with redaction markers.

        ``-e KEY VALUE`` pairs whose key names a credential (tokens, secrets, passwords, API keys)
        carry values that must not reach artifact provenance: jobs deliver credentials through the
        secret mechanism, never plain environment variables. The key stays legible; only the value
        is redacted.
        """
        redacted: list[str] = []
        expect_key = False
        expect_value = False
        for part in argv:
            if expect_key:
                # The flag's key: keep it legible; redact the value only when it names a credential.
                redacted.append(part)
                expect_key, expect_value = False, looks_like_credential(part)
                continue
            if expect_value:
                redacted.append("[REDACTED:credential]")
                expect_value = False
                continue
            redacted.append(part)
            for flag in ("-e", "--env-vars"):
                if part == flag:
                    expect_key = True
                    break
        return tuple(redacted)

    @classmethod
    def from_git(cls, repo_dir: Path | None = None) -> "Provenance":
        """Capture build provenance from the git repository at ``repo_dir`` (or cwd).

        Strict: raises if git is unavailable, since the content-addressed
        ``tree_hash`` is the reason to build at all.
        """
        # `git stash create` captures any dirty state as a transient commit whose
        # tree we deref below — dropping the per-call timestamp a commit hash
        # would carry, so tree_hash stays purely content-addressed. Empty (no
        # output) means a clean tree, so fall back to HEAD.
        stash = git_output(["stash", "create"], repo_dir)
        ref = stash or "HEAD"
        return cls(
            tree_hash=git_output(["rev-parse", "--short", f"{ref}^{{tree}}"], repo_dir),
            base_commit=git_output(["rev-parse", "--short", "HEAD"], repo_dir),
            dirty=bool(git_output(["status", "--porcelain", "--untracked-files=all"], repo_dir)),
            branch=git_output(["symbolic-ref", "--short", "-q", "HEAD"], repo_dir, check=False) or None,
            built_by=_getuser(),
        )

    @classmethod
    def capture(cls, repo_dir: Path | None = None) -> "Provenance":
        """Best-effort provenance of the current launch: git context plus the origin
        remote, capture time, and argv.

        Prefers the provenance published in ``MARIN_PROVENANCE`` (stamped by the submitting
        client) — returned verbatim, so a remote process reports the launch that produced it,
        not itself. Otherwise tolerant git capture: every git field degrades to empty/``None``
        outside a checkout or when the ``git`` binary is absent, so it never raises. Use to
        stamp an artifact built by an arbitrary run.
        """
        published = _provenance_from_env()
        if published is not None:
            return published

        def g(*args: str) -> str:
            # A missing `git` binary (bundle image without git) degrades like being outside
            # a checkout: git fields empty, launch context still captured.
            try:
                return git_output(list(args), repo_dir, check=False)
            except FileNotFoundError:
                return ""

        stash = g("stash", "create")
        ref = stash or "HEAD"
        return cls(
            tree_hash=g("rev-parse", "--short", f"{ref}^{{tree}}"),
            base_commit=g("rev-parse", "--short", "HEAD"),
            dirty=bool(g("status", "--porcelain", "--untracked-files=all")),
            branch=g("symbolic-ref", "--short", "-q", "HEAD") or None,
            built_by=_getuser(),
            git_remote=g("remote", "get-url", "origin") or None,
            created_at=datetime.now().isoformat(),
            command_line=cls._redact_credentials(sys.argv),
        )

    @classmethod
    def from_json(cls, raw: str) -> "Provenance":
        """Parse what :meth:`to_json` writes.

        Raises ``ValueError`` for anything else: text that is not JSON or is nested
        too deeply to parse, a value that is not an object, a missing required
        field, or a field of the wrong type. A malformed payload is not an identity:
        ``built_by`` feeds per-user namespacing, and callers fall back on error.
        """
        try:
            d = json.loads(raw)
        except RecursionError as error:
            raise ValueError("provenance JSON is nested too deeply to parse") from error
        if not isinstance(d, dict):
            raise ValueError(f"provenance must be a JSON object, got {type(d).__name__}")
        for name, types in _JSON_FIELD_TYPES.items():
            if name in d and not isinstance(d[name], types):
                raise ValueError(f"provenance field {name} has type {type(d[name]).__name__}")
            if name in _REQUIRED_JSON_FIELDS and name not in d:
                raise ValueError(f"provenance is missing {name}")
        command_line = d.get("command_line", [])
        if not all(isinstance(arg, str) for arg in command_line):
            raise ValueError("provenance command_line must be a list of strings")
        return cls(
            tree_hash=d["tree_hash"],
            base_commit=d["base_commit"],
            dirty=d["dirty"],
            branch=d.get("branch"),
            built_by=d.get("built_by"),
            git_remote=d.get("git_remote"),
            created_at=d.get("created_at", ""),
            command_line=tuple(command_line),
        )

    def to_json(self) -> str:
        return json.dumps(dataclasses.asdict(self))

    @property
    def dedup_key(self) -> str:
        """The value to key image tags and version comparisons on."""
        return self.tree_hash

    def __str__(self) -> str:
        suffix = ""
        if self.branch:
            suffix += f" ({self.branch})"
        if self.built_by:
            suffix += f" ({self.built_by})"
        if self.dirty:
            return f"{self.tree_hash} (off of {self.base_commit}){suffix}"
        return f"{self.base_commit}{suffix}"


def _provenance_from_env() -> Provenance | None:
    """The provenance published in ``MARIN_PROVENANCE``, or ``None`` when absent or malformed.

    A malformed value must not break stamping or namespacing; callers fall back.
    """
    raw = os.environ.get(LAUNCH_PROVENANCE_ENV)
    if not raw:
        return None
    try:
        return Provenance.from_json(raw)
    except ValueError:
        logger.warning("Ignoring malformed %s value: %r", LAUNCH_PROVENANCE_ENV, raw)
        return None


@functools.cache
def _capture_once() -> Provenance:
    return Provenance.capture()


# functools.cache does not serialize concurrent first calls, and two concurrent
# `git stash create` runs race on the repo's index.lock — the loser silently stamps
# a dirty tree as clean HEAD. The lock makes the cache-filling capture exclusive.
_capture_lock = threading.Lock()


def launch_provenance() -> Provenance:
    """The current launch's provenance, captured once per process (thread-safe)."""
    with _capture_lock:
        return _capture_once()


def git_output(args: list[str], cwd: Path | None, *, check: bool = True, timeout: float | None = None) -> str:
    """Return Git stdout; checked failures raise with stderr."""
    try:
        result = subprocess.run(["git", *args], capture_output=True, text=True, cwd=cwd, timeout=timeout)
    except subprocess.TimeoutExpired as error:
        raise RuntimeError(f"git {' '.join(args)} timed out after {timeout} seconds") from error
    if check and result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def _getuser() -> str | None:
    # getpass.getuser() raises when no username resolves from the environment or the
    # password database; provenance is best-effort, so treat that as unknown.
    try:
        return getpass.getuser()
    except (OSError, KeyError):
        return None


# A path segment is lowercase alphanumerics plus '_' and '-'; collapse anything else.
_USER_SEGMENT_RE = re.compile(r"[^a-z0-9_-]+")

# Machine/service logins that must never own a per-user namespace: resolving to one of
# these means the launching human's identity was not threaded to this process.
_MACHINE_LOGINS = frozenset({"root", "runner", "ubuntu", "exedev"})


def username_segment() -> str:
    """The current user as a path-safe segment, for per-user artifact namespacing.

    Resolves the same user that stamps provenance ``built_by``: the launch identity carried
    in ``MARIN_PROVENANCE`` when present — so a remote worker namespaces under the submitting
    human, not its own OS login — otherwise the local OS login. The raw name is reduced to a
    clean segment: an email-like login drops its domain but keeps the whole local name
    (``russell.power@host`` → ``russell-power``), and the result is lowercased with any
    remaining character collapsed to ``-``. The full local name is kept so distinct users stay
    distinct. Raises ``RuntimeError`` if no username resolves — per-user namespacing must never
    silently fall back to a shared bucket.
    """
    launch = _provenance_from_env()
    raw = (launch.built_by if launch is not None else None) or _getuser()
    if not raw:
        raise RuntimeError(
            "cannot resolve a username for per-user namespacing "
            "(no launch provenance built_by, and getpass.getuser found none)"
        )
    name = raw.strip()
    if "@" in name:
        name = name.split("@", 1)[0]
    segment = _USER_SEGMENT_RE.sub("-", name.lower()).strip("-")
    if not segment:
        raise RuntimeError(f"username {raw!r} did not sanitize to a usable path segment")
    if segment in _MACHINE_LOGINS:
        logger.warning(
            "per-user namespace resolved to machine login %r — the launching human's identity "
            "was not threaded to this process",
            segment,
        )
    return segment
