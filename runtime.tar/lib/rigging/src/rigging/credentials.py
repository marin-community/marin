# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Resolve the client credentials for talking to a Marin cluster.

This is the consumer convention behind "one login": given a cluster's auth
shape, assemble the bearer material a client must attach. It never runs an
interactive flow — acquiring the IAP edge refresh token (the browser OAuth flow)
is the job of the login orchestration layer above; this module only locates
whatever that produced and hands back ready-to-attach interceptors.

The controller mints no user token, so the ``Authorization`` bearer carries
nothing for ordinary user / CLI traffic. A client may set ``$MARIN_CLUSTER_TOKEN``
to inject an explicit bearer (e.g. a worker JWT) for CI / headless runs.

IAP edge-token resolution (the ``Proxy-Authorization`` bearer, IAP clusters only)
is the sole per-request auth. Precedence (see :func:`iap_provider_for`): the cached
desktop-OAuth refresh token (the human path), otherwise an ambient service-account
ID token — a key, GCE metadata, or an impersonated ADC (the in-cluster / CI path).
The machine path mints for a dedicated programmatic audience if one is configured,
else for the desktop client id, which is the app's public identity
(:data:`~rigging.auth.MARIN_DESKTOP_OAUTH_CLIENT`), overridable per cluster.
"""

import os
from collections.abc import Sequence
from dataclasses import dataclass

from rigging.auth import (
    MARIN_DESKTOP_OAUTH_CLIENT,
    BearerTokenInjector,
    IapRefreshTokenProvider,
    IapServiceAccountTokenProvider,
    OAuthClient,
    StaticTokenProvider,
    TokenProvider,
)
from rigging.cluster_manifest import AuthProvider, ClusterAuth
from rigging.credential_store import load_credentials

MARIN_CLUSTER_TOKEN_ENV = "MARIN_CLUSTER_TOKEN"


@dataclass(frozen=True)
class ClientCredentials:
    """Bearer material for outgoing RPCs to a Marin service.

    Bundles the app-auth provider (attached on ``Authorization``) and, for an
    IAP-fronted cluster, the IAP edge provider (``Proxy-Authorization``). Passing
    both as one value keeps a call site from attaching one and forgetting the
    other — the failure where a command works on a tunneled cluster but is
    rejected by IAP because it never sent the edge token.
    """

    token_provider: TokenProvider | None = None
    iap_provider: TokenProvider | None = None

    def _bearers(self) -> tuple[tuple[str, TokenProvider], ...]:
        """The (header, provider) pairs to attach, skipping absent providers.

        The app token rides in ``Authorization``; the IAP edge token in
        ``Proxy-Authorization`` so the app header stays free for the service's own
        JWT. Either may be absent (loopback trust sends neither).
        """
        pairs = (("authorization", self.token_provider), ("proxy-authorization", self.iap_provider))
        return tuple((header, provider) for header, provider in pairs if provider is not None)

    def interceptors(self) -> tuple:
        """The client-side interceptor chain for these credentials."""
        return tuple(BearerTokenInjector(provider, header) for header, provider in self._bearers())

    def headers(self) -> dict[str, str]:
        """The same bearer headers :meth:`interceptors` attaches, for plain-HTTP callers.

        Mints on every call, so do not cache the result across requests.
        """
        return {header: f"Bearer {token}" for header, provider in self._bearers() if (token := provider.get_token())}


def _login_hint(cluster: str) -> str:
    """The canonical 'log in again' remedy for ``cluster``."""
    return f"log in to cluster {cluster!r} to authenticate"


def iap_edge_provider(
    cluster: str,
    *,
    desktop_client: OAuthClient = MARIN_DESKTOP_OAUTH_CLIENT,
) -> IapRefreshTokenProvider | None:
    """Build the IAP edge provider from ``cluster``'s cached desktop-OAuth login.

    Pairs the refresh token cached by the cluster login with ``cluster``'s
    desktop client to silently re-mint the OIDC ID token IAP requires. Returns
    None when the user has not logged in (so a pre-login command degrades to a
    clear UNAUTHENTICATED error rather than crashing on a missing credential).
    """
    record = load_credentials(cluster)
    if record is None or record.edge_refresh_token is None:
        return None
    return IapRefreshTokenProvider(
        desktop_client.client_id,
        desktop_client.client_secret,
        record.edge_refresh_token,
        login_hint=_login_hint(cluster),
    )


def _desktop_client(auth: ClusterAuth) -> OAuthClient:
    """The cluster's desktop OAuth client, falling back to the Marin app default."""
    iap = auth.iap
    if iap is not None and iap.desktop_oauth_client_id and iap.desktop_oauth_client_secret:
        return OAuthClient(iap.desktop_oauth_client_id, iap.desktop_oauth_client_secret)
    return MARIN_DESKTOP_OAUTH_CLIENT


def iap_provider_for(
    cluster: str,
    *,
    audiences: Sequence[str] = (),
    desktop_client: OAuthClient = MARIN_DESKTOP_OAUTH_CLIENT,
) -> TokenProvider:
    """The IAP edge provider for ``cluster``, human login first.

    A cached desktop login wins; otherwise the token is minted from ambient
    service-account credentials (a key, GCE metadata, an impersonated ADC, or a
    Workload Identity Federation ADC). ``audiences`` is the cluster's configured
    programmatic audience list; when it is empty the machine path mints for
    ``desktop_client``'s id, which IAP registers as a programmatic client and
    admits -- the same ``aud`` the human path presents. Either way IAP still
    checks the caller against the backend allowlist for authorization.
    """
    human = iap_edge_provider(cluster, desktop_client=desktop_client)
    if human is not None:
        return human
    return IapServiceAccountTokenProvider(audiences[0] if audiences else desktop_client.client_id)


def _edge_provider(cluster: str, auth: ClusterAuth) -> TokenProvider | None:
    """Resolve the IAP edge provider, or None for a non-IAP cluster."""
    if auth.provider is not AuthProvider.IAP or auth.iap is None:
        return None
    desktop_client = _desktop_client(auth)
    return iap_provider_for(
        cluster,
        audiences=auth.iap.programmatic_audiences,
        desktop_client=desktop_client,
    )


def credentials_for(
    cluster: str,
    auth: ClusterAuth,
    *,
    token_env: str = MARIN_CLUSTER_TOKEN_ENV,
) -> ClientCredentials:
    """Assemble the :class:`ClientCredentials` for ``cluster`` from the standard sources.

    ``auth`` is the cluster's resolved auth shape (provider + IAP params). The IAP
    edge provider is the sole per-request auth (``Proxy-Authorization``); the
    ``Authorization`` bearer is empty unless ``$MARIN_CLUSTER_TOKEN`` injects one.
    """
    override = os.environ.get(token_env)
    return ClientCredentials(
        token_provider=StaticTokenProvider(override) if override else None,
        iap_provider=_edge_provider(cluster, auth),
    )
