# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Bucket-routed filesystems: one process, every Marin backend.

:mod:`rigging.filesystem.factory` resolves a URL against the process-wide fsspec
configuration, which holds exactly one S3 endpoint at a time. That is right for a
task pinned to one cluster and wrong for anything that spans backends — a browser
listing GCS and CoreWeave side by side, or a copy from CoreWeave to GCS.

:func:`filesystem_for` routes instead on the bucket's declared backend
(``config/*.yaml`` via :func:`rigging.filesystem.cluster_config.data_buckets`), building each
S3-compatible filesystem with explicit endpoint, signing region, and credentials
rather than reading or writing environment variables. GCS and unregistered buckets
fall through to the guarded factory, so cross-region metering and ``mirror://``
still apply where they already did.
"""

import logging
from enum import StrEnum
from typing import Any

import s3fs

from rigging.filesystem.bulk_deletion import with_bulk_deletion
from rigging.filesystem.cluster_config import BucketSpec, StoreType, data_buckets
from rigging.filesystem.factory import url_to_fs
from rigging.filesystem.paged_listing import with_listing
from rigging.filesystem.s3_compat import (
    credentials_hint,
    fsspec_s3_conf,
    s3_credentials,
    s3_endpoint,
    s3_python_config_kwargs,
)
from rigging.filesystem.storage_path import StoragePath

logger = logging.getLogger(__name__)


class MissingCredentials(Exception):
    """A bucket's backend has no usable credentials in the environment."""


class S3UploadPolicy(StrEnum):
    STANDARD = "standard"
    FIXED_PARTS = "fixed_parts"


def filesystem_for(
    url: str,
    *,
    s3_upload_policy: S3UploadPolicy = S3UploadPolicy.STANDARD,
) -> tuple[Any, str]:
    """Return ``(fs, path)`` for *url*, routed by the bucket's declared backend.

    An ``s3://`` URL naming a bucket declared as R2 or CoreWeave gets a dedicated
    :class:`s3fs.S3FileSystem` carrying that backend's endpoint, addressing style,
    signing region, and credentials; instances are shared through s3fs's own
    kwargs-keyed cache. Everything else — GCS, local paths, ``mirror://``, and
    ``s3://`` buckets no config declares — goes through the guarded
    :func:`rigging.filesystem.factory.url_to_fs`, which reads the ambient environment.
    S3 and GCS results expose paged listing and bulk deletion through
    ``fs.listing`` and ``fs.deletion``.

    Raises:
        MissingCredentials: if the routed backend has no credentials configured.
    """
    parsed = StoragePath(url)
    if parsed.scheme != "s3":
        fs, path = url_to_fs(url)
        return _with_object_store_operations(fs), path

    spec = data_buckets().get(parsed.bucket)
    if spec is None or spec.store not in (StoreType.R2, StoreType.COREWEAVE):
        fs, path = url_to_fs(url)
        return _with_object_store_operations(fs), path

    return _with_object_store_operations(_s3_filesystem(spec, s3_upload_policy)), _s3_path(parsed)


def _with_object_store_operations(fs: Any) -> Any:
    return with_bulk_deletion(with_listing(fs))


def _s3_path(parsed: StoragePath) -> str:
    """``bucket/key`` — the protocol-stripped form s3fs expects."""
    return f"{parsed.bucket}/{parsed.key}" if parsed.key else parsed.bucket


def _s3_filesystem(spec: BucketSpec, upload_policy: S3UploadPolicy) -> s3fs.S3FileSystem:
    """Build (or reuse) the S3 filesystem serving *spec*'s backend.

    The signing region is the bucket's own for CoreWeave, whose endpoint routes on it, and
    ``"auto"`` for R2, which ignores the AWS region scheme entirely.
    """
    credentials = s3_credentials(spec.store)
    if credentials is None:
        raise MissingCredentials(f"no credentials for {spec.store} bucket {spec.name!r}: {credentials_hint(spec.store)}")
    key, secret = credentials

    endpoint = s3_endpoint(spec.store)
    conf = fsspec_s3_conf(endpoint)
    return s3fs.S3FileSystem(
        key=key,
        secret=secret,
        endpoint_url=endpoint,
        client_kwargs={"region_name": spec.signing_region or "auto"},
        # ``fsspec_s3_conf`` is the JSON-safe env shape, so it carries the
        # endpoint's addressing style but not the whole-request deadline.
        config_kwargs={**conf["config_kwargs"], **s3_python_config_kwargs()},
        fixed_upload_size=upload_policy is S3UploadPolicy.FIXED_PARTS,
    )
