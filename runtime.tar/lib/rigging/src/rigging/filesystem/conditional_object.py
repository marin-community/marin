# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Conditional reads and writes for one mutable object.

Object storage has no portable compare-and-swap API in fsspec. This module exposes the
small common operation needed by commit pointers: read bytes with an opaque version, then
replace those bytes only if the version is unchanged. Local files use ``flock``, GCS uses
generations, and S3 uses ETags with conditional ``PutObject`` headers.
"""

from __future__ import annotations

import fcntl
import functools
import hashlib
import os
from dataclasses import dataclass
from typing import Protocol

import botocore.config
import botocore.session
from botocore.exceptions import ClientError
from google.api_core.exceptions import NotFound, PreconditionFailed
from google.cloud import storage

import rigging.filesystem.factory as factory
from rigging.filesystem.atomic import unique_temp_path
from rigging.filesystem.s3_compat import s3_credential_options
from rigging.filesystem.s3_errors import is_transient_s3_error
from rigging.filesystem.storage_path import StoragePath
from rigging.timing import ExponentialBackoff, retry_with_backoff

_MAX_READ_ATTEMPTS = 8
_MAX_S3_READ_ATTEMPTS = 8
_S3_READ_BACKOFF = ExponentialBackoff(initial=0.1, maximum=5.0, factor=2.0, jitter=0.25)
_MAX_S3_WRITE_ATTEMPTS = 8
_S3_WRITE_BACKOFF_INITIAL = 1.0
_S3_WRITE_BACKOFF_MAXIMUM = 10 * 60.0
_S3_MISSING_CODES = frozenset({"NotFound", "NoSuchKey", "404"})
_S3_CONDITIONAL_READ_RETRY_CODES = frozenset({"PathStyleRequestNotAllowed"})


def _is_retryable_s3_conditional_read(error: Exception) -> bool:
    if is_transient_s3_error(error):
        return True
    if not isinstance(error, ClientError):
        return False
    return error.response.get("Error", {}).get("Code") in _S3_CONDITIONAL_READ_RETRY_CODES


class ConditionalWriteError(RuntimeError):
    """The object changed after it was read."""


class UnsupportedConditionalWrite(ValueError):
    """The path's backend cannot provide an atomic conditional write."""


@dataclass(frozen=True)
class VersionedBytes:
    """Bytes read from an object and the opaque backend version that identifies them."""

    data: bytes
    version: str


class ConditionalObject(Protocol):
    """One object supporting compare-and-swap publication."""

    @property
    def path(self) -> str: ...

    def version(self) -> str | None:
        """Return the current opaque object version, or None when the object is absent."""
        ...

    def read(self) -> VersionedBytes | None: ...

    def write(self, data: bytes, *, expected_version: str | None) -> str: ...


def _local_version(data: bytes) -> str:
    return hashlib.blake2b(data, digest_size=16).hexdigest()


@functools.cache
def _gcs_client() -> storage.Client:
    return storage.Client()


@dataclass(frozen=True)
class LocalConditionalObject:
    """A local object whose readers and writers coordinate through ``flock``."""

    path: str

    def _local_path(self) -> str:
        fs, local_path = factory.url_to_fs(self.path)
        if not getattr(fs, "local_file", False):
            raise UnsupportedConditionalWrite(f"{self.path!r} is not a local path")
        return local_path

    def version(self) -> str | None:
        local_path = self._local_path()
        try:
            with open(local_path, "rb") as handle:
                fcntl.flock(handle.fileno(), fcntl.LOCK_SH)
                return _local_version(handle.read())
        except FileNotFoundError:
            return None

    def read(self) -> VersionedBytes | None:
        local_path = self._local_path()
        try:
            with open(local_path, "rb") as handle:
                fcntl.flock(handle.fileno(), fcntl.LOCK_SH)
                data = handle.read()
        except FileNotFoundError:
            return None
        return VersionedBytes(data=data, version=_local_version(data))

    def write(self, data: bytes, *, expected_version: str | None) -> str:
        local_path = self._local_path()
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        if expected_version is None:
            # Publish the initialized inode at once: opening the destination before flock
            # lets a concurrent reader acquire its shared lock while the file is empty.
            temp_path = unique_temp_path(local_path)
            with open(temp_path, "xb") as handle:
                try:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
                    try:
                        os.link(temp_path, local_path)
                    except FileExistsError as error:
                        raise ConditionalWriteError(
                            f"conditional create failed for {self.path}: object exists"
                        ) from error
                finally:
                    os.unlink(temp_path)
            return _local_version(data)
        try:
            with open(local_path, "r+b") as handle:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                handle.seek(0)
                current = handle.read()
                found_version = _local_version(current)
                if found_version != expected_version:
                    raise ConditionalWriteError(
                        f"conditional write failed for {self.path}: "
                        f"expected {expected_version!r}, found {found_version!r}"
                    )
                handle.seek(0)
                handle.truncate()
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
        except FileNotFoundError as error:
            raise ConditionalWriteError(f"conditional update failed for {self.path}: object is absent") from error
        return _local_version(data)


@dataclass(frozen=True)
class GcsConditionalObject:
    """A GCS object using blob generations as compare-and-swap versions."""

    path: str

    def _bucket_and_key(self):
        parsed = StoragePath(self.path)
        return _gcs_client().bucket(parsed.bucket), parsed.key

    def version(self) -> str | None:
        bucket, key = self._bucket_and_key()
        blob = bucket.get_blob(key)
        if blob is None:
            return None
        assert blob.generation is not None
        return str(blob.generation)

    def read(self) -> VersionedBytes | None:
        bucket, key = self._bucket_and_key()
        for _attempt in range(_MAX_READ_ATTEMPTS):
            blob = bucket.get_blob(key)
            if blob is None:
                return None
            assert blob.generation is not None
            generation = blob.generation
            try:
                data = blob.download_as_bytes(if_generation_match=generation)
            except NotFound:
                return None
            except PreconditionFailed:
                continue
            return VersionedBytes(data=data, version=str(generation))
        raise ConditionalWriteError(f"object changed {_MAX_READ_ATTEMPTS} consecutive times while reading {self.path}")

    def write(self, data: bytes, *, expected_version: str | None) -> str:
        bucket, key = self._bucket_and_key()
        blob = bucket.blob(key)
        generation = 0 if expected_version is None else int(expected_version)
        try:
            blob.upload_from_string(data, if_generation_match=generation)
        except PreconditionFailed as exc:
            raise ConditionalWriteError(f"conditional write failed for {self.path}") from exc
        assert blob.generation is not None
        return str(blob.generation)


@dataclass(frozen=True)
class S3ConditionalObject:
    """An S3 object using ETags as compare-and-swap versions."""

    path: str
    endpoint_url: str | None = None

    @staticmethod
    @functools.cache
    def _client(endpoint_url: str | None):
        session = botocore.session.get_session()
        config = botocore.config.Config(s3={"addressing_style": "virtual"})
        credentials = {}
        options = s3_credential_options()
        access_key = options.get("key")
        secret_key = options.get("secret")
        if access_key and secret_key:
            credentials = {
                "aws_access_key_id": access_key,
                "aws_secret_access_key": secret_key,
            }
            if session_token := options.get("token"):
                credentials["aws_session_token"] = session_token
        if endpoint_url:
            return session.create_client("s3", endpoint_url=endpoint_url, config=config, **credentials)
        return session.create_client("s3", config=config, **credentials)

    def _parts(self) -> tuple[str, str]:
        parsed = StoragePath(self.path)
        return parsed.bucket, parsed.key

    def version(self) -> str | None:
        bucket, key = self._parts()
        client = self._client(self.endpoint_url)

        def head() -> dict | None:
            try:
                return client.head_object(Bucket=bucket, Key=key)
            except ClientError as exc:
                if exc.response["Error"]["Code"] in _S3_MISSING_CODES:
                    return None
                raise

        response = retry_with_backoff(
            head,
            retryable=_is_retryable_s3_conditional_read,
            max_attempts=_MAX_S3_READ_ATTEMPTS,
            backoff=_S3_READ_BACKOFF,
            operation=f"conditional S3 version read {self.path}",
        )
        if response is None:
            return None
        return response["ETag"]

    def read(self) -> VersionedBytes | None:
        bucket, key = self._parts()
        client = self._client(self.endpoint_url)

        def get() -> VersionedBytes | None:
            try:
                response = client.get_object(Bucket=bucket, Key=key)
            except ClientError as exc:
                if exc.response["Error"]["Code"] in _S3_MISSING_CODES:
                    return None
                raise
            return VersionedBytes(data=response["Body"].read(), version=response["ETag"])

        return retry_with_backoff(
            get,
            retryable=_is_retryable_s3_conditional_read,
            max_attempts=_MAX_S3_READ_ATTEMPTS,
            backoff=_S3_READ_BACKOFF,
            operation=f"conditional S3 read {self.path}",
        )

    def write(self, data: bytes, *, expected_version: str | None) -> str:
        client = self._client(self.endpoint_url)
        bucket, key = self._parts()
        condition = {"IfNoneMatch": "*"} if expected_version is None else {"IfMatch": expected_version}
        reconcile = False

        def put() -> dict:
            nonlocal reconcile
            if reconcile:
                current = self.read()
                if current is not None and current.data == data:
                    return {"ETag": current.version}
                current_version = None if current is None else current.version
                if current_version != expected_version:
                    raise ConditionalWriteError(f"conditional write failed for {self.path}")
                reconcile = False
            try:
                return client.put_object(Bucket=bucket, Key=key, Body=data, **condition)
            except ClientError as exc:
                if exc.response["Error"]["Code"] in (
                    "PreconditionFailed",
                    "ConditionalRequestConflict",
                    "409",
                    "412",
                ):
                    raise ConditionalWriteError(f"conditional write failed for {self.path}") from exc
                if is_transient_s3_error(exc):
                    reconcile = True
                raise
            except Exception as exc:
                if is_transient_s3_error(exc):
                    reconcile = True
                raise

        response = retry_with_backoff(
            put,
            retryable=is_transient_s3_error,
            max_attempts=_MAX_S3_WRITE_ATTEMPTS,
            backoff=ExponentialBackoff(
                initial=_S3_WRITE_BACKOFF_INITIAL,
                maximum=_S3_WRITE_BACKOFF_MAXIMUM,
                factor=2.0,
                jitter=0.25,
            ),
            operation=f"conditional S3 write {self.path}",
        )
        return response["ETag"]


def conditional_object(path: str) -> ConditionalObject:
    """Return the conditional object implementation for ``path``.

    Generic fsspec schemes are intentionally rejected. A writable commit pointer must not
    silently degrade to last-writer-wins behavior.
    """
    parsed = StoragePath(path)
    if parsed.is_local:
        return LocalConditionalObject(path)
    if parsed.scheme == "gs":
        return GcsConditionalObject(path)
    if parsed.scheme == "s3":
        endpoint_url = os.environ.get("AWS_ENDPOINT_URL_S3") or os.environ.get("AWS_ENDPOINT_URL")
        return S3ConditionalObject(path, endpoint_url=endpoint_url)
    raise UnsupportedConditionalWrite(f"conditional writes are not supported for {parsed.scheme!r} paths")
