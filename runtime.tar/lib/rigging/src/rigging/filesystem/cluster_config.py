# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Cluster data config, storage-prefix/region resolution, lifecycle-managed temp
storage, and GCS-location utilities.

A :class:`DataConfig` describes where a cluster's data lives: the
region-to-bucket mirror set, the URL scheme, and the temp TTL policy.
:func:`data_config` returns the active config — the one bound by
:func:`use_data_config`, else the cluster named by ``MARIN_CLUSTER`` (default
``marin``), loaded from ``config/<cluster>.yaml``. Every "where does data live"
answer flows through it: :func:`marin_prefix` is ``data_config().resolved_root()``,
while :func:`marin_temp_bucket` resolves backend scratch storage, honoring a
cluster-wide ``MARIN_TEMP_PREFIX`` override when configured. Lifecycle rules
on every configured data bucket are managed by ``infra/buckets``.
"""

import contextlib
import contextvars
import dataclasses
import functools
import logging
import os
import pathlib
import urllib.error
import urllib.request
from collections.abc import Callable, Generator, Mapping, Sequence
from enum import StrEnum
from pathlib import PurePath
from types import MappingProxyType
from typing import Any

import yaml
from google.api_core.exceptions import Forbidden as GcpForbiddenException
from google.cloud import storage

from rigging.config_discovery import list_cluster_configs, resolve_cluster_config
from rigging.filesystem.storage_path import StoragePath, split_gcs_path

logger = logging.getLogger(__name__)


def _bundled_cluster_config_dir() -> str | None:
    """Bundled cluster-config dir for an installed (wheel) rigging.

    Populated by the ``force-include`` in ``lib/rigging/pyproject.toml`` at
    ``rigging/clusters``. Returns ``None`` for a source/editable checkout, where
    the repo-root ``config/`` entry resolves against the marin workspace root.
    Mirrors ``iris.cli.connect._bundled_iris_config_dir``.

    This module lives at ``rigging/filesystem/cluster_config.py``, so the bundled
    ``rigging/clusters`` dir is two levels up from this file.
    """
    bundled = pathlib.Path(__file__).resolve().parent.parent / "clusters"
    return str(bundled) if bundled.is_dir() else None


# A per-user override dir for connecting to a live cluster (e.g. on a dev VM).
# Named so tests can filter it out of MARIN_CLUSTER_CONFIG_DIRS by identity
# rather than re-hardcoding the path, since it makes cluster-config resolution
# host-dependent: a document there may lack a `data:` block, silently swapping
# the loaded DataConfig out from under a test that expects the committed
# config/marin.yaml layout.
PER_USER_CLUSTER_CONFIG_DIR = "~/.config/marin/clusters"

# Cluster config search dirs, highest priority first: a per-user override, the
# repo-root ``config/`` directory (in-tree checkout), then the bundled copy for
# installed wheels. Relative paths resolve against the marin workspace root via
# :func:`rigging.config_discovery.resolve_cluster_config`.
MARIN_CLUSTER_CONFIG_DIRS: tuple[str, ...] = tuple(
    p
    for p in (
        PER_USER_CLUSTER_CONFIG_DIR,
        "config",
        _bundled_cluster_config_dir(),
    )
    if p is not None
)

_MARIN_PREFIX_ENV = "MARIN_PREFIX"
_MARIN_CLUSTER_ENV = "MARIN_CLUSTER"
_MARIN_TEMP_PREFIX_ENV = "MARIN_TEMP_PREFIX"
_GCP_METADATA_ZONE_URL = "http://metadata.google.internal/computeMetadata/v1/instance/zone"
_DEFAULT_LOCAL_PREFIX = "/tmp/marin"


class StoreType(StrEnum):
    """Object-storage backend serving a bucket.

    Distinguishes the two S3-compatible backends — which share the ``s3://``
    scheme but differ in endpoint, addressing, and credentials — from GCS.
    """

    GCS = "gcs"
    R2 = "r2"
    COREWEAVE = "coreweave"


@dataclasses.dataclass(frozen=True)
class BucketSpec:
    """A single data bucket: its name and which backend serves it.

    Attributes:
        name: Bucket name without scheme, e.g. ``marin-us-east1`` or ``marin-na``.
        store: Backend serving the bucket.
        signing_region: S3 signing region for backends that require one
            (CoreWeave, e.g. ``US-EAST-02A``). Distinct from the *placement*
            region (the ``region_buckets`` key). ``None`` for GCS (not S3) and R2
            (which signs with ``"auto"``).
    """

    name: str
    store: StoreType
    signing_region: str | None = None


@dataclasses.dataclass(frozen=True)
class StoreConfig:
    """Connection settings and shared scratch storage for one S3-compatible backend.

    Declared under ``data.stores`` in a cluster config so the connection details live
    beside the buckets they serve rather than as constants in code. Each environment
    variable named here, when set, overrides the config value — that is how a pod picks
    up its node-local endpoint, and how an operator points at a staging account.

    Attributes:
        endpoint: Default endpoint URL for the backend.
        endpoint_env: Variable overriding ``endpoint``.
        key_id_env: Variable holding the access key ID.
        key_secret_env: Variable holding the secret access key.
        temp_bucket: Shared lifecycle-managed scratch bucket for this backend.
            When absent, temporary paths stay in the source bucket.
        checkpoint_read_buckets: Additional scratch buckets to search when resuming checkpoints.
    """

    endpoint: str
    endpoint_env: str
    key_id_env: str
    key_secret_env: str
    temp_bucket: BucketSpec | None = None
    checkpoint_read_buckets: tuple[str, ...] = ()


@dataclasses.dataclass(frozen=True)
class DataConfig:
    """Where a cluster's data lives — the single source for storage layout.

    Attributes:
        region_buckets: Region name -> :class:`BucketSpec` for the cross-region
            mirror set.
        stores: Backend -> :class:`StoreConfig` for the S3-compatible backends this
            config's buckets are served by. GCS needs no entry: it authenticates with
            application default credentials and has one endpoint.
        scheme: URL scheme for the cluster's storage (e.g. ``"gs"`` or ``"s3"``).
        temp_path: Path segment for TTL-managed scratch data.
        ttl_days: Allowed TTL-day values for temp lifecycle rules.
        root: Explicit single-prefix root (e.g. ``"s3://marin-na/marin"``). Set
            only for clusters that do not use region-local bucket selection.
    """

    region_buckets: Mapping[str, BucketSpec]
    stores: Mapping[StoreType, StoreConfig] = dataclasses.field(default_factory=dict)
    scheme: str = "gs"
    temp_path: str = "tmp"
    ttl_days: tuple[int, ...] = (1, 2, 3, 4, 5, 6, 7, 14, 30)
    root: str | None = None

    @property
    def buckets(self) -> Mapping[str, BucketSpec]:
        """All data and scratch buckets, keyed by name."""
        buckets = {bucket.name: bucket for bucket in self.region_buckets.values()}
        for store in self.stores.values():
            if store.temp_bucket is not None:
                buckets[store.temp_bucket.name] = store.temp_bucket
        return buckets

    def resolved_root(self) -> str:
        """Resolve the storage root for this config. Never returns ``None``.

        Precedence: ``MARIN_PREFIX`` env > ``self.root`` > region-local bucket
        from ``region_buckets[<gcs metadata region>]`` > ``{scheme}://marin-{region}``
        for a detected-but-unmapped region > :data:`_DEFAULT_LOCAL_PREFIX`.

        The configured value is canonicalized so downstream joins do not duplicate
        separators. Relative local paths are anchored at the working directory.
        """
        env_prefix = os.environ.get(_MARIN_PREFIX_ENV)
        if env_prefix:
            return _canonical_root(env_prefix)
        if self.root is not None:
            return _canonical_root(self.root)
        region = region_from_metadata()
        if region is not None:
            spec = self.region_buckets.get(region)
            if spec is not None:
                return f"{self.scheme}://{spec.name}"
            return f"{self.scheme}://marin-{region}"
        return _DEFAULT_LOCAL_PREFIX


def _canonical_root(prefix: str) -> str:
    """Canonicalize a root and anchor relative local paths at the working directory."""
    path = StoragePath(prefix)
    if path.is_local and not path.rooted:
        return StoragePath.normalize(os.path.abspath(prefix))
    return str(path)


# The marin cluster's storage layout lives in ``config/marin.yaml`` (loaded as
# the default below). This in-code config is only a degraded fallback for when
# no config file is discoverable — e.g. an installed package running outside a
# marin checkout. Such contexts set ``MARIN_PREFIX`` (which wins in
# ``resolved_root``) or detect a region (constructing ``gs://marin-{region}``),
# so an empty ``region_buckets`` is sufficient.
_DEFAULT_CLUSTER = "marin"
_FALLBACK_DATA_CONFIG: DataConfig = DataConfig(region_buckets={})

_active_data_config: contextvars.ContextVar[DataConfig | None] = contextvars.ContextVar(
    "marin_data_config", default=None
)


def data_config() -> DataConfig:
    """Return the active :class:`DataConfig`.

    Resolution: the config bound by :func:`use_data_config` (a context-local
    override), else the cluster named by ``MARIN_CLUSTER`` (default ``marin``)
    loaded from its ``config/<cluster>.yaml``.
    """
    override = _active_data_config.get()
    if override is not None:
        return override
    return load_cluster_config()


@contextlib.contextmanager
def use_data_config(config: DataConfig) -> Generator[DataConfig, None, None]:
    """Bind *config* as the active :class:`DataConfig` for the duration of the block."""
    token = _active_data_config.set(config)
    try:
        yield config
    finally:
        _active_data_config.reset(token)


def load_cluster_config(cluster: str | None = None) -> DataConfig:
    """Load a cluster's :class:`DataConfig` from its ``config/<cluster>.yaml``.

    The cluster name is ``cluster`` arg > ``MARIN_CLUSTER`` env > ``marin``. A
    parsed ``data:`` block becomes the config; other keys (e.g. ``iris:``) are
    ignored. When the default ``marin`` config cannot be found (e.g. an installed
    package outside a checkout), returns :data:`_FALLBACK_DATA_CONFIG`; a missing
    *named* cluster raises ``FileNotFoundError``. Cached; call
    :func:`reset_data_config_cache` in tests after changing env or config files.
    """
    name = cluster or os.environ.get(_MARIN_CLUSTER_ENV) or _DEFAULT_CLUSTER
    return _load_cluster_config_cached(name)


def load_cluster_config_from_dirs(cluster: str, config_dirs: Sequence[pathlib.Path]) -> DataConfig:
    """Load a required data config from an explicit set of config directories.

    Unlike :func:`load_cluster_config`, this does not consult per-user overrides
    and does not fall back to an empty default when the file or ``data:`` block
    is absent. It is intended for reviewed infrastructure inputs.
    """
    config_path = resolve_cluster_config(cluster, config_dirs)
    config = _read_data_config(config_path)
    if config is None:
        raise ValueError(f"cluster config {config_path} has no `data:` section")
    return config


@functools.cache
def _load_cluster_config_cached(cluster: str) -> DataConfig:
    try:
        config_path = resolve_cluster_config(cluster, MARIN_CLUSTER_CONFIG_DIRS)
    except FileNotFoundError:
        if cluster == _DEFAULT_CLUSTER:
            return _FALLBACK_DATA_CONFIG
        raise
    return _read_data_config(config_path) or _FALLBACK_DATA_CONFIG


def _read_data_config(config_path: pathlib.Path) -> DataConfig | None:
    """Parse the file's data config, returning None when its `data:` block is empty."""
    with config_path.open("rb") as f:
        document = yaml.safe_load(f) or {}
    data = document.get("data")
    if not data:
        return None
    return _parse_data_config(data)


def _parse_bucket_spec(value: object) -> BucketSpec:
    """Normalize one ``region_buckets`` YAML entry into a :class:`BucketSpec`.

    Each entry is an explicit mapping ``{bucket, store[, signing_region]}``. The
    ``store`` (``gcs``/``r2``/``coreweave``) is required because it cannot be
    inferred — R2 and CoreWeave share the ``s3`` scheme but need different
    endpoints and credentials. CoreWeave entries must carry a ``signing_region``.
    """
    if not isinstance(value, Mapping):
        raise ValueError(
            f"region_buckets entry must be a mapping {{bucket, store[, signing_region]}}, "
            f"got {type(value).__name__}: {value!r}"
        )
    if "bucket" not in value or "store" not in value:
        raise ValueError(f"region_buckets entry must set 'bucket' and 'store': {value!r}")
    store = StoreType(str(value["store"]))
    signing_region = str(value["signing_region"]) if value.get("signing_region") is not None else None
    if store is StoreType.COREWEAVE and signing_region is None:
        raise ValueError(f"CoreWeave bucket {value['bucket']!r} must specify a 'signing_region'.")
    return BucketSpec(name=str(value["bucket"]), store=store, signing_region=signing_region)


def _parse_store_config(name: object, value: object) -> StoreConfig:
    """Normalize one ``data.stores`` YAML entry into a :class:`StoreConfig`.

    Endpoint and credential-variable fields are required so missing connection
    settings fail at config load. Shared scratch storage is optional.
    """
    required = ("endpoint", "endpoint_env", "key_id_env", "key_secret_env")
    if not isinstance(value, Mapping) or any(field not in value for field in required):
        raise ValueError(f"stores.{name} must be a mapping setting {', '.join(required)}: {value!r}")
    temp_bucket = _parse_bucket_spec(value["temp_bucket"]) if value.get("temp_bucket") is not None else None
    if temp_bucket is not None and temp_bucket.store != StoreType(str(name)):
        raise ValueError(f"stores.{name}.temp_bucket must use the same store: {value['temp_bucket']!r}")
    checkpoint_read_buckets = value.get("checkpoint_read_buckets", ())
    if not isinstance(checkpoint_read_buckets, (list, tuple)) or any(
        not isinstance(bucket, str) for bucket in checkpoint_read_buckets
    ):
        raise ValueError(f"stores.{name}.checkpoint_read_buckets must be a list of bucket names")
    return StoreConfig(
        **{field: str(value[field]) for field in required},
        temp_bucket=temp_bucket,
        checkpoint_read_buckets=tuple(checkpoint_read_buckets),
    )


def _parse_data_config(data: Mapping[str, object]) -> DataConfig:
    """Build a :class:`DataConfig` from a parsed ``data:`` config block.

    Keys absent from the block fall back to the :class:`DataConfig` field
    defaults, so per-field defaults are defined once on the dataclass.
    """
    temp = data.get("temp") or {}
    raw_ttl = temp.get("ttl_days")
    root = data.get("root")
    scheme = str(data.get("scheme") or DataConfig.scheme)
    raw_buckets = data.get("region_buckets") or {}
    region_buckets = {region: _parse_bucket_spec(value) for region, value in raw_buckets.items()}
    raw_stores = data.get("stores") or {}
    stores = {StoreType(str(name)): _parse_store_config(name, value) for name, value in raw_stores.items()}
    return DataConfig(
        region_buckets=region_buckets,
        stores=stores,
        scheme=scheme,
        temp_path=str(temp.get("path") or DataConfig.temp_path),
        ttl_days=tuple(raw_ttl) if raw_ttl is not None else DataConfig.ttl_days,
        root=str(root) if root is not None else None,
    )


def reset_data_config_cache() -> None:
    """Clear the cluster-config, region, and bucket-registry caches. For tests."""
    _load_cluster_config_cached.cache_clear()
    data_buckets.cache_clear()
    _region_from_metadata.cache_clear()
    s3_data_buckets.cache_clear()
    store_configs.cache_clear()


# ---------------------------------------------------------------------------
# Region + prefix resolution
# ---------------------------------------------------------------------------


@functools.cache
def _region_from_metadata() -> str | None:
    """Derive the GCP region from the instance metadata server, or ``None``."""
    try:
        req = urllib.request.Request(_GCP_METADATA_ZONE_URL, headers={"Metadata-Flavor": "Google"})
        with urllib.request.urlopen(req, timeout=2) as resp:
            zone = resp.read().decode().strip().split("/")[-1]
    except (urllib.error.URLError, OSError, TimeoutError, ValueError):
        return None
    if "-" not in zone:
        return None
    return zone.rsplit("-", 1)[0]


def region_from_metadata() -> str | None:
    """Derive the cached GCP region from the instance metadata server."""
    return _region_from_metadata()


def region_from_prefix(prefix: str) -> str | None:
    """Extract the canonical GCP region from a ``gs://marin-{region}/…`` prefix.

    Bucket names are normalized through the active config's ``region_buckets``
    (e.g. ``gs://marin-eu-west4`` -> ``europe-west4``); unknown ``marin-``
    buckets fall back to stripping the ``marin-`` prefix.
    """
    parsed = StoragePath.parse(prefix)
    if parsed.scheme != "gs" or not parsed.bucket:
        return None
    bucket = parsed.bucket
    for region, spec in data_config().region_buckets.items():
        if spec.name == bucket:
            return region
    if bucket.startswith("marin-"):
        return bucket[len("marin-") :]
    return None


def marin_region() -> str | None:
    """Return the current GCP region, from instance metadata or ``MARIN_PREFIX``."""
    return region_from_metadata() or region_from_prefix(os.environ.get(_MARIN_PREFIX_ENV, ""))


def marin_prefix() -> str:
    """Return the active cluster's storage prefix (``data_config().resolved_root()``)."""
    return data_config().resolved_root()


@functools.cache
def data_buckets() -> Mapping[str, BucketSpec]:
    """Every declared data bucket (name -> :class:`BucketSpec`) across all cluster configs.

    Recognition must be cross-cluster — a launcher on a GCS cluster may target an
    R2/CoreWeave output prefix (see :func:`marin_temp_bucket`'s ``source_prefix``),
    and a browser shows every backend at once — so this aggregates across all
    cluster configs rather than only the active one. The first config declaring a
    bucket name wins; a name declared twice with conflicting backends is a config
    error this does not police. Cached; :func:`reset_data_config_cache` clears it.
    """
    registry: dict[str, BucketSpec] = {}
    for cluster in list_cluster_configs(MARIN_CLUSTER_CONFIG_DIRS):
        for spec in load_cluster_config(cluster).buckets.values():
            registry.setdefault(spec.name, spec)
    return MappingProxyType(registry)


def require_regional_coreweave_bucket(uri: str, region: str) -> None:
    """Require a declared CoreWeave S3 bucket in the supplied execution region."""
    source = StoragePath(uri)
    if source.scheme != "s3":
        raise ValueError("Regional artifacts require CoreWeave S3")
    bucket = data_buckets()[source.bucket]
    if bucket.store is not StoreType.COREWEAVE or bucket.signing_region is None:
        raise ValueError("Regional artifacts require a declared CoreWeave bucket region")
    if bucket.signing_region.casefold() != region.casefold():
        raise ValueError("Stage the artifact in the execution region before use")


@functools.cache
def store_configs() -> Mapping[StoreType, StoreConfig]:
    """Every declared :class:`StoreConfig` across all cluster configs.

    Aggregated cross-cluster for the same reason as :func:`data_buckets`: reaching a
    CoreWeave bucket from a GCS cluster needs the CoreWeave backend's settings whether
    or not the active config declares them. The first config declaring a backend wins.
    Cached; :func:`reset_data_config_cache` clears it.
    """
    registry: dict[StoreType, StoreConfig] = {}
    for cluster in list_cluster_configs(MARIN_CLUSTER_CONFIG_DIRS):
        for store, config in load_cluster_config(cluster).stores.items():
            registry.setdefault(store, config)
    return MappingProxyType(registry)


def store_config(store: StoreType) -> StoreConfig:
    """The :class:`StoreConfig` for *store*.

    Raises:
        ValueError: if no cluster config declares *store* — including for
            ``StoreType.GCS``, which is reached through application default
            credentials and has no S3 connection settings.
    """
    config = store_configs().get(store)
    if config is None:
        raise ValueError(f"no cluster config declares a 'stores' entry for {store}")
    return config


@functools.cache
def s3_data_buckets() -> Mapping[str, BucketSpec]:
    """The R2/CoreWeave subset of :func:`data_buckets`.

    These S3-compatible buckets carry ``tmp/ttl=Nd/`` lifecycle rules and are
    used to route temp paths (:func:`marin_temp_bucket`). The set is defined in
    ``config/*.yaml`` via each bucket's ``store`` type (``r2``/``coreweave``).
    """
    return MappingProxyType(
        {name: spec for name, spec in data_buckets().items() if spec.store in (StoreType.R2, StoreType.COREWEAVE)}
    )


# ---------------------------------------------------------------------------
# Temp storage
# ---------------------------------------------------------------------------


def _s3_bucket_from_prefix(prefix: str | None) -> str | None:
    """Return the bucket from an ``s3://bucket/…`` prefix, or ``None``.

    Only recognizes buckets in :func:`s3_data_buckets` (the R2/CoreWeave buckets
    with lifecycle rules managed by ``infra/buckets``), so unknown
    S3 buckets fall through to the flat non-TTL fallback instead of getting a
    ``tmp/ttl=Nd/`` path that would never be cleaned up.
    """
    if not prefix:
        return None
    parsed = StoragePath.parse(prefix)
    if parsed.scheme != "s3":
        return None
    return parsed.bucket if parsed.bucket in s3_data_buckets() else None


def _append_path_prefix(path: str, prefix: str) -> str:
    if prefix:
        return f"{path}/{prefix.strip('/')}"
    return path


def _resolve_ttl_days(ttl_days: int, allowed: tuple[int, ...]) -> int:
    """Map *ttl_days* to the smallest *allowed* value that is ``>= ttl_days``.

    Requests above the largest allowed value clamp to that maximum (with
    a warning) — temp data is by definition disposable, so capping the TTL
    is preferable to forcing the caller to handle an exception. Logs a
    warning whenever the requested value is rounded.
    """
    if ttl_days <= 0:
        raise ValueError(f"ttl_days={ttl_days} must be positive. Allowed values: {allowed}.")
    if ttl_days in allowed:
        return ttl_days
    for n in allowed:
        if n > ttl_days:
            logger.warning("ttl_days=%d not configured; rounding up to %d", ttl_days, n)
            return n
    capped = max(allowed)
    logger.warning("ttl_days=%d exceeds the configured maximum; clamping to %d", ttl_days, capped)
    return capped


def marin_temp_bucket(
    ttl_days: int,
    prefix: str = "",
    *,
    source_prefix: str | None = None,
    temp_prefix: str | None = None,
) -> str:
    """Return a lifecycle-managed temporary path. Never returns ``None``.

    For a GCS marin prefix with a known region, or an explicitly provided
    ``source_prefix`` with a known region, returns a path under the
    region-local marin bucket::

        gs://marin-{region}/tmp/ttl={N}d/{prefix}

    For a known S3-compatible prefix, use its backend's configured shared
    scratch bucket, or the source bucket when none is configured::

        s3://{scratch_bucket}/tmp/ttl={N}d/{prefix}

    Otherwise falls back to a flat path under the marin prefix::

        {marin_prefix}/tmp/{prefix}

    Pulumi-managed lifecycle rules on every data bucket auto-delete objects
    under ``tmp/ttl=Nd/`` after *N* days.
    When ``MARIN_TEMP_PREFIX`` is set, it overrides ambient and explicit source
    prefixes. An explicit ``temp_prefix`` takes precedence over the environment.

    Args:
        ttl_days: Lifecycle TTL in days.  Values not in the active config's
            ``ttl_days`` are rounded up to the nearest configured value (with a
            warning); values above the maximum clamp to it.  Non-positive values
            raise :class:`ValueError`.
        prefix: Optional sub-path appended after the TTL directory.
        source_prefix: Optional path used to choose the temp bucket region.
            Useful when configuring a remote job from a launcher that may be in
            a different region than the job output path.
        temp_prefix: Explicit scratch destination, taking precedence over
            ``MARIN_TEMP_PREFIX`` and backend scratch routing.
    """
    cfg = data_config()
    ttl_days = _resolve_ttl_days(ttl_days, cfg.ttl_days)

    override_prefix = temp_prefix or os.environ.get(_MARIN_TEMP_PREFIX_ENV)
    mp = override_prefix or source_prefix or marin_prefix()

    # An explicit destination wins over cluster and backend defaults.
    # Otherwise source_prefix fully determines the backend and region, taking
    # precedence over the ambient marin prefix and VM metadata.
    if override_prefix is not None:
        region = region_from_prefix(override_prefix)
        s3_bucket = _s3_bucket_from_prefix(override_prefix)
    elif source_prefix is not None:
        region = region_from_prefix(source_prefix)
        s3_bucket = _s3_bucket_from_prefix(source_prefix)
    else:
        region = marin_region() if mp.startswith("gs://") else None
        s3_bucket = _s3_bucket_from_prefix(mp)

    if region:
        spec = cfg.region_buckets.get(region)
        if spec:
            path = f"gs://{spec.name}/{cfg.temp_path}/ttl={ttl_days}d"
            return _append_path_prefix(path, prefix)

    if s3_bucket:
        if override_prefix is None:
            store = store_configs().get(s3_data_buckets()[s3_bucket].store)
            if store is not None and store.temp_bucket is not None:
                s3_bucket = store.temp_bucket.name
        # Lifecycle rules match the bucket-root tmp/ prefix, outside marin/.
        path = f"s3://{s3_bucket}/{cfg.temp_path}/ttl={ttl_days}d"
        return _append_path_prefix(path, prefix)

    if "://" not in mp:
        mp = f"file://{mp}"
    path = f"{mp}/{cfg.temp_path}"
    return _append_path_prefix(path, prefix)


# ---------------------------------------------------------------------------
# GCS utilities
# ---------------------------------------------------------------------------


def get_bucket_location(bucket_name_or_path: str) -> str:
    """Return the GCS bucket's location (lower-cased region string)."""
    if bucket_name_or_path.startswith("gs://"):
        bucket_name = split_gcs_path(bucket_name_or_path)[0]
    else:
        bucket_name = bucket_name_or_path

    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    return bucket.location.lower()


def check_path_in_region(key: str, path: str, region: str, local_ok: bool = False) -> None:
    """Validate that a GCS path's bucket is in the expected region.

    Raises ``ValueError`` if the path is local (and ``local_ok`` is False)
    or if the bucket's region doesn't match *region*.  Logs a warning
    (instead of raising) when the bucket's region can't be checked due
    to permission errors.
    """

    if not path.startswith("gs://"):
        if local_ok:
            logger.warning(f"{key} is not a GCS path: {path}. This is fine if you're running locally.")
            return
        else:
            raise ValueError(f"{key} must be a GCS path, not {path}")
    try:
        bucket_region = get_bucket_location(path)
        if region.lower() != bucket_region.lower():
            raise ValueError(
                f"{key} is not in the same region ({bucket_region}) as the VM ({region}). "
                f"This can cause performance issues and billing surprises."
            )
    except GcpForbiddenException:
        logger.warning(f"Could not check region for {key}. Be sure it's in the same region as the VM.", exc_info=True)


def check_gcs_paths_same_region(
    obj: Any,
    *,
    local_ok: bool,
    region: str | None = None,
    skip_if_prefix_contains: Sequence[str] = ("train_urls", "validation_urls"),
    region_getter: Callable[[], str | None] | None = None,
    path_checker: Callable[[str, str, str, bool], None] | None = None,
) -> None:
    """Validate that ``gs://`` paths in ``obj`` live in the current VM region."""
    if region_getter is None:
        region_getter = marin_region
    if path_checker is None:
        path_checker = check_path_in_region

    if region is None:
        region = region_getter()
        if region is None:
            if local_ok:
                logger.warning("Could not determine the region of the VM. This is fine if you're running locally.")
                return
            raise ValueError("Could not determine the region of the VM. This is required for path checks.")

    for key, path in collect_gcs_paths(
        obj,
        path_prefix="",
        skip_if_prefix_contains=skip_if_prefix_contains,
    ):
        path_checker(key, path, region, local_ok)


def collect_gcs_paths(
    obj: Any,
    *,
    path_prefix: str = "",
    skip_if_prefix_contains: Sequence[str] = ("train_urls", "validation_urls"),
) -> list[tuple[str, str]]:
    """Collect ``(path_key, gs://...)`` entries found recursively in ``obj``."""
    paths: list[tuple[str, str]] = []
    _collect_gcs_paths_recursively(
        obj,
        path_prefix,
        skip_if_prefix_contains=tuple(skip_if_prefix_contains),
        out=paths,
    )
    return paths


def _collect_gcs_paths_recursively(
    obj: Any,
    path_prefix: str,
    *,
    skip_if_prefix_contains: tuple[str, ...],
    out: list[tuple[str, str]],
) -> None:
    if isinstance(obj, dict):
        for key, value in obj.items():
            new_prefix = f"{path_prefix}.{key}" if path_prefix else str(key)
            _collect_gcs_paths_recursively(
                value,
                new_prefix,
                skip_if_prefix_contains=skip_if_prefix_contains,
                out=out,
            )
        return

    if isinstance(obj, list | tuple | set):
        for index, item in enumerate(obj):
            new_prefix = f"{path_prefix}[{index}]"
            _collect_gcs_paths_recursively(
                item,
                new_prefix,
                skip_if_prefix_contains=skip_if_prefix_contains,
                out=out,
            )
        return

    if isinstance(obj, str | os.PathLike):
        path_str = _normalize_path_like(obj)
        if path_str.startswith("gs://"):
            if any(skip_token in path_prefix for skip_token in skip_if_prefix_contains):
                return
            out.append((path_prefix, path_str))
        return

    if dataclasses.is_dataclass(obj):
        for field in dataclasses.fields(obj):
            new_prefix = f"{path_prefix}.{field.name}" if path_prefix else field.name
            _collect_gcs_paths_recursively(
                getattr(obj, field.name),
                new_prefix,
                skip_if_prefix_contains=skip_if_prefix_contains,
                out=out,
            )
        return

    if not isinstance(obj, str | int | float | bool | type(None)):
        logger.warning(f"Found unexpected type {type(obj)} at {path_prefix}. Skipping.")


def _normalize_path_like(path: str | os.PathLike) -> str:
    if isinstance(path, os.PathLike):
        path_str = os.fspath(path)
        if isinstance(path, PurePath):
            parts = path.parts
            if parts and parts[0] == "gs:" and not path_str.startswith("gs://"):
                remainder = "/".join(parts[1:])
                return f"gs://{remainder}" if remainder else "gs://"
        return path_str
    return path
