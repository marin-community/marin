# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Pinned retrieval state for the licensed OpenResearcher data and pinned BM25 index."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from taskcompendium.identity import GIT_REVISION_PATTERN, SHA256_PATTERN
from taskcompendium.models import FunctionDefinition, ProviderRequirement

OPENRESEARCHER_ACTION_INTERFACE = "openresearcher-bm25:v1"


class OpenResearcherState(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    implementation_revision: str = Field(pattern=GIT_REVISION_PATTERN)
    corpus_revision: Literal["8367703babe6e080899a48782f365c284c32b668"]
    index_manifest_sha256: str = Field(pattern=SHA256_PATTERN)
    tokenizer_revision: str = Field(pattern=GIT_REVISION_PATTERN)
    top_k: Literal[5]
    snippet_max_tokens: Literal[512]
    include_get_document: Literal[True]


def openresearcher_state(requirement: ProviderRequirement) -> OpenResearcherState:
    if requirement.action_interface != OPENRESEARCHER_ACTION_INTERFACE:
        raise ValueError(f"Unsupported OpenResearcher interface: {requirement.action_interface}")
    return OpenResearcherState.model_validate(requirement.initial_state)


def openresearcher_tools(state: OpenResearcherState) -> tuple[FunctionDefinition, ...]:
    search = FunctionDefinition(
        name="search",
        description=f"Perform a search on a knowledge source. Returns top-{state.top_k} hits with docid, score, "
        "and snippet. The snippet contains the document's contents (may be truncated based on token limits).",
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
            "additionalProperties": False,
        },
    )
    if not state.include_get_document:
        return (search,)
    return (
        search,
        FunctionDefinition(
            name="get_document",
            description="Retrieve a full document by its docid.",
            parameters={
                "type": "object",
                "properties": {"docid": {"type": "string"}},
                "required": ["docid"],
                "additionalProperties": False,
            },
        ),
    )
