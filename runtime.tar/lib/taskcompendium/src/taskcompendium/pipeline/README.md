# Task curation library

This package turns the rows of one pinned source into TaskSpecs, reviews and
verifies them, and writes the filtered tasks with a manifest. The
[experiment](../../../../../experiments/post_training/task_curation/README.md)
owns the dataset declarations, the catalog and the ArtifactSteps; TaskCompendium
does not import experiments or construct ArtifactSteps.

## The recipe

`run_source_pipeline` consumes a `SourceRecipe` ([models.py](models.py)):

| Field | Meaning |
| --- | --- |
| `name`, `version` | Source name and converter revision, recorded on every row's `Source`. |
| `source` | `SourceFiles`: the staged dataset, revision, file patterns, format, and optional `select`, `decode` and `read` callables, or `parts` to produce each file's rows, of a known count, in parallel parts. |
| `convert` | `RawRow -> TaskSpec | NormalizedTask | ImportRejection`. The converter fixes the grader. |
| `rubric` | A `ReviewRubric` for model review, or `None` to skip review. |
| `controls` | `Controls(golden, memory_mb)` for grader verification, or `None` to skip it. |
| `intended_use` | `train` or `eval`. |
| `inputs` | Auxiliary staged inputs, passed by name to the source callables. |

Generic conversion techniques live in [convert/](../convert/): answer tasks
graded in process by verifyit, TaskTrove archive decoding, image-installed
source scorers, executable tasks and Nemotron Ultra row decoding. A converter
returns `NormalizedTask` when it records changes to the source (for example a
prompt rewrite), and `ImportRejection` with a stable reason code for rows it
cannot convert.

## Conversion without a recipe

Caller-owned ingestion supplies decoded `RawRow` values and source provenance to
[`convert_raw_row`](conversion.py), with a converter and `ConversionContext`.
The returned `ConvertedRow` values feed [`write_conversion`](source_processing.py)
on an entered `ZephyrContext`, which writes unreviewed `normalize/` shards and a
`manifest.json`, returning paths, row counts and rejections in `ConversionResult`.
Conversion executes lazily with writing: measure the executing call, and optionally
pass `PhaseTelemetry` to the writer to retain counters and the execution ID.

## Stages

[source_processing.py](source_processing.py) runs these stages; the
[telemetry](#telemetry) section lists the phase and Zephyr execution of each:

1. **Raw sample.** Read the staged files, record every row locator under
   `download/locators/`, and draw at most 100 raw rows. In sample mode, a source
   read in `parts` draws its row indices from the parts' row counts and produces
   only the drawn rows; its ledger has no `raw_input_sha256` for the others.
2. **Normalize and prepare.** Convert the sample and run cheap structural checks
   (`verify_task`): resource layout, answer-format compatibility, and
   reference/wrong-answer checks for in-process numeric, MCQ, exact and action
   graders. The driver deduplicates the checked panel and saves its review
   batches.
3. **Review.** With a rubric, the GLM reviewer judges the sample. These reviews
   are the only model reviews of the source: more than 50% known defects reject
   it, and otherwise it is accepted. The fraction uses the whole panel as the
   denominator; uncertain judgments, unsupported conversions and duplicate rows
   are not defects. Unavailable reviews leave the source `incomplete` only when
   they could still push the defects above 50%; a rerun resumes the same sample.
   Without a rubric, `skip_source_review` keeps every converted row with
   `quality_basis="unreviewed"` and rejects the source only when converter
   defects and failed checks exceed the rejection threshold.
4. **Full expansion.** In full mode an accepted source converts and audits every
   row. Unsampled rows of an accepted source use
   `quality_basis="inferred_from_source"`.
5. **Filter.** Rows are kept, rejected or deferred from quality evidence.
   Deferred rows (unavailable or malformed review) are excluded from `final/`
   and counted separately from defects; the manifest records them as
   `unavailable_reviews`. They make the source `incomplete` only when resolving
   them could change the quality decision.
6. **Verify.** With controls, [source_verification.py](source_verification.py)
   samples kept rows and grades one control submission per task through the
   same grading path rollouts use ([controls.py](controls.py)):
   - `golden(task)`, a known-correct `Reply`, `WorkspaceFiles` or
     `OracleCommand`, which must score 1;
   - otherwise, when the declaration has no `golden` or it returns `None`, an
     empty submission, which shows that the grader runs. A sandbox grader runs
     on it in a fresh machine of its image, with an empty answer file where it
     reads one, a conversation ending in an empty reply, and an empty
     workspace. The control passes when the grader scores it 0 or rejects it.
     A positive reward records a `defect`: an empty reply satisfies the task.
     The row is rejected with `check:empty`, and because the grader ran, the
     trial counts as checked and passed for the source.

   An `OracleCommand` runs with the task's worker and oracle resources in a
   fresh machine satisfying the agent's requirements. Empty agent requirements
   use the grader environment. Its output files, or the contents of `answer_file`, become the
   submission, which the grader then grades in its own environment. Graders
   that run outside the process get their machines from the campaign's
   `GradingMachines`, which selects a bubblewrap sandbox on the worker for
   `packages_lock` requirements and a sandbox of the pinned image for image
   requirements. Shared runtime preparation validates the selected machine and
   binds dependencies. Memory settings are advisory. Every grading machine has network
   access denied. Without controls the stage is skipped and sandbox graders
   stay unverified.

   A judge-graded source runs its declared positive or negative control through the campaign's
   explicit judge endpoint, outside the grader sandbox. Endpoint credentials are runtime-only and
   are not recorded in task specifications, artifact identities or reports. Judge sources without
   declared controls remain unverified.
7. **Admit and export.** Each row gets an `admission`:

   | Admission | Meaning |
   | --- | --- |
   | `admitted` | Kept, and the grader runs in process, is a verifyit judge, passed its controls, or is covered by a passing control sample. |
   | `rejected` | Rejected by conversion, checks, review or verification. |
   | `deferred` | Held back for unavailable review or inconclusive verification. |
   | `no_grader` | The converter found no runnable grader (`NoGrader`). |
   | `unverified` | A sandbox grader, other than a judge, without controls or a passing control sample. |

Output layout of one source:

```
download/      row locators of the staged source files
normalize/     every converted row (TaskSpec JSON, rejection reason, normalization changes)
review/        review and filter decisions, report.json, manifest.json
verify/        checks, grader readiness and admission per row, report.json, manifest.json
final/         admitted rows only
manifest.json  status, counts, quality and verification reports, admission summary
telemetry.json Zephyr execution IDs, counters and phase wall times
```

The manifest's `admission` field summarizes the source: `admitted` when any row
is admitted, otherwise `none`.

## Verification trials

Verification samples up to the configured sample size with seeded task-ID hashes
across all shards (the driver samples at most 20 tasks by default) and runs each
task's control in a fresh environment once per attempt (the driver makes one
attempt). An attempt
whose control hits an infrastructure error runs again, up to two more times,
before it is recorded. A task passes when its control passes or records a defect
on every attempt and no earlier trial failed; a task with both a pass and a
definite failure counts as inconsistent. The report's `counts.defective` records
the sampled tasks with a defect. When the pass fraction meets
`minimum_pass_fraction` (the driver uses 95%) and the sample is conclusive,
unsampled rows get `source_sampled` readiness. Otherwise controls run on every
remaining kept task; already sampled tasks are not rerun. The report records
`validated`, with counts and evidence covering all eligible tasks. Passed tasks
remain usable, failed and defective tasks are rejected, and unavailable controls
defer only their own task. An empty sample skips controls. The 95% threshold
controls this execution shortcut; it does not set the GLM quality grade.

Completed validation shards checkpoint their trial evidence before returning.
Reruns retain known individual failures even when a recovered sample permits the
shortcut. A source with no completed controls remains incomplete for retry.
The source manifest and `verify/report.json` contain counts and a `trial_report`
reference; full results are retained once in that report and in shard checkpoints.

A rerun of the same source artifact reuses the complete trials that its earlier
attempt saved. Trial identity covers the whole task, the controls code, the
machine backend and worker image, all TaskCompendium, VerifyIT and Shellbox
Python files, and the verification settings. QEMU reuse requires a
digest-pinned worker image carrying the bundle; network-enabled graders always
run fresh. Infrastructure errors rerun the whole trial; definite failures and
defects survive successful retries.

## Review execution

Full preparation uses one deduplication partition per 1,000 selected raw rows,
capped at 64, using the population count from raw sampling. Rows with the same
deduplication key stay together, and source locator order determines the
duplicate survivor. The driver prepares the panel the same way without a
shuffle. Prepared review batches are saved before inference. Batches respect both
`review_batch_size` and `review_input_bytes` (64 MiB by default); an oversized
audit is preserved alone. Review execution uses `review_task_resources`, so
several model requests can wait on one worker. Completed review shards are
reused when an audit resumes.

Inference uploads are limited to 64 requests and 4 MiB per provider batch; an
oversized single request is deferred with its size diagnostic. Transient HTTP
failures use bounded retries with backoff, and failed requests leave unavailable
review records that do not count as source defects. GLM completions use an
exact-request cache keyed by the complete request and the declared model
revision, read through FineStore, so unrelated catalog changes do not repeat
inference. The quality review reads the cache once for all of a source's sampled
requests.

GLM sees resource paths, roles, SHA-256 hashes, byte counts and UTF-8 previews.
Up to 256 files share 32,768 preview characters: each text file first receives up
to 100 characters, then earlier previews expand to at most 8,192 characters each.
Binary files retain signatures without text, and an aggregate hash covers
omitted files.

## Telemetry

Zephyr counters report review cache hits and misses, submitted requests and
bytes, request failures, review outcomes, check outcomes, control and trial
outcomes, admissions, and time spent in provider calls and grading.
`telemetry.json` keeps the final counter dictionaries of every execution and the
wall time of each phase. Join its execution IDs to Zephyr stage rows by
execution ID and emitting cluster/job; take the latest value per counter series
rather than summing snapshots, and do not add phase wall time to nested
execution times. Failed executions have no ID or final counters.

A source runs these phases in order:

| Phase | Work |
| --- | --- |
| `raw_sample` | One execution scans the staged files, writes the locators and draws the panel. A parted source in sample mode draws the panel by index on the driver, and the execution produces only the panel's rows. |
| `panel_normalize` | One execution decodes, converts and checks the panel rows. |
| `sample_prepare` | The driver deduplicates the panel and saves its review batches. |
| `quality_review` | With a rubric, the driver reads the review cache once and one execution reviews the sample; without one, the driver decides from conversion and check failures. |
| `full_prepare` | Full mode only: one execution converts, deduplicates and checks every row. |
| `audit_review` | One execution reuses the panel's reviews and applies the source decision to every other prepared row, without model requests. |
| `filter` | One execution writes the filtered audit and its kept rows. |
| `verification` | With controls, the executions of [source verification](#verification-trials). |
| `export` | One execution shuffles the checked rows by task ID into the normalized shards and writes the `normalize`, `review`, `verify` and `final` views, with the unprocessed review rows of an unexpanded sample. |

## Grading environments

A task's agent environment and its grader's environment are declared separately
in `EnvironmentRequirements`. A task may require `SHELL_SIMULATOR` while its grader
requires `LINUX_PROCESS` with an image or packages lock. Conversation-only tasks
need no command semantics. Missing packaging never implies simulation.

| Contract | Requirement |
| --- | --- |
| Built-in shell commands and virtual files preserve the requested behavior | Declare `SHELL_SIMULATOR` after checking command semantics, paths, quoting, pipes and file metadata. |
| Arbitrary Python packages, compiled binaries or image-specific dependencies | Declare `LINUX_PROCESS` with a pinned image or supported packages lock. |
| Kernel behavior, subprocesses, networking or special filesystem behavior | Check the specific Shellbox backend's support. |
| Grader has different dependencies from the task | Declare those dependencies in the grader's environment. |
| Rows within a source differ in runtime needs | Emit requirements for each row. |

Verification records evidence for the selected backend and image; a passing
sample on gVisor does not certify simulation. Runtime binding rejects unsupported
requirements before machine creation. This failure does not establish a source defect.

See the [task curation reference](../../../../../docs/references/task-curation.md)
for the output schema and the experiment's catalog and driver.
