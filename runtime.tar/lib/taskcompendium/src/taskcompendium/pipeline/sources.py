# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Decode records from pinned source files staged by an acquisition artifact."""

import csv
import hashlib
import json
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, replace
from fnmatch import fnmatchcase
from typing import Any
from urllib.parse import quote

from rigging.filesystem.factory import url_to_fs
from rigging.filesystem.storage_path import StoragePath
from zephyr.expr import col
from zephyr.input_file import InputFileSpec
from zephyr.readers import compute_parquet_splits, load_jsonl, load_parquet

from taskcompendium.pipeline.fingerprints import callable_identity
from taskcompendium.pipeline.inputs import ConversionContext, SourceFileOverride, SourceFiles, SourceFormat, StagedInputs
from taskcompendium.pipeline.models import SourceRecipe

PARQUET_SHARD_BYTES = 128 * 1024 * 1024
PREPARED_SHARD_ROWS = 256


def _binary_hash_identity(value: Any) -> dict[str, Any]:
    if isinstance(value, bytes):
        return {"binary_sha256": hashlib.sha256(value).hexdigest(), "size": len(value)}
    raise TypeError(f"Unsupported raw source value: {type(value).__name__}")


def canonical_source_json(data: dict[str, Any]) -> str:
    """Encode original source data, representing binary values by digest and size."""
    return json.dumps(
        data, default=_binary_hash_identity, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    )


def raw_input_sha256(data: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_source_json(data).encode()).hexdigest()


def prepared_parquet_directory(file: StoragePath) -> StoragePath:
    return file.parent / ".curation-parquet" / (file.name + ".parquet")


def prepared_manifest_path(file: StoragePath) -> StoragePath:
    return prepared_parquet_directory(file) / "manifest.json"


def prepared_component_path(file: StoragePath, component: str) -> StoragePath:
    return prepared_manifest_path(file).parent / (quote(component, safe="") + ".parquet")


def source_files_identity(spec: SourceFiles) -> dict[str, Any]:
    """Stable artifact identity for a staged reader and its selection rules."""
    return {
        "revision": "2",
        "dataset": spec.dataset,
        "source_revision": spec.revision,
        "patterns": spec.patterns,
        "format": spec.format.value,
        "select": callable_identity(spec.select) if spec.select is not None else None,
        "decode": callable_identity(spec.decode) if spec.decode is not None else None,
        "read": callable_identity(spec.read) if spec.read is not None else None,
        # Present only for parted sources, so whole-file sources keep their identities.
        **({"parts": callable_identity(spec.parts)} if spec.parts is not None else {}),
        **(
            {"prepared_component": spec.prepared_component, "prepared_source_revision": "3"}
            if spec.prepared_component is not None
            else {}
        ),
    }


def staged_inputs(paths: Mapping[str, str]) -> StagedInputs:
    """Resolve staged auxiliary input paths for the source callables."""
    return {name: StoragePath(path) for name, path in paths.items()}


def conversion_context(recipe: SourceRecipe) -> ConversionContext:
    """The staged inputs and grader image environment the recipe's source callables receive."""
    return ConversionContext(staged_inputs(recipe.inputs), recipe.grader_environment)


def staged_files(
    path: str, spec: SourceFiles, overrides: Mapping[str, SourceFileOverride] | None = None
) -> tuple[str, ...]:
    """List selected files by pinned relative path, rejecting missing declarations."""
    if overrides:
        for logical in overrides:
            if (
                logical.startswith("/")
                or ".." in logical.split("/")
                or not any(fnmatchcase(logical, pattern) for pattern in spec.patterns)
            ):
                raise ValueError(f"Local source filename {logical!r} does not match declaration {spec.patterns}")
        return tuple(sorted(overrides))
    root = StoragePath(path)
    _, root_path = url_to_fs(path)
    filesystem_root = StoragePath(root_path)
    files = set()
    for pattern in spec.patterns:
        for file in (root / pattern).glob():
            _, file_path = url_to_fs(str(file))
            relative = StoragePath(file_path).relative_to(filesystem_root)
            if not any(part.startswith(".") for part in relative.split("/")):
                files.add(relative)
    if not files:
        raise FileNotFoundError(f"No staged files match {spec.patterns} under {path}")
    return tuple(sorted(files))


def row_locator(file: str, index: int) -> str:
    """The stable locator of a staged file's row."""
    return f"{file}:{index}"


@dataclass(frozen=True)
class SourceShard:
    """One staged file, an indexed file part, or a native Parquet row range.

    ``indices`` restricts a part to those rows; ``None`` reads all of them.
    ``row_start`` and ``row_end`` bound native Parquet reads without renumbering rows.
    """

    file: str
    part: int
    parts: int
    indices: frozenset[int] | None
    row_start: int = 0
    row_end: int | None = None
    read_path: str | None = None
    prepared_path: str | None = None

    @property
    def name(self) -> str:
        """A name unique among the source's shards: the file, with its part when it has several."""
        return self.file if self.parts == 1 else f"{self.file}#part-{self.part}"


def source_shards(
    path: str, spec: SourceFiles, overrides: Mapping[str, SourceFileOverride] | None = None
) -> tuple[SourceShard, ...]:
    """The independently readable shards of the selected files, in file and part order."""
    parts = spec.parts.count if spec.parts is not None else 1
    if parts < 1:
        raise ValueError("A parted source requires at least one part")
    return tuple(
        SourceShard(file, part, parts, None, read_path=overrides[file].path if overrides else None)
        for file in staged_files(path, spec, overrides)
        for part in range(parts)
    )


def _decoded_rows(path: StoragePath, source_format: SourceFormat) -> Iterator[dict[str, Any]]:
    if source_format == SourceFormat.PARQUET:
        yield from load_parquet(str(path))
    elif source_format == SourceFormat.JSONL:
        yield from load_jsonl(str(path))
    elif source_format == SourceFormat.JSON:
        with path.open("rt") as stream:
            payload = json.load(stream)
        if not isinstance(payload, list):
            raise ValueError(f"Expected a JSON record array in {path}")
        yield from payload
    elif source_format == SourceFormat.CSV:
        with path.open("rt", encoding="utf-8-sig") as stream:
            yield from csv.DictReader(stream)
    else:
        raise ValueError(f"Unsupported staged source format: {source_format}")


def _indexed_rows(
    file: StoragePath, shard: SourceShard, spec: SourceFiles, context: ConversionContext
) -> Iterator[tuple[int, dict[str, Any]]]:
    if shard.prepared_path is not None:
        rows = load_parquet(
            InputFileSpec(
                path=shard.prepared_path,
                columns=["source_index", "raw_json"],
                row_start=shard.row_start,
                row_end=shard.row_end,
                filter_expr=col("component") == spec.prepared_component,
            )
        )
        return ((row["source_index"], json.loads(row["raw_json"])) for row in rows)
    if spec.parts is not None:
        return spec.parts(file, context, shard.part, shard.indices)
    assert shard.indices is None, "Only a parted source reads selected rows"
    if shard.row_start != 0 or shard.row_end is not None:
        assert spec.read is None and spec.format == SourceFormat.PARQUET, "Row bounds require a native Parquet reader"
        rows = load_parquet(InputFileSpec(path=str(file), row_start=shard.row_start, row_end=shard.row_end))
        return enumerate(rows, start=shard.row_start)
    return enumerate(spec.read(file, context) if spec.read is not None else _decoded_rows(file, spec.format))


def staged_raw_file_rows(
    path: str, shard: SourceShard, spec: SourceFiles, context: ConversionContext
) -> Iterator[dict[str, Any]]:
    """Yield one shard's selected source rows before decoding with their original stable locators."""
    relative_file = shard.file
    if relative_file.startswith("/") or ".." in relative_file.split("/"):
        raise ValueError(f"Source file must be relative to its staged root: {relative_file}")
    for index, row in _indexed_rows(
        StoragePath(shard.read_path) if shard.read_path is not None else StoragePath(path) / relative_file,
        shard,
        spec,
        context,
    ):
        if not isinstance(row, dict):
            raise ValueError(f"Expected an object at {relative_file}:{index}")
        if spec.select is not None and not spec.select(row, context):
            continue
        yield {"index": index, "locator": row_locator(relative_file, index), "data": row}


def decode_staged_row(record: dict[str, Any], spec: SourceFiles, context: ConversionContext) -> dict[str, Any]:
    """Apply a source decoder to an already selected row without changing its locator."""
    original_path = record.get("original_path", record["data"].get("path"))
    data = spec.decode(record["data"], context) if spec.decode is not None else record["data"]
    return {**record, "original_path": original_path, "data": data}


def staged_file_rows(
    path: str, shard: SourceShard, spec: SourceFiles, context: ConversionContext
) -> Iterator[dict[str, Any]]:
    """Yield one shard's selected, decoded records with their original file and row locators."""
    for record in staged_raw_file_rows(path, shard, spec, context):
        yield decode_staged_row(record, spec, context)


def conversion_shards(
    source_input: str,
    spec: SourceFiles,
    *,
    parquet_shard_bytes: int = PARQUET_SHARD_BYTES,
    overrides: Mapping[str, SourceFileOverride] | None = None,
) -> tuple[SourceShard, ...]:
    """Split native Parquet reads at row-group boundaries for mechanical conversion.

    Native row groups remain intact, so a single large group can exceed the byte target.
    Prepared components also bound rows per shard: small compressed math records
    can otherwise leave costly decoding and reference checks on one worker.
    Custom readers and explicitly partitioned sources retain their own shard definitions.
    """
    shards = source_shards(source_input, spec, overrides)
    if spec.prepared_component is not None:
        prepared = []
        for shard in shards:
            # Prepared files belong to the immutable acquisition artifact.
            # Overrides read their supplied files directly.
            if shard.read_path is not None:
                prepared.append(shard)
                continue
            file = StoragePath(source_input) / shard.file
            manifest = json.loads(prepared_manifest_path(file).read_text())
            if not manifest["components"].get(spec.prepared_component, 0):
                continue
            parquet = prepared_component_path(file, spec.prepared_component)
            ranges = compute_parquet_splits(
                str(parquet), parquet_shard_bytes, filter_expr=col("component") == spec.prepared_component
            )
            ranges = [
                (row_start, min(row_start + PREPARED_SHARD_ROWS, end))
                for start, end in ranges
                for row_start in range(start, end, PREPARED_SHARD_ROWS)
            ]
            prepared.extend(
                replace(shard, part=index, parts=len(ranges), prepared_path=str(parquet), row_start=start, row_end=end)
                for index, (start, end) in enumerate(ranges)
            )
        return tuple(prepared)
    if spec.format != SourceFormat.PARQUET or spec.read is not None or spec.parts is not None:
        return shards
    parts = []
    for shard in shards:
        ranges = compute_parquet_splits(
            shard.read_path or str(StoragePath(source_input) / shard.file), parquet_shard_bytes
        )
        parts.extend(
            replace(shard, part=index, parts=len(ranges), row_start=start, row_end=end)
            for index, (start, end) in enumerate(ranges)
        )
    return tuple(parts)
