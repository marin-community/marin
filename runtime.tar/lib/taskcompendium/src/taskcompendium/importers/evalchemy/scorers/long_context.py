# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Pinned scoring and selection policies for OpenAI MRCR and GraphWalks.

Adopted from Marin Evalchemy's pinned OpenAI dataset integrations. Preparation
and grading are pure; model-tokenizer eligibility belongs to the evaluation run.
"""

import re
from difflib import SequenceMatcher

from verifyit.grade import InvalidTask, Reward, scored

MRCR_BIN_UPPER_BOUNDS = (8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576)
MRCR_NEEDLE_COUNTS = (2, 4, 8)
GRAPHWALKS_CONTEXT_MARGIN = 64
GRAPHWALKS_PREFIX_TOKEN_MARGIN = 256
GRAPHWALKS_PREFIX_CHARS_PER_TOKEN = 8
GRAPHWALKS_MIN_OUTPUT_TOKENS = 4096
GRAPHWALKS_REASONING_RESERVE = 4096
GRAPHWALKS_OUTPUT_BUDGET_MULTIPLIER = 2
FINAL_ANSWER_PREFIX = "Final Answer:"


def mrcr_bin(total_tokens: int) -> int | None:
    """Map the official content-plus-answer token count into the published bins."""
    lower = 4096
    for upper in MRCR_BIN_UPPER_BOUNDS:
        if lower <= total_tokens <= upper:
            return upper
        lower = upper + 1
    return None


def grade_nonce_similarity(expected: str, nonce: str, response: str) -> Reward:
    if not isinstance(expected, str) or not isinstance(nonce, str) or not nonce:
        raise InvalidTask("MRCR requires text and a nonempty nonce")
    hit = response.startswith(nonce)
    score = SequenceMatcher(None, response.removeprefix(nonce), expected.removeprefix(nonce)).ratio() if hit else 0.0
    return scored(score, metrics={"accuracy": score, "prefix_hit_rate": float(hit)})


def graphwalks_answer(response: str) -> tuple[list[str], bool]:
    """Return final-line nodes and whether extraction failed; a parsed empty list succeeds."""
    line = response.rstrip().split("\n")[-1]
    if FINAL_ANSWER_PREFIX not in line:
        return [], True
    match = re.search(r"\[.*\]", line)
    if match is None:
        return [], True
    return [node.strip() for node in match.group(0).strip("[]").split(",") if node.strip()], False


def grade_graphwalks(expected: tuple[str, ...], response: str) -> Reward:
    if not isinstance(expected, tuple) or any(not isinstance(node, str) for node in expected):
        raise InvalidTask("GraphWalks requires reference node strings")
    extracted, extraction_failed = graphwalks_answer(response)
    predicted, truth = set(extracted), set(expected)
    if extraction_failed:
        precision = recall = f1 = 0.0
    elif not truth and not predicted:
        precision = recall = f1 = 1.0
    else:
        overlap = len(predicted & truth)
        recall = overlap / len(truth) if truth else 0.0
        precision = overlap / len(predicted) if predicted else 0.0
        f1 = 2 * recall * precision / (recall + precision) if recall + precision else 0.0
    return scored(
        f1,
        metrics={
            "f1": f1,
            "precision": precision,
            "recall": recall,
            "exact_match": float(predicted == truth and not extraction_failed),
        },
        model_answer=extracted,
        answer_extraction_errors=["failed_to_parse"] if extraction_failed else [],
    )
