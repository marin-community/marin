# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Reject a spec that no harness can run, before an attempt acquires resources."""

from collections.abc import Mapping

from shellbox.machine import MachineFactory, NetworkPolicy
from taskcompendium.models import (
    CONVERSATION_ANSWERS,
    EXECUTION_RESOURCE_FIELDS,
    AnswerType,
    CommandSemantics,
    EnvironmentRequirements,
    NoGrader,
    ProviderNetworkAccess,
    ScriptGrader,
    TaskSpec,
    VerifyitGrader,
    grades_with_judge,
    require_resolved_environment,
)
from taskcompendium.runtime.environment import validate_machine_spec
from taskcompendium.runtime.integrity import require_integrity_contract

from rolloutengine.grading import judge_connection
from rolloutengine.machines import _machine_spec
from rolloutengine.models import TaskRolloutSpec

WORKSPACE_ANSWERS = frozenset({AnswerType.FILE, AnswerType.STATE, AnswerType.WORKSPACE_STATE})


def task_machine_reason(task: TaskSpec) -> str | None:
    """Why ``task`` runs only with a task machine, or ``None`` when it runs without one.

    Tool providers run on the host, so they do not need a machine. A workspace answer needs one only
    when the engine grades it: nothing reads a ``NoGrader`` task's workspace.
    """
    grader = task.grader
    if task.environment_requirements.model_copy(update={"tool_providers": {}}) != EnvironmentRequirements():
        return "Environment requirements need a selected machine"
    if task.resources.all + task.resources.worker:
        return "Task resources require a task machine"
    if task.tool_bindings:
        return "A shell binding requires a task machine"
    if task.output_paths:
        return "Output paths require a task machine"
    if not isinstance(grader, NoGrader) and task.answer_type in WORKSPACE_ANSWERS:
        return "Workspace tasks require a task machine"
    if isinstance(grader, ScriptGrader) and (grader.collect or grader.artifacts):
        return "Artifact grading requires a task machine"
    return None


def validate_spec(spec: TaskRolloutSpec, machine_factories: Mapping[str, MachineFactory]) -> None:
    """Check the machine selections against the task's environments, resources, and grader."""
    task = spec.task
    require_integrity_contract(task)
    if any(
        requirement.network_access is ProviderNetworkAccess.SERVICE_ONLY
        for requirement in task.environment_requirements.tool_providers.values()
    ):
        if spec.task_machine is not None and spec.task_machine.network is not NetworkPolicy.DENY:
            raise ValueError("Service-only task tools require a network-denied actor and a private relay")
    for runtime, declared in (
        (spec.task_machine, task.execution_requirements),
        (spec.verifier_machine, task.verifier_execution_requirements),
    ):
        if (
            runtime is not None
            and declared is not None
            and any((getattr(runtime, name) or 0) < getattr(declared, name) for name in EXECUTION_RESOURCE_FIELDS)
        ):
            raise ValueError("Selected machine is smaller than the task's declared allocation")
    if task.execution_requirements is not None and (
        spec.limits.total_turn_timeout is None
        or spec.limits.total_turn_timeout > task.execution_requirements.agent_timeout_sec
    ):
        raise ValueError("Rollout actor limit must honor the task's declared deadline")
    grader = task.grader
    judge = grades_with_judge(grader)
    host_judge = judge and isinstance(grader, VerifyitGrader)
    grader_environment = (
        grader.environment if isinstance(grader, VerifyitGrader | ScriptGrader) and not host_judge else None
    )
    if judge:
        judge_connection(spec)
        if task.answer_type not in CONVERSATION_ANSWERS:
            raise NotImplementedError(f"The engine grades a judge only on a conversation answer, not {task.answer_type}")
    if task.answer_type == AnswerType.STATE and not isinstance(grader, NoGrader):
        raise NotImplementedError("The engine does not capture a state answer, so it cannot grade one")
    require_resolved_environment(task.environment_requirements)
    if grader_environment is not None:
        require_resolved_environment(grader_environment)
    if grader_environment is not None and spec.verifier_machine is None:
        raise ValueError("A grader with an environment requires a verifier machine")
    if grader_environment is None and spec.verifier_machine is not None:
        raise ValueError("The task's grader does not use a verifier machine")
    task_resources = task.resources.all + task.resources.worker
    selections = [(spec.task_machine, task.environment_requirements, task_resources)]
    if grader_environment is not None:
        selections.append((spec.verifier_machine, grader_environment, task_resources + task.resources.verifier))
    for selection, requirements, resources in selections:
        if selection is None:
            continue
        if selection.backend not in machine_factories:
            raise ValueError(f"Unknown Shellbox factory: {selection.backend!r}")
        validate_machine_spec(requirements, machine_factories[selection.backend], _machine_spec(requirements, selection))
        if requirements.command_semantics == CommandSemantics.SHELL_SIMULATOR and any(
            resource.mtime_ns is not None for resource in resources
        ):
            raise NotImplementedError("The built-in filesystem cannot preserve resource timestamps")
    if spec.task_machine is None and (reason := task_machine_reason(task)) is not None:
        raise ValueError(reason)
