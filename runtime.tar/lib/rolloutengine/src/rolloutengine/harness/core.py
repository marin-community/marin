# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""The harness contract: the agent loop of one task attempt, and its session with the model.

A harness runs the loop: it sends prompts, runs tools, and decides when the attempt ends. It calls the model
through its ``ModelSession``, which records the exact tokens and applies the turn and token limits.
The harness does not grade: the engine grades the rollout with the task's grader after the harness ends.
"""

from collections.abc import Callable, Coroutine, Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from shellbox.machine import Machine
from taskcompendium.models import TaskSpec

from rolloutengine.models import ContextRecovery, EventSink, ModelTurn, Prompt, RolloutLimits

OUTPUT_LIMIT_OPTION_KEYS = ("max_tokens", "max_completion_tokens", "max_output_tokens")


def reply_options_match(previous: dict[str, Any], current: dict[str, Any]) -> bool:
    """Check whether the model options can belong to the same conversation."""
    return {key: value for key, value in previous.items() if key not in OUTPUT_LIMIT_OPTION_KEYS} == {
        key: value for key, value in current.items() if key not in OUTPUT_LIMIT_OPTION_KEYS
    }


class HarnessCleanup(Protocol):
    """The attempt's cleanup scope: it closes resources after the record is committed and graded."""

    def push(self, name: str, close: Callable[[], Coroutine[Any, Any, None]]) -> None:
        """Run ``close`` when the attempt ends, within ``RolloutLimits.cleanup_timeout``.

        A failure does not change the recorded turns or the grade. ``Rollout.metrics`` counts it, and
        ``run_task`` also adds it to the grade diagnostics.
        """
        ...


@dataclass(frozen=True)
class HarnessContext:
    """One attempt's inputs for a harness.

    ``limits`` are the attempt's limits, for example to tell the model that one turn is left. ``machine`` is
    the prepared task machine, or ``None`` when the attempt has none. A harness may report its own events,
    such as tool calls, to ``events``, and registers the close of its resources with ``cleanup``. ``run_id``
    identifies the attempt.
    """

    task: TaskSpec
    limits: RolloutLimits
    machine: Machine | None
    events: EventSink
    cleanup: HarnessCleanup
    run_id: str


class ModelSession(Protocol):
    """One attempt's session with the model. It records the exact tokens of each turn and applies the limits.

    One request can be open at a time. A request that is cancelled while the model generates changes
    nothing, so the harness can send it again. If the harness ends before its next request, the record
    keeps the cancelled request without an answer. When a limit ends the attempt, the next ``start`` or
    ``reply`` raises ``LimitReached``, and the harness lets it propagate. A failed model request raises
    ``RolloutEnded`` with the model's error as its cause. ``ContextWindowExceeded`` rejects only the
    current request; a harness can shorten its observations or compact and retry under the same limits.
    A harness that catches a refusal and asks again
    runs until a turn or attempt deadline. Each request after the end of the attempt yields before it
    raises, so a harness that asks again in a loop does not stop other attempts.
    """

    async def start(self, prompt: Prompt) -> ModelTurn:
        """Start a new conversation with ``prompt`` and return the model's turn.

        A later ``start`` replaces the chat, for example after the harness makes its history shorter or
        changes its tools. The rollout keeps the earlier conversations.
        """
        ...

    async def reply(
        self,
        observations: tuple[dict[str, Any], ...],
        *,
        token_ids: tuple[int, ...] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ModelTurn:
        """Send ``observations`` after the model's last message, and return the next turn.

        ``token_ids`` pins the exact tokens of the next prompt. They must start with the tokens served so far:
        under ``TraceMode.EXACT_TOKENS``, other tokens break the token contract before the request is sent.
        ``options`` supplies the full options for the request. Only the output limits may change.
        """
        ...

    def record(
        self,
        *,
        observations: tuple[dict[str, Any], ...] = (),
        data: object = None,
        metrics: Mapping[str, Any] | None = None,
    ) -> None:
        """Add to the step of the last turn: observations that the model never receives, data, and metrics.

        ``data`` is for the trainer, for example a reward, and the engine does not read it. A turn with
        recorded observations ends the conversation's turns: ``reply`` refuses it. After ``LimitReached`` or a
        failed model request, the harness can still add data and metrics, for example a final reward, to the
        step of the last turn until the record is final. If no turn exists, ``record`` raises the refusal again.
        """
        ...


class Harness(Protocol):
    """The agent loop for a task: what the model sees, which tools run, and when the attempt ends."""

    @property
    def context_recovery(self) -> ContextRecovery:
        """When the session lets this harness recover from a context rejection during an attempt."""
        ...

    def check(self, task: TaskSpec, limits: RolloutLimits) -> None:
        """Raise an error if this harness cannot run ``task`` under ``limits``, before any machine starts."""
        ...

    async def run(self, context: HarnessContext, session: ModelSession) -> None:
        """Run one attempt. Return when the task is done, and let ``RolloutEnded`` and ``LimitReached`` propagate."""
        ...
