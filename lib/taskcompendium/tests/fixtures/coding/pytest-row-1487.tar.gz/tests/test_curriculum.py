import struct
import pytest

# Import the target module as per the project's packaging
from imx import img
from imx.img import CmdWriteData, CmdNop, EnumWriteOps


def test_cmd_write_data_single_entry_roundtrip():
    # Create with data; ops should default to WRITE_VALUE when data is provided
    cmd = CmdWriteData(data=[(0x10, 0x1234)])
    assert cmd.ops == EnumWriteOps.WRITE_VALUE
    assert len(cmd) == 1
    assert cmd[0] == [0x10, 0x1234]

    # Export to bytes and check length and encoding
    exported = cmd.export()
    assert len(exported) == 4 + 8  # 4 for op code, 8 for one entry

    op_code = struct.unpack("<I", exported[0:4])[0]
    assert op_code == EnumWriteOps.WRITE_VALUE.value

    addr, val = struct.unpack("<II", exported[4:12])
    assert addr == 0x10
    assert val == 0x1234

    # Round-trip parse
    parsed = CmdWriteData.parse(exported)
    assert parsed == cmd


def test_cmd_write_data_append_and_get():
    cmd = CmdWriteData()
    cmd.append(0, 100)
    assert len(cmd) == 1
    assert cmd[0] == [0, 100]

    exported = cmd.export()
    assert len(exported) == 12  # 4 (op) + 8 (one entry)

    parsed = CmdWriteData.parse(exported)
    assert parsed == cmd


def test_cmd_nop_roundtrip():
    nop = CmdNop(param=255)
    assert nop.size == 4

    exported = nop.export()
    assert len(exported) == 4

    parsed = CmdNop.parse(exported)
    assert parsed == nop


def test_cmd_write_data_two_entries_roundtrip():
    cmd = CmdWriteData(data=[(1, 2), (3, 4)])
    exported = cmd.export()
    assert len(exported) == 4 + 8 * 2  # 4 + 16 = 20

    parsed = CmdWriteData.parse(exported)
    assert parsed == cmd


def test_cmd_equality_with_different_type():
    cmd = CmdWriteData(data=[(0, 1)])
    # Ensure equality comparison with a different type returns False (or NotImplemented)
    assert not (cmd == 123)
    class Dummy:
        pass
    assert not (cmd == Dummy())