# Easy rewrite: simplified imx imaging commands module

Goal
- Create a small, easy-to-understand Python package under /app/imx that exposes an imx.img API used by tests.
- Package layout (preferred): /app/imx with __init__.py and img.py
- Import style: tests will use from imx import img, so ensure __init__.py exposes the submodule.

What to implement (easy scope)
- Package layout (preferred)
  - /app/imx/
    - __init__.py
    - img.py

- Public API (simplified)
  - Enums (all in imx.img)
    - EnumWriteOps
      - WRITE_VALUE
    - EnumItm
      - ENG
    - EnumEngine
      - ANY
  - Command classes (all in imx.img)
    - CmdWriteData
      - __init__(self, data=None, ops=None)
        - If data is provided, it should be a sequence of (address, value) pairs.
        - If ops is None and data is provided, set ops to EnumWriteOps.WRITE_VALUE.
      - append(self, address: int, value: int)  # for entries
      - __len__(self) -> int  # number of entries
      - __getitem__(self, idx) -> list[int]
      - bytes property: should return 4
      - ops property: one of EnumWriteOps
      - export(self) -> bytes
        - Deterministic encoding suitable for tests:
          - First 4 bytes: op code (EnumWriteOps value)
          - For each entry, append 8 bytes: 4-byte address, 4-byte value
          - Total length: 4 + 8 * number_of_entries
      - parse(cls, data: bytes) -> CmdWriteData
        - Reconstruct the object from the bytes produced by export.
      - __eq__(self, other) -> bool
    - CmdNop
      - __init__(self, param: int)
      - size property: 4
      - export(self) -> bytes
      - parse(cls, data: bytes) -> CmdNop
      - __eq__
  - Note: This easy version focuses on CmdWriteData and CmdNop to get you started quickly. The skeleton is designed so you can later extend with additional command classes if desired.

3) Behavior guarantees (easy)
- All implemented classes should implement __eq__ to compare type and relevant fields.
- export/parse should be mutually compatible: parse(export(obj)) yields an equal object.
- Tests that check export length for CmdWriteData and CmdNop (e.g., 12 for 1 entry, 20 for 2 entries, 4 for CmdNop) should pass with the encoding described above.

4) Implementation notes (hints)
- Use Python’s enum.Enum for the enumerations.
- Use a simple deterministic binary encoding:
  - 4-byte little-endian integers for all fields
  - Use struct.pack/unpack with format "<I" for 4-byte unsigned int
- For CmdWriteData:
  - If there are N entries, export length = 4 + 8*N
  - The first 4 bytes represent the operation code value of EnumWriteOps.WRITE_VALUE
  - Each entry is 8 bytes: 4-byte address, 4-byte value
- For CmdNop:
  - export should be exactly 4 bytes (the single param encoded as a 4-byte int)
- Packaging
  - Place the implementation under /app/ as a package:
    - /app/imx/__init__.py should expose the module named img (e.g., from . import img)
    - /app/imx/img.py contains the enums and command classes

5) Skeleton to start with (optional starter)
- If you’d like, you can begin with a minimal skeleton that defines:
  - EnumWriteOps with WRITE_VALUE
  - EnumItm with ENG
  - EnumEngine with ANY
  - CmdWriteData with method stubs (pass) and docstrings
  - CmdNop with method stubs (pass) and docstrings
- Then progressively implement the methods above:
  - __init__, append, __len__, __getitem__
  - export, parse, __eq__, properties (bytes, ops, size)

6) Acceptance criteria (easy)
- CmdWriteData implemented with:
  - __init__ handling data and ops as described
  - append, __len__, __getitem__
  - bytes property returns 4
  - ops property set to EnumWriteOps.WRITE_VALUE when data is provided without ops
  - export yields 4 + 8*N bytes
  - parse(export(obj)) yields an equal object
  - __eq__ compares type and entries
- CmdNop implemented with:
  - __init__(param)
  - size == 4
  - export, parse, __eq__
- __init__.py exposes img so tests importing from imx import img work
- All implemented parts are deterministic and test-friendly

Implementation location reminder
- The code should live under /app/ as a package (preferred) with /app/imx/__init__.py and /app/imx/img.py. If you choose a single-file approach, adapt the same API accordingly under /app/.

Notes
- The simplified task prioritizes getting a small, well-defined API working quickly.
- You can extend the API later with the remaining command classes and more enums if desired.