import os
import math
import pytest

import deepchem as dc


def test_adam_optimizer_basic_store():
    opt = dc.models.optimizers.Adam(learning_rate=0.01)
    # basic attributes should be stored and accessible
    assert isinstance(opt, dc.models.optimizers.Adam)
    assert hasattr(opt, "learning_rate")
    assert opt.learning_rate == 0.01


def test_metalearner_base_interface_minimal():
    class DummyLearner(dc.metalearning.MetaLearner):
        def __init__(self):
            self._vars = {"w": 1.0}

        @property
        def variables(self):
            return self._vars

        def compute_model(self, inputs, variables, training):
            # simple, deterministic output
            x = inputs if isinstance(inputs, list) else [inputs]
            outputs = [0.0 for _ in x]
            loss = 0.0
            return (loss, outputs)

        def select_task(self):
            # optional method; no-op
            pass

        def get_batch(self):
            # optional; not used in this test
            return [1.0]

    learner = DummyLearner()
    # ensure the API surface exists
    assert isinstance(learner, dc.metalearning.MetaLearner)
    batch = learner.get_batch()
    loss, outputs = learner.compute_model(inputs=batch, variables=learner.variables, training=False)
    assert isinstance(loss, float)
    assert isinstance(outputs, list)


def test_maml_predict_and_restore_reproducible(tmp_path):
    class SineLearner(dc.metalearning.MetaLearner):
        def __init__(self):
            self._vars = {}

        @property
        def variables(self):
            return self._vars

        def compute_model(self, inputs, variables, training):
            # Expect inputs as (x_list, target_list); if not provided, handle gracefully
            if isinstance(inputs, tuple) and len(inputs) == 2:
                x, t = inputs
            else:
                x = inputs
                t = None

            # deterministic outputs: sin(x)
            outputs = [math.sin(v) for v in x]

            if t is not None:
                loss = sum((outputs[i] - t[i]) ** 2 for i in range(len(x)))
            else:
                loss = 0.0
            return (loss, outputs)

        def get_batch(self):
            x = [0.0, 1.0, 2.0]
            t = [0.0, math.sin(1.0), math.sin(2.0)]
            return (x, t)

    model_dir = str(tmp_path / "dc_maml_cache")
    learner = SineLearner()
    adam = dc.models.optimizers.Adam(learning_rate=0.001)
    maml1 = dc.metalearning.MAML(learner, meta_batch_size=4, optimizer=adam, model_dir=model_dir)
    maml1.fit(steps=1)

    batch = learner.get_batch()
    loss1, outputs1 = maml1.predict_on_batch(batch)

    # Create a new MAML instance with the same model_dir and restore
    learner2 = SineLearner()
    maml2 = dc.metalearning.MAML(learner2, meta_batch_size=4, optimizer=None, model_dir=model_dir)
    maml2.restore()
    loss2, outputs2 = maml2.predict_on_batch(batch)

    assert loss1 == pytest.approx(loss2)
    assert len(outputs1) == len(outputs2)
    for a, b in zip(outputs1, outputs2):
        assert a == pytest.approx(b)