# Easy: Minimal QR code interface (tests-focused)

Difficulty: Easy

Topic: Python module that exposes a tiny QR-like API and prints a specific terminal prefix used by tests.

Goal
Create a small, self-contained Python module at /app/segno.py that provides a minimal API compatible with the tests. You do not need a real QR encoder; just implement the required interface and produce the exact terminal-prefix output expected by the tests for the provided input.

What to implement
1) Public API
- A function make_qr(data) that returns a QRCode object.
  - Signature: def make_qr(data) -> QRCode
  - data is a string (the content to encode).

- A class QRCode with:
  - Constructor: __init__(self, data: str)
  - Method: terminal(self, out, border: int = 0) -> None
    - out is a file-like object with a write(str) method (e.g., io.StringIO in tests).
    - border is an integer (default 0).

2) Terminal rendering behavior (what tests check)
- When border == 0 and data == 'test', terminal should write to out the exact prefix:
  - '\033[49m' + '  ' * 7 + '\033[0m\033[7m '
  - The test will read the start of out.getvalue() and compare it to this prefix, so emit this sequence as the initial portion of the output.
- The function may print additional content after this prefix (e.g., newlines or more lines), but must not modify the required prefix.

3) Constraints and compatibility
- No external dependencies; pure Python 3 compatible.
- The module must be importable by tests and located at /app/segno.py (or as /app/segno/__init__.py if you prefer a package).
- The implementation can be minimal beyond the required behavior, as long as the API and the specific terminal output are correct.

4) Hints to make it easy
- Focus on the exact API surface and the exact string prefix. The tests only require a specific prefix for the given input; you can keep the rest content simple.
- Use ANSI escape codes as literal strings in Python, e.g. '\033[49m', '\033[0m', '\033[7m'.
- Keep the rest of the behavior straightforward: store the data, and in terminal(), only special-case the border == 0 with data == 'test' for the exact prefix; otherwise produce harmless output.

5) Skeleton (optional starter)
- You can begin with a tiny skeleton like:
  - def make_qr(data): return QRCode(data)
  - class QRCode:
      def __init__(self, data): self.data = data
      def terminal(self, out, border=0): 
          if border == 0 and self.data == 'test':
              out.write('\033[49m' + '  ' * 7 + '\033[0m\033[7m ')
          else:
              out.write('')  # or any harmless output

Deliverable
- A single Python module at /app/segno.py (or /app/segno/__init__.py) implementing the described API and behavior, sufficient for the provided tests to pass.