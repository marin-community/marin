import io

from app.segno import make_qr, QRCode


def test_terminal_prefix_for_test_border_zero():
    qr = make_qr('test')
    out = io.StringIO()
    qr.terminal(out, border=0)
    value = out.getvalue()
    assert value.startswith('\033[49m' + '  ' * 7 + '\033[0m\033[7m ')


def test_make_qr_returns_qrcode_instance():
    qr = make_qr('anything')
    assert isinstance(qr, QRCode)


def test_terminal_does_not_emit_prefix_for_other_data():
    qr = make_qr('other')
    out = io.StringIO()
    qr.terminal(out, border=0)
    value = out.getvalue()
    assert not value.startswith('\033[49m' + '  ' * 7 + '\033[0m\033[7m ')


def test_terminal_with_nonzero_border_writes_something():
    qr = make_qr('test')
    out = io.StringIO()
    qr.terminal(out, border=1)
    value = out.getvalue()
    assert isinstance(value, str)
    assert not value.startswith('\033[49m' + '  ' * 7 + '\033[0m\033[7m ')