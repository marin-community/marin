This is an interactive problem.

To prevent the mischievous rabbits from freely roaming around the zoo, Zookeeper has set up a special lock for the rabbit enclosure. This lock is called the Rotary Laser Lock.

The lock consists of $$$n$$$ concentric rings numbered from $$$0$$$ to $$$n-1$$$. The innermost ring is ring $$$0$$$ and the outermost ring is ring $$$n-1$$$. All rings are split equally into $$$nm$$$ sections each. Each of those rings contains a single metal arc that covers exactly $$$m$$$ contiguous sections. At the center of the ring is a core and surrounding the entire lock are $$$nm$$$ receivers aligned to the $$$nm$$$ sections.

The core has $$$nm$$$ lasers that shine outward from the center, one for each section. The lasers can be blocked by any of the arcs. A display on the outside of the lock shows how many lasers hit the outer receivers.

In the example above, there are $$$n=3$$$ rings, each covering $$$m=4$$$ sections. The arcs are colored in green (ring $$$0$$$), purple (ring $$$1$$$), and blue (ring $$$2$$$) while the lasers beams are shown in red. There are $$$nm=12$$$ sections and $$$3$$$ of the lasers are not blocked by any arc, thus the display will show $$$3$$$ in this case.

Wabbit is trying to open the lock to free the rabbits, but the lock is completely opaque, and he cannot see where any of the arcs are. Given the relative positions of the arcs, Wabbit can open the lock on his own.

To be precise, Wabbit needs $$$n-1$$$ integers $$$p_1,p_2,\ldots,p_{n-1}$$$ satisfying $$$0 \leq p_i < nm$$$ such that for each $$$i$$$ $$$(1 \leq i < n)$$$, Wabbit can rotate ring $$$0$$$ clockwise exactly $$$p_i$$$ times such that the sections that ring $$$0$$$ covers perfectly aligns with the sections that ring $$$i$$$ covers. In the example above, the relative positions are $$$p_1 = 1$$$ and $$$p_2 = 7$$$.

To operate the lock, he can pick any of the $$$n$$$ rings and rotate them by $$$1$$$ section either clockwise or anti-clockwise. You will see the number on the display after every rotation.

Because his paws are small, Wabbit has asked you to help him to find the relative positions of the arcs after all of your rotations are completed. You may perform up to $$$15000$$$ rotations before Wabbit gets impatient.

Note: For the first test, the configuration is the same as shown on the picture from the statement.

After the first rotation (which is rotating ring $$$0$$$ clockwise by $$$1$$$ section), we obtain the following configuration:

After the second rotation (which is rotating ring $$$2$$$ counter-clockwise by $$$1$$$ section), we obtain the following configuration:

After the third rotation (which is rotating ring $$$1$$$ clockwise by $$$1$$$ section), we obtain the following configuration:

If we rotate ring $$$0$$$ clockwise once, we can see that the sections ring $$$0$$$ covers will be the same as the sections that ring $$$1$$$ covers, hence $$$p_1=1$$$.

If we rotate ring $$$0$$$ clockwise five times, the sections ring $$$0$$$ covers will be the same as the sections that ring $$$2$$$ covers, hence $$$p_2=5$$$.

Note that if we will make a different set of rotations, we can end up with different values of $$$p_1$$$ and $$$p_2$$$ at the end.

Input Format: The first line consists of 2 integers $$$n$$$ and $$$m$$$ $$$(2 \leq n \leq 100, 2 \leq m \leq 20)$$$, indicating the number of rings and the number of sections each ring covers.

Output Format: None

Write your solution to one of: `/app/solution.py` (Python 3) or `/app/solution.cpp` (C++17). Your program must read from standard input and write to standard output. The verifier compiles your solution (if needed), runs it against test cases, and compares stdout (a special judge is used where the problem allows multiple valid outputs).