You will produce a structured response. Write your final answer to `/app/answer.txt`.
Emit a single well-formed XML document representing data that follows the JSON Schema in the task. The verifier checks the answer is well-formed XML and that every top-level required field from the schema appears as an element (or attribute) in the document.

---

[system]
Extract structured data from the given document. Only include information explicitly stated in the text.

I have a document and a schema. Please extract all matching information from the document into the schema format.

Document:
Sikorsky S-9
# Sikorsky S-9

Sikorsky S-9

| S-9 | |
| --- | --- |
|  | |
| Sikorsky S-9 circa 1913 | |
| Role | Experimental MonoplaneType of aircraft |
| National origin | Russian Empire |
| Manufacturer | Russian Baltic Railroad Car Works |
| Designer | Igor Sikorsky |
| First flight | 1913 |
| Number built | 1 |

The **Sikorsky S-9** *Kruglyj* (Rounded One) was a Russian single engine prototype aircraft completed in the spring of 1913 by the Russian Baltic Railroad Car Works while Igor Sikorsky was the chief engineer of the aircraft manufacturing division.

## Design and development

The S-9 was a three-seat mid-wing monoplane with constant-chord wire-braced wings originally powered by a Gnome air-cooled rotary engine rated at 100 hp (75 kW). It was the first monocoque monoplane built in Russia and the cylindrical tapered fuselage was constructed of plywood 5 mm thick in the forward section and 3mm thick aft. Construction was completed in the spring of 1913.[1][2]

## Operational history

Upon completion the S-9 was found to be substantially heavier than anticipated and the engine only delivered 80% of its rated horsepower. Initial flight tests revealed very poor performance. The engine was replaced by a 100 hp (75 kW) Gnome Monosoupape and further flights showed only a nominal increase in speed. The machine was eventually scrapped.[1]

## Specifications

S-9 nose detail

*Data from* *Russian Aviation Museum*[2]

**General characteristics**

* **Crew:** One
* **Capacity:** Two passenger
* **Upper wingspan:** 39 ft 4 in (12 m)
* **Wing area:** 320 sq ft (30 m$^{2}$ )
* **Empty weight:** 1,521 lb (690 kg)
* **Gross weight:** 2,183 lb (990 kg)
* **Powerplant:** 1 × Gnome Monosoupape 7-cylinder air-cooled rotary piston engine, 100 hp (75 kW)
* **Propellers:** 2-bladed

**Performance**

* **Maximum speed:** 56 mph (90 km/h, 49 kn)
* **Wing loading:** 6.8 lb/sq ft (33 kg/m$^{2}$ ) max load

Schema (xml):
<schema_definition>
  <name>Sikorsky_S9</name>
  <strict>true</strict>
  <schema>
    <type>object</type>
    <additionalProperties>false</additionalProperties>
    <required>
      <item>aircraft_name</item>
      <item>role</item>
      <item>manufacturer</item>
      <item>designer</item>
      <item>first_flight_year</item>
      <item>number_built</item>
    </required>
    <properties>
      <aircraft_name>
        <type>string</type>
      </aircraft_name>
      <role>
        <type>string</type>
      </role>
      <national_origin>
        <type>string</type>
      </national_origin>
      <manufacturer>
        <type>string</type>
      </manufacturer>
      <designer>
        <type>string</type>
      </designer>
      <first_flight_year>
        <type>integer</type>
      </first_flight_year>
      <number_built>
        <type>integer</type>
      </number_built>
      <configuration>
        <type>string</type>
      </configuration>
      <seats>
        <type>integer</type>
      </seats>
      <engine_original>
        <type>string</type>
      </engine_original>
      <engine_replaced>
        <type>string</type>
        <nullable>true</nullable>
      </engine_replaced>
      <construction_material>
        <type>string</type>
      </construction_material>
      <fuselage_thickness_forward_mm>
        <type>integer</type>
      </fuselage_thickness_forward_mm>
      <fuselage_thickness_aft_mm>
        <type>integer</type>
      </fuselage_thickness_aft_mm>
      <wing_span_m>
        <type>number</type>
      </wing_span_m>
      <wing_area_m2>
        <type>number</type>
      </wing_area_m2>
      <empty_weight_kg>
        <type>integer</type>
      </empty_weight_kg>
      <gross_weight_kg>
        <type>integer</type>
      </gross_weight_kg>
      <powerplant>
        <type>string</type>
      </powerplant>
      <propellers>
        <type>string</type>
      </propellers>
      <max_speed_kmh>
        <type>integer</type>
      </max_speed_kmh>
      <wing_loading_kg_per_m2>
        <type>number</type>
      </wing_loading_kg_per_m2>
      <operational_status>
        <type>string</type>
      </operational_status>
    </properties>
  </schema>
</schema_definition>

## Submitting your answer (IMPORTANT)
You are a terminal agent. Your chat reply is NOT graded — the grader only reads the file `/app/answer.txt` inside the sandbox. You MUST write your XML document to `/app/answer.txt` by RUNNING A SHELL COMMAND, e.g. a heredoc:

    cat > /app/answer.txt <<'EOF'
    <your XML document here>
    EOF

Then confirm it with `cat /app/answer.txt`. An empty or missing `/app/answer.txt` scores 0 regardless of what you wrote in your reply.
