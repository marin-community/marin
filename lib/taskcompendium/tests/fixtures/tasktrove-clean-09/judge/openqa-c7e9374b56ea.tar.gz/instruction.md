You are answering an open-ended question. Write your concise final answer to `/app/response.txt`. An LLM judge will compare your response to the reference answer(s) and score for semantic equivalence (paraphrases and alternative phrasings are acceptable as long as the substantive answer matches).

---

Solve the following problem step by step. Put your answer inside \boxed{}.

In an experiment where microbial cells were initially grown in darkness until a control culture exposed to fluorescent light showed slight turbidity, cells were then washed, resuspended in buffer, and exposed to fluorescent light for 5, 30, 60, or 120 minutes before being transferred to fresh medium and incubated in darkness for 7 days. A control group was inoculated and maintained under continuous light. Assuming that pigment production is induced only by light exposure during active growth, which condition would most likely result in the highest pigment level after the 7-day incubation period?
Remember to put your answer inside \boxed{}.