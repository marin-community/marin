You are answering an open-ended question. Write your concise final answer to `/app/response.txt`. An LLM judge will compare your response to the reference answer(s) and score for semantic equivalence (paraphrases and alternative phrasings are acceptable as long as the substantive answer matches).

---

Solve the following problem step by step. Put your answer inside \boxed{}.

The solid region D is bounded by the coordinate planes and by the surfaces z = 1 - y/3 and z = 1 - x. When setting up the triple integral over D, why is the order of integration dx dy dz easier to evaluate than dy dz dx?
Remember to put your answer inside \boxed{}.