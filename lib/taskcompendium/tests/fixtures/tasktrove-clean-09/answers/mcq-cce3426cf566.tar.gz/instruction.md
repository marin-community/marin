You are answering a multiple-choice question. Read the question below and write your final answer to `/app/answer.txt`.

The verifier extracts a single letter (A/B/C/...) from your answer file using a regex pattern; the simplest valid output is a file containing exactly
`Answer: X` (where X is your chosen letter).

---

Answer the following multiple choice question. The last line of your response should be in the following format: 'Answer: A/B/C/D/E/F/G/H/I/J' (e.g. 'Answer: D').

Predicting catalytic turnover frequencies solely from first-principles quantum calculations is fundamentally limited even with ideal computational resources because:

A: Density Functional Theory (DFT) systematically misrepresents transition state energies for complex bond rearrangements
B: Entropic contributions and solvation effects at reaction conditions are impossible to model accurately
C: Long-range van der Waals forces cannot be captured by current exchange-correlation functionals
D: Zero-point energy corrections introduce unacceptable errors above 500 K
E: Surface restructuring and dynamic catalyst evolution under operating conditions are inherently unpredictable
F: Ensemble effects requiring multiscale modeling exceed computational feasibility for realistic catalysts
G: Key kinetic parameters depend on emergent mesoscale phenomena inaccessible to ab initio methods
H: The Born-Oppenheimer approximation fails for excited electron states during catalysis
I: Explicit modeling of dispersive particle-support interactions remains computationally intractable
J: Quantum tunneling contributions dominate at industrially relevant temperatures