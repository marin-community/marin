#!/usr/bin/env python3
"""Score a captured shell session's output against one task's oracle output.

Reads the expected output from nl2bash_expected.json beside this script (under
``$TASKTROVE_TESTS_DIR``), compares it against the capture file named by its one argument,
and reports the reward through ``$TASKTROVE_LOGS_DIR/reward.json``. The comparison is a
normalized, order-insensitive multiset of "records" (one per output line; ANSI codes, a leading
``/workspace/`` or ``./`` prefix, a trailing size unit, and repeated whitespace are stripped):
every expected record must appear in the actual output, and no extra record may look like an
error. Self-contained: it does not import the original dataset's grader.
"""

import collections
import json
import os
import re
import sys
from pathlib import Path

OUTPUT = Path(sys.argv[1])
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ERROR = re.compile(r"(?i)\b(?:error|failed|failure|no such file|not found|permission denied|traceback)\b")
UNIT = re.compile(r"(?i)\s+(?:bytes?|kb|kib|mb|mib|gb|gib)\s*$")


def _record(line):
    value = ANSI.sub("", line).strip()
    value = re.sub(r"(?<!\S)/workspace/", "", value)
    value = re.sub(r"(?<!\S)\./", "", value)
    value = UNIT.sub("", value)
    return re.sub(r"\s+", " ", value).strip()


def _records(text):
    return [record for line in text.splitlines() if (record := _record(line))]


def _score(actual, expected):
    expected_records = collections.Counter(_records(expected))
    actual_records = collections.Counter(_records(actual))
    if not expected_records:
        return (1, []) if not actual_records else (0, ["expected empty output"])
    missing = expected_records - actual_records
    if missing:
        return 0, [f"missing expected records: {dict(missing)}"]
    extras = actual_records - expected_records
    for record in extras:
        if ERROR.search(record):
            return 0, [f"unexpected error record: {record}"]
    return 1, []


def main():
    tests_dir = Path(os.environ["TASKTROVE_TESTS_DIR"])
    logs_dir = Path(os.environ["TASKTROVE_LOGS_DIR"])
    data = json.loads((tests_dir / "nl2bash_expected.json").read_text())
    expected = data["expected_output"]

    if not OUTPUT.exists():
        reward, errors = 0, [f"missing output: {OUTPUT}"]
    else:
        reward, errors = _score(OUTPUT.read_text(errors="replace"), expected)

    for error in errors:
        print(error, file=sys.stderr)
    logs_dir.mkdir(parents=True, exist_ok=True)
    (logs_dir / "reward.json").write_text(json.dumps({"reward": reward}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
