#!/bin/bash
set -euo pipefail
exec tasktrove-verify /tests/verifier.toml
