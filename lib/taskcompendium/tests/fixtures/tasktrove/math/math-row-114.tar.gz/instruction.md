# Advanced Geometry Puzzle

<!-- laion v2 puzzles deliverable: answer.txt -->

## Deliverable (REQUIRED)

Write ONLY your final answer to **`/app/answer.txt`** (a single line, no
explanation). The verifier reads that file and compares it to the gold answer
using the format described in the problem statement:
- a number (a bare integer or decimal, e.g. `42` or `41.634`)
- coordinates as `(x, y)` rounded to 3 decimals where applicable
- a comma-separated list (order matters) where asked
- a single word choice (`on`, `off`, or `undetermined`) where asked

Do not include units labels the problem did not ask for; do not wrap the answer
in prose. The score is 1 for a correct answer, 0 otherwise.


## Puzzle Type
**advanced_geometry** from the **puzzle** dataset

## Problem Statement
Given triangle ABC with coordinates A=(-10, -9), B=(8, 4), and C=(-9, 10), find the coordinates of its orthocenter. For all geometry problems:
1. Give coordinates in the form (x, y)
2. Round decimal answers to 3 decimal places
3. Use the degree symbol ° for angles
4. Return only the angle, coordinates, or radius as your answer.


## Task
Solve this puzzle and provide your answer. The expected format and requirements are specified in the problem statement above.

Note: This is a logic/reasoning puzzle that requires careful analysis and systematic thinking to arrive at the correct solution.