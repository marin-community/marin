You are answering a multiple-choice question. Read the question below and write your final answer to `/app/answer.txt`.

The verifier extracts a single letter (A/B/C/...) from your answer file using a regex pattern; the simplest valid output is a file containing exactly
`Answer: X` (where X is your chosen letter).

---

Answer the following multiple choice question. The last line of your response should be in the following format: 'Answer: \boxed{A/B/C/D/E/F/G/H/I/J}' (e.g. 'Answer: \boxed{E}').

In office lighting design for reading printed documents, what is the recommended minimum luminance contrast ratio between the task (text) and its immediate background to ensure visual comfort without excessive glare?

A: 1:1
B: 2:1
C: 3:1
D: 4:1
E: 5:1
F: 7:1
G: 10:1
H: 15:1
I: 20:1
J: No specific ratio is recommended