You are answering an open-ended question. Write your concise final answer to `/app/response.txt`. An LLM judge will compare your response to the reference answer(s) and score for semantic equivalence (paraphrases and alternative phrasings are acceptable as long as the substantive answer matches).

---

Solve the following problem step by step. Put your answer inside \boxed{}.

In a Fraunhofer diffraction experiment with a circular aperture, when monochromatic light of wavelength $ \lambda $ is incident at an oblique angle $ \theta_0 $, a phase difference is introduced across the aperture, causing the principal intensity maximum to shift from $ \theta = 0 $ to $ \theta = \theta_0 $. What is the total phase difference (in radians) accumulated across the diameter of the aperture due to this oblique incidence, where $ a $ is the radius of the aperture?
Remember to put your answer inside \boxed{}.