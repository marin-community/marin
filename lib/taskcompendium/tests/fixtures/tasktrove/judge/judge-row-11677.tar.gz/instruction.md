You are answering an open-ended question. Write your concise final answer to `/app/response.txt`. An LLM judge will compare your response to the reference answer(s) and score for semantic equivalence (paraphrases and alternative phrasings are acceptable as long as the substantive answer matches).

---

Solve the following problem step by step. Put your answer inside \boxed{}.

Two independent experiments measure the branching ratio for the decay ℓ → ℓ′γ in a back-to-back geometry, with the muon channel using energy and angular resolutions of ΔE = 0.01Eℓ′ and Δθ = 10 mrad, and the tau channel using ΔE = 0.04Eℓ′ and Δθ = 13 mrad. After applying a photon energy threshold of 10 MeV in the lepton rest frame and integrating over their respective resolution windows, the branching ratios are found to be BR(τ) ≈ 1.68 × 10⁻¹⁰ and BR(μ) ≈ 1.34 × 10⁻¹⁰. What is the primary reason these values are significantly smaller than those obtained using the KMS method?
Remember to put your answer inside \boxed{}.